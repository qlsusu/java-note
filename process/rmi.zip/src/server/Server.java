package server;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class Server {

	public void serverStart() {

		try {
			// 启动RMI服务
			LocateRegistry.createRegistry(7890);// rmi端口
			MyRMI myRmi = new MyRMI();
			Naming.rebind("//localhost:7890/rmi", myRmi);// 绑定
			System.out.println("rmi launched");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new Server().serverStart();
	}

}