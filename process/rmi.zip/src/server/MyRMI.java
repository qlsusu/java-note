package server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import com.ql.tool.FileTool;

/**
 * 远程RMI 页面采集接口实现类
 * 
 * <a href="http://my.oschina.net/arthor" target="_blank"
 * rel="nofollow">@author</a> 张飞
 * 
 */

public class MyRMI extends UnicastRemoteObject implements IMyRMI {
	public MyRMI() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	private static final long serialVersionUID = 1L;

	public void test() throws RemoteException {
		// TODO Auto-generated method stub
		System.out.println("run on server");
		FileTool.getInstance().writeData("test.txt", "adfasdf".getBytes());
	}

}