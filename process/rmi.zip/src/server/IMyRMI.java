package server;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * 远程RMI 页面采集接口
 * 
 * 
 */
public interface IMyRMI extends Remote {
    public void test() throws RemoteException;
}