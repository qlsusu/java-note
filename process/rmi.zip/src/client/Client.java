package client;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import server.IMyRMI;

public class Client {

	public static void main(String[] args) {
		try {
			IMyRMI rmi = (IMyRMI) Naming.lookup("//109.123.106.81:7890/rmi");
			rmi.test();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (NotBoundException e) {
			e.printStackTrace();
		}
	}
}