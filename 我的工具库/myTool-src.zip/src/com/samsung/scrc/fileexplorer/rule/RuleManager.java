package com.samsung.scrc.fileexplorer.rule;

import java.util.ArrayList;
import java.util.List;

import com.samsung.scrc.fileexplorer.entity.Entity;

public class RuleManager {
	private static RuleManager instance = new RuleManager();

	private RuleManager() {

	}

	public static RuleManager getInstance() {
		return instance;
	}

	public List<Entity> getRelated(Entity entity) {
		List<Entity> entities = new ArrayList<Entity>();

		return entities;
	}
}
