package com.samsung.scrc.fileexplorer.rule;

import java.util.ArrayList;

import java.util.List;

public class RuleConfig {
	public static class Rule {
		public static class Item {
			public String field1;
			public String field2;
			public String operator;
		}

		public String type1;
		public String type2;
		public List<Item> items = new ArrayList<RuleConfig.Rule.Item>();
	}

	public List<Rule> rules = new ArrayList<RuleConfig.Rule>();
}
