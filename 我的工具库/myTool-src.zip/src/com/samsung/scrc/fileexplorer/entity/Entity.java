package com.samsung.scrc.fileexplorer.entity;

public interface Entity {
}
