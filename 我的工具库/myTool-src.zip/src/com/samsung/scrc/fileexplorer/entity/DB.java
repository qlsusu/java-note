package com.samsung.scrc.fileexplorer.entity;

import java.util.ArrayList;
import java.util.List;

import com.samsung.scrc.fileexplorer.entity.Movie;
import com.samsung.scrc.fileexplorer.entity.Music;
import com.samsung.scrc.fileexplorer.entity.Photo;

public class DB {
	private List<Music> musics = new ArrayList<Music>();
	private List<Movie> movies = new ArrayList<Movie>();
	private List<Photo> photos = new ArrayList<Photo>();

	public List<Music> getMusics() {
		return musics;
	}

	public List<Movie> getMovies() {
		return movies;
	}

	public List<Photo> getPhotos() {
		return photos;
	}

}
