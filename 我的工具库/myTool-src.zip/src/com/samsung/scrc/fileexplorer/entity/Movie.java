package com.samsung.scrc.fileexplorer.entity;

public class Movie implements Entity {
	public String director;
	public String actor;
	public String type;
	public String releaseTime;
	public String series;
	public String location;
	public String resolution;
	public String duration;
	public String producer;

	public String name;
	public String modifyTime;
	public String size;
	public String desc;

}