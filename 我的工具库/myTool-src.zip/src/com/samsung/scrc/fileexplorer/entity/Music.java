package com.samsung.scrc.fileexplorer.entity;

public class Music implements Entity {
	public String singer;
	public String album;
	public String releaseTime;
	public String inMovie;
	public String genre;
	public String duration;

	public String name;
	public String modifyTime;
	public String size;
	public String desc;

}