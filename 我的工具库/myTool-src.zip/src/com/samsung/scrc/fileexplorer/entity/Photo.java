package com.samsung.scrc.fileexplorer.entity;

public class Photo implements Entity {
	public String location;
	public String resolution;
	public String takeTime;

	public String name;
	public String modifyTime;
	public String size;
	public String desc;

}