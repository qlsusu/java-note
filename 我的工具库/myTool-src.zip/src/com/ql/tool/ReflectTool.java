package com.ql.tool;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ReflectTool {
	public static ReflectTool instance = new ReflectTool();

	private ReflectTool() {

	}

	public void getAllFields(Class<?> clz, List<Field> fields) {
		if (clz != null) {
			Field[] fs = clz.getDeclaredFields();
			for (Field f : fs) {
				fields.add(f);
			}
			Class<?> superClz = clz.getSuperclass();
			if (superClz != null) {
				getAllFields(superClz, fields);
			}
		}
	}

	/**
	 * 获得property的值
	 * 
	 * @param prop
	 *            a.b.c形式：获取src的a的b的c的值
	 * @param src
	 * @return
	 * @see #getProperty(List, Object)
	 * @see #getProperty(List, Object, int, List)
	 */
	public List<Object> getProperty(String prop, Object src) {
		if (src != null && !StringTool.isNull(prop)) {
			return getProperty(Arrays.asList(prop.split("\\.")), src);
		}

		return null;
	}

	/**
	 * 获得property的值
	 * 
	 * @param ps
	 *            [a,b,c]形式：获取src的a的b的c的值
	 * @param src
	 * @return
	 * @see #getProperty(List, Object, int, List)
	 */
	public List<Object> getProperty(List<String> ps, Object src) {
		List<Object> pos = new ArrayList<>();
		getProperty(ps, src, 0, pos);
		return pos;
	}

	/**
	 * 获得property的值<br>
	 * 不允许：<br>
	 * 若property的类型为list，则不允许该list中的元素为list，后续改进...
	 * 若property为collection类型，则只能为list类型，后续改进...
	 * 
	 * @param ps
	 *            [a,b,c]形式：获取src的a的b的c的值
	 * @param src
	 * @param pIndex
	 *            当前在获取src的 ps[index]的 值
	 * @param pos
	 *            最终的prperty值将被放入到该数组中<br>
	 *            为什么使用数组： 当b是一个list，而c是一个 非list<br>
	 *            当property为list，则返回list对象
	 */
	private void getProperty(List<String> ps, Object src, int pIndex,
			List<Object> pos) {
		if (src != null && ps != null && !ps.isEmpty()) {
			try {
				if (src.getClass() != ArrayList.class) {
					try {
						Field field = src.getClass().getDeclaredField(
								ps.get(pIndex));
						field.setAccessible(true);
						Object po = field.get(src);

						pIndex++;
						if (pIndex == ps.size()) {
							pos.add(po);
						} else {
							getProperty(ps, po, pIndex, pos);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					@SuppressWarnings("rawtypes")
					List list = (List) src;
					for (Object ele : list) {
						getProperty(ps, ele, pIndex, pos);
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			pos.add(src);
		}
	}

	public void setBeanBuffer2(Object o, String prefix, StringBuffer buf) {
		setBeanBuffer(o, prefix, buf);

		String content = buf.toString();
		String[] ss = content.split("\n");

		Map<String, String> map = new HashMap<String, String>();

		for (String s : ss) {
			String key = s.substring(0, s.indexOf(":"));
			String value = s.substring(s.indexOf(":") + 1);

			if (!map.containsKey(key)) {
				map.put(key, value);
			} else {
				value = map.remove(key) + " | " + value;

				map.put(key, value);
			}
		}

		buf.replace(0, buf.length(), "");
		Set<String> keys = map.keySet();
		for (String k : keys) {
			buf.append(k + ":" + map.get(k) + "\n");
		}
	}

	@SuppressWarnings("rawtypes")
	public void setBeanBuffer(Object o, String prefix, StringBuffer buf) {
		try {
			if (o != null) {
				Field[] fs = o.getClass().getDeclaredFields();
				for (Field f : fs) {
					f.setAccessible(true);
					Object value = f.get(o);
					if (value != null) {
						if (f.getType().isPrimitive()
								|| f.getType() == String.class) {
							buf.append(prefix + "." + f.getName() + ":"
									+ f.get(o) + "\n");
						} else if (f.getType() == List.class) {
							List list = (List) f.get(o);
							Class eleClz = Class
									.forName(((ParameterizedType) f
											.getGenericType())
											.getActualTypeArguments()[0]
											.toString().split(" ")[1]);
							if (eleClz.isPrimitive() || eleClz == String.class) {
								for (Object obj : list) {
									buf.append(prefix + "." + f.getName() + ":"
											+ obj + "\n");
								}
							} else {
								for (Object obj : list) {
									setBeanBuffer(obj,
											prefix + "." + f.getName(), buf);
								}
							}
						} else {
							setBeanBuffer(f.get(o), prefix + "." + f.getName(),
									buf);
						}
					} else {
						buf.append(prefix + "." + f.getName() + ":" + "\n");
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void setObj(Object src, String fieldName, Object value,
			boolean isUseLastEleInCollection) {
		if (src != null && !StringTool.isNull(fieldName) && value != null) {
			final String seperator = ",@,@";
			fieldName = fieldName.replace(".", seperator);
			String[] fs = fieldName.split(seperator);

			Class<?> clz = src.getClass();
			try {
				if (fs.length > 1) {
					for (int i = 0; i < fs.length - 1; i++) {
						Field field = clz.getDeclaredField(fs[i]);
						field.setAccessible(true);
						if (field.getType() == List.class) {
							clz = Class
									.forName(((ParameterizedType) field
											.getGenericType())
											.getActualTypeArguments()[0]
											.toString().split(" ")[1]);
							List list = (List) field.get(src);

							if (list.isEmpty() || !isUseLastEleInCollection) {
								Object o = clz.newInstance();
								list.add(o);
								src = o;
							} else if (isUseLastEleInCollection) {
								src = list.get(list.size() - 1);
							}
						} else {
							if (field.get(src) == null) {
								Object o = field.getType().newInstance();
								field.set(src, o);
							}
							src = field.get(src);
							clz = field.getType();
						}
					}
				}

				Field f = clz.getDeclaredField(fs[fs.length - 1]);
				f.setAccessible(true);
				Class<?> type = f.getType();
				if (type == double.class) {
					f.set(src, Double.valueOf(value + ""));
				} else if (type == float.class) {
					f.set(src, Float.valueOf(value + ""));
				} else if (type == int.class) {
					f.set(src, Integer.valueOf(value + ""));
				} else if (type == String.class) {
					f.set(src, value);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
			}
		}
	}

	public void lightCopy(Object target, Object src) {
		if (target != null && src != null
				&& target.getClass() == src.getClass() && target != src) {
			List<Field> fs = new ArrayList<>();
			getAllFields(src.getClass(), fs);
			for (Field f : fs) {
				f.setAccessible(true);
				try {
					f.set(target, f.get(src));
				} catch (IllegalArgumentException | IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
