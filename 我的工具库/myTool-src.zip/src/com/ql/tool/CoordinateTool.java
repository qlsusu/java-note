package com.ql.tool;

import java.util.ArrayList;
import java.util.List;

public class CoordinateTool {
	private CoordinateTool() {

	}

	private static CoordinateTool intance = new CoordinateTool();

	public static CoordinateTool getIntance() {
		return intance;
	}

	/**
	 * 将dms转换为ddd<br>
	 * 例子：108度54分22.2秒=108+(54/60)+(22.2/3600)=108.90616度
	 * 
	 * @param d
	 * @param m
	 * @param s
	 * @return
	 */
	public double getDdd(double d, double m, double s) {
		double value = -1;

		value = d + m / 60.0 + s / 3600.0;

		return value;
	}

	/**
	 * 将ddd转换为dms<br>
	 * 例子： 108.90593整数位不变取108(度),用0.90593*60=54.3558,取整数位54(分),0.3558*60=21.348
	 * 再取整数位21(秒)<br>
	 * 故转化为108度54分21秒.
	 * 
	 * @param ddd
	 * @return
	 */
	public double[] getDms(double ddd) {
		double[] dms = new double[3];

		dms[0] = (int) ddd;

		double value = (ddd - dms[0]) * 60;
		dms[1] = (int) value;
		dms[2] = (value - dms[1]) * 60;

		return dms;
	}

	/**
	 * 从一个dms字符串描述中，找到dms
	 * 
	 * @param s
	 *            形式： 34° 35' 48" North 14 57′ <br>
	 *            或者，19°06′20″N<br>
	 *            或者，120 45′ 40.72″ E<br>
	 *            或者，9.33°N<br>
	 *            或者，07º13'S<br>
	 * @return
	 * @deprecated
	 */
	public String[] splitDms(String s) {
		String[] dms = null;

		if (!StringTool.isNull(s)) {
			dms = new String[4];

			final String dt0 = "°";
			final String dt1 = "'";
			final String dt2 = "\"";

			int idxTag = -1;

			// 先进行转换，
			// 针对于07º13'S
			s = s.replace("º", dt0);
			// 针对于：19°06′20″N
			s = s.replace("′", dt1);
			s = s.replace("″", dt2);

			int idx0 = s.indexOf(dt0);
			if (idx0 != -1) {
				idxTag = idx0;

				dms[0] = s.substring(0, idx0).trim();
			}

			int idx1 = s.indexOf(dt1, idx0);
			if (idx1 != -1) {
				idxTag = idx1;

				dms[1] = s.substring(idx0 + 1, idx1).trim();

				int idx2 = s.indexOf(dt2, idx1);
				if (idx2 != -1) {
					idxTag = idx2;

					dms[2] = s.substring(idx1 + 1, idx2).trim();

					// 针对于120 45′ 40.72″ E形式
					if (dms[0] == null) {
						String[] ss = dms[1].split(" ");
						if (ss.length == 2) {
							dms[0] = ss[0].trim();
							dms[1] = ss[1].trim();
						} else {
							dms = null;
						}
					}
				}
			}

			if (idxTag != -1) {
				// 设置 经纬度tag
				dms[3] = s.substring(idxTag + 1).trim();
			}
		}

		return dms;
	}

	/**
	 * 从一个dms字符串描述中，找到dms<br>
	 * 支持形式：<br>
	 * 34° 35' 48" North<br>
	 * 34° 35' 48\" North 43° 40' 37\" East <br>
	 * 19°06′20″N<br>
	 * 37º36'22' N<br>
	 * 9.33°N<br>
	 * 07º13'S<br>
	 * 14 57′ 35.15″ N, 120 45′ 40.72″ E"<br>
	 * 46.84972（认为是degree，注意：如果不指定direction，s不要为经纬度混合形式，如：-31.955002,115.858469）<br>
	 * 40.614637 N, 75.165496 <br>
	 * 120 45′ 40.72″ E（认为120是degree）<br>
	 * 06′20″N（存在问题：不知道是d还是m）<br>
	 * 26°42'48.52\"N/ 81°36'35.98\"W<br>
	 * 15° 52' 60 N , 74° 34' 60 E（没有"关键字） 53°53'23\"N. 1°36'45\"W.
	 * 
	 * 缺点：<br>
	 * 1.如，对于：06′20″N，dms仅仅分割成2个字符串，无法知道：是d还是m
	 * 2.无法纠错，如果用户提供错误，如：06′20N″（应该为06′20″N）
	 * 
	 * @param s
	 * 
	 * @return
	 */
	public List<String[]> splitDmsd(String s) {
		List<String[]> dmsds = new ArrayList<>();

		if (!StringTool.isNull(s)) {
			final String dirSplitExp = "(?i)[(north)|n|(south)|s|(east)|e|(west)|w]";
			// 加上一个空格，因为：xxx和12n 经过exp分割，长度均为1，则无法判断：提供的s是否是有效的
			s += " ";

			String[] latLng = s.split(dirSplitExp);
			// length大于1，才代表s是有效的
			if (latLng.length > 1) {
				List<String> unit = new ArrayList<>();
				for (String data : latLng) {
					if (!StringTool.isNull(data)) {
						unit.add(data);
					}
				}

				// 计算dms
				for (int i = 0; i < unit.size(); i++) {
					String[] dmsd = new String[4];
					dmsds.add(dmsd);

					String data = unit.get(i);
					final String[] removes = new String[] { ",", "/", ";" };
					for (String remove : removes) {
						data = data.replace(remove, "").trim();
					}
					final String[] removeStarts = new String[] { "." };
					for (String remove : removeStarts) {
						if (data.startsWith(remove)) {
							data = data.replace(remove, "").trim();
						}
					}

					if (!StringTool.isNull(data)) {
						final String dmsSplitExp = "(?i)[°|º|'|′|’|\"|″|_|:]";

						String[] ds = data.split(dmsSplitExp);

						for (int j = 0, k = 0; j < ds.length
								&& k < dmsd.length - 1; j++) {
							if (!StringTool.isNull(ds[j])) {
								dmsd[k] = ds[j].trim();
								k++;
							}
						}
					}
				}
				for (String[] dmsd : dmsds) {
					List<String> list = new ArrayList<>();
					for (String data : dmsd) {
						if (!StringTool.isNull(data)) {
							String[] ss = data.split(" ");
							for (String str : ss) {
								str = str.trim();
								if (!StringTool.isNull(str)) {
									list.add(str);
								}
							}
						}
					}
					for (int i = 0; i < list.size(); i++) {
						dmsd[i] = list.get(i);
					}
				}

				// 计算direction
				int start = -1;
				for (int i = 0; i < unit.size() - 1; i++) {
					String data = unit.get(i);
					String[] dmsd = dmsds.get(i);

					start = s.indexOf(data, start + 1) + data.length();
					dmsd[dmsd.length - 1] = s.substring(start,
							s.indexOf(unit.get(i + 1), start + +1)).trim();
				}
				String[] dmsd = dmsds.get(dmsds.size() - 1);
				String direction = s.substring(
						s.lastIndexOf(unit.get(unit.size() - 1))
								+ unit.get(unit.size() - 1).length()).trim();
				dmsd[dmsd.length - 1] = direction;

				// 去掉无效的dmsd：每个元素均为 空或者""
				List<String[]> removes = new ArrayList<>();
				for (String[] d : dmsds) {
					boolean isBad = true;
					for (String str : d) {
						if (!StringTool.isNull(str)) {
							isBad = false;
							break;
						}
					}
					if (isBad) {
						removes.add(d);
					}
				}
				dmsds.removeAll(removes);
			}
			// 如果不能按照direction进行分割，则认为为纯数字
			else {
				String[] dmsd = new String[4];
				dmsds.add(dmsd);
				dmsd[0] = s.trim();
			}
		}

		return dmsds;
	}
}
