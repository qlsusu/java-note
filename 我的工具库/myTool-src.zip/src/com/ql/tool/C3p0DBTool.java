package com.ql.tool;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.mchange.v2.c3p0.DataSources;

public final class C3p0DBTool {
	private static final Log LOG = LogFactory.getLog(C3p0DBTool.class);
	
	private static final String POOLNAME_DEFAULT = "pool_extractor";

	private ComboPooledDataSource ds;

	private Map<String, ComboPooledDataSource> tagToDs = new HashMap<>();

	private C3p0DBTool() {
		if (ds != null) {
			ds.close();
		}

		ds = new ComboPooledDataSource(POOLNAME_DEFAULT);
	}

	private static class SingletonHolder {
		private static C3p0DBTool instance = new C3p0DBTool();
	}

	public static final C3p0DBTool getInstance() {
		return SingletonHolder.instance;
	}

	public synchronized final Connection getConnection() {
		return getConnection(POOLNAME_DEFAULT);
	}

	public synchronized final Connection getConnection(String tag) {
		Connection connection = null;
		if (!StringTool.isNull(tag)) {
			try {
				ComboPooledDataSource ds = null;
				for (Entry<String, ComboPooledDataSource> entry : tagToDs
						.entrySet()) {
					if (entry.getKey().equals(tag)) {
						ds = entry.getValue();
						break;
					}
				}
				if (ds == null) {
					ds = new ComboPooledDataSource(tag);
					tagToDs.put(tag, ds);
				}
				connection = ds.getConnection();
			} catch (SQLException e) {
				// TODO
				e.printStackTrace();
			}
		}

		return connection;
	}

	/**
	 * 创建表<br>
	 * 以itemid的 incre*10000 进行分割
	 * 
	 * @param tablePrefix
	 */
	public void executeSqlFileWithTable(String sqlFile, List<String> tables) {
		if (FileTool.getInstance().isFileExist(sqlFile) && tables != null) {
			String sqlOriginal = new String(FileTool.getInstance().readContent(
					sqlFile));

			final String tableTag = "{tableName}";
			for (String table : tables) {
				String sql = sqlOriginal.replace(tableTag, table);
				LOG.debug(sql);

				Connection conn = getConnection();
				Statement statement = null;

				try {
					statement = conn.createStatement();
					statement.execute(sql);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					LOG.debug(e.toString());
				} finally {
					close(conn, statement, null);
				}
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					LOG.debug(e.toString());
				}
			}
		}
	}

	protected synchronized final void destroy() {
		try {
			DataSources.destroy(ds);
		} catch (SQLException e) {
			// TODO
		}
	}

	public void close(Connection conn) {
		close(conn, null, null);
	}

	public void close(Statement statement) {
		DbUtils.closeQuietly(statement);
	}

	public void close(ResultSet rs) {
		DbUtils.closeQuietly(rs);
	}

	public void close(Connection conn, Statement statement, ResultSet rs) {
		DbUtils.closeQuietly(conn, statement, rs);
	}

}
