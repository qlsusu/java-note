package com.ql.tool;

import java.util.ArrayList;
import java.util.List;

public class ListTool {
	public static ListTool instance = new ListTool();

	private ListTool() {

	}

	/**
	 * 将source分成若干个list，每个list的size 不大于 unitSize
	 * 
	 * @param source
	 * @param unitSize
	 * @return
	 */
	public List<List<?>> splitList(List<?> source, int unitSize) {
		List<List<?>> lists = new ArrayList<>();

		if (source != null && unitSize > 0) {
			int count = 0;
			while (true) {
				if (count + unitSize <= source.size()) {
					lists.add(source.subList(count, count + unitSize));
					count += unitSize;
				} else {
					if (count >= source.size()) {
						break;
					}
					lists.add(source.subList(count, source.size()));
					break;
				}
			}
		}

		return lists;
	}
}
