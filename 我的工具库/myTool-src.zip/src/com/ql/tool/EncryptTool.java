package com.ql.tool;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class EncryptTool {
	private static EncryptTool instance = new EncryptTool();

	public static final String MD5 = "MD5";
	public static final String SHA1 = "SHA1";

	public static EncryptTool getInstance() {
		return instance;
	}

	public String encrypt(String strSrc, String encName) {
		// parameter strSrc is a string will be encrypted,
		// parameter encName is the algorithm name will be used.
		// encName dafault to "MD5"
		// 得到MessageDigest对象
		MessageDigest md = null;
		// 加密后的字符串
		String strDes = null;
		// 要加密的字符串字节型数组
		byte[] bt = strSrc.getBytes();
		try {
			if (StringTool.isNull(encName)) {
				encName = MD5;
			}
			md = MessageDigest.getInstance(encName);
			md.update(bt);
			// 通过执行诸如填充之类的最终操作完成哈希计算
			strDes = bytes2Hex(md.digest()); // to HexString
		} catch (NoSuchAlgorithmException e) {
			// System.out.println("Invalid algorithm./n" + e.getMessage());
			return null;
		}
		return strDes;
	}

	// 将字节数组转换成16进制的字符串
	private String bytes2Hex(byte[] bts) {
		String des = "";
		String tmp = null;

		for (int i = 0; i < bts.length; i++) {
			tmp = (Integer.toHexString(bts[i] & 0xFF));
			if (tmp.length() == 1) {
				des += "0";
			}
			des += tmp;
		}
		return des;
	}
}
