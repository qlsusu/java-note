package com.ql.tool;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.Character.UnicodeBlock;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;

/**
 * A utility about string.
 * 
 * @author qilu
 * 
 */
public class StringTool {
	public static boolean isNull(String str) {
		return str == null || str.trim().equals("");
	}

	public static String adjust(String str, List<String> unwantedWords,
			boolean isHandleColon) {
		if (!isNull(str)) {
			if (isHandleColon && str.contains("\"")) {
				str = str.replaceAll("\"", "\\\\\"");
			}
			// System.out.println("str:" + str);
			if (unwantedWords != null) {
				for (String s : unwantedWords) {
					str = str.replace(s, "");
				}
			}
		}
		return str;
	}

	public static List<String> getKeys(String s, String startS, String endS) {
		List<String> list = new ArrayList<String>();

		if (!isNull(s)) {
			int start = -1;
			int end = -1;
			while (true) {
				start = s.indexOf(startS);
				end = s.indexOf(endS, start);
				if (start != -1 && end != -1) {
					String key = s.substring(start + 1, end);
					s = s.substring(end + 1);
					list.add(key);
				} else {
					break;
				}
			}
		}
		return list;
	}

	/**
	 * 将str中的空白（空格，tab，回车，换行，-，/），替换成replace
	 * 
	 * @param str
	 * @param replace
	 * @return
	 */
	public static String replaceSignBlank(String str, String replace) {
		String result = null;

		if (!isNull(str)) {
			replace = isNull(replace) ? "_" : replace;
			// String reg = "[ \t\r\n]";
			String reg = "(?i)[^a-zA-Z0-9\u4E00-\u9FA5]";
			result = str.replaceAll(reg, replace);
			// result = result.replace("-", replace);
			// result = result.replace("/", replace);

			result = result.trim();
		}
		return result;
	}

	/**
	 * 连接两个字符串<br>
	 * 允许 其一/全部 为空
	 * 
	 * @param a
	 * @param b
	 * @param connector
	 * @return
	 */
	public static String connectStrings(String a, String b, String connector) {
		StringBuffer result = new StringBuffer();

		connector = !isNull(connector) ? connector : " ";
		if (!isNull(a)) {
			result.append(a).append(connector);
		}
		if (!isNull(b)) {
			result.append(b);
		}

		return result.toString().trim();
	}

	public static String connectStringsIgnoreAlreadyHave(String a, String b) {
		StringBuffer result = new StringBuffer();

		if (!isNull(b)) {
			result.append(b);
		}
		if (isNull(result.toString()) && !isNull(a)) {
			result.append(a);
		}

		return result.toString();
	}

	public static String UpperFirstChar(String str) {
		String s = null;

		if (!isNull(str)) {
			s = str.substring(0, 1).toUpperCase();
			if (str.length() > 1) {
				s = s + str.substring(1);
			}
		}

		return s;
	}

	public static String lowerFirstChar(String str) {
		String s = null;

		if (!isNull(str)) {
			s = str.substring(0, 1).toLowerCase();
			if (str.length() > 1) {
				s = s + str.substring(1);
			}
		}

		return s;
	}

	/**
	 * str的一部分 是否在set中
	 * 
	 * @param str
	 * @param set
	 * @return
	 */
	public static boolean isPartInSet(String str, Set<String> set) {
		if (!isNull(str) && set != null) {
			for (String s : set) {
				if (str.contains(s)) {
					return true;
				}
			}
		}

		return false;
	}

	public static String firstCharLow(String s, boolean isLow) {
		String str = null;
		if (!isNull(s)) {
			if (isLow) {
				str = (s.charAt(0) + "").toLowerCase()
						+ s.subSequence(1, s.length());
			} else {
				str = (s.charAt(0) + "").toUpperCase()
						+ s.subSequence(1, s.length());
			}
		}
		return str;
	}

	public static String becomeXmlSpecialChar(String value) {
		String str = null;
		if (!isNull(value)) {
			Map<String, String> map = new HashMap<>();
			map.put("&", "&amp;");
			map.put(">", "&gt;");
			map.put("<", "&lt;");
			map.put("\"", "&quot;");
			map.put("'", "&apos;");

			for (String key : map.keySet()) {
				value = value.replaceAll(key, map.get(key));
			}
			str = value;
		}
		return str;
	}

	public static String removeXmlSpecialChar(String value) {
		String str = null;
		if (!isNull(value)) {
			Map<String, String> map = new HashMap<>();
			map.put("&", "&amp;");
			map.put(">", "&gt;");
			map.put("<", "&lt;");
			map.put("\"", "&quot;");
			map.put("'", "&apos;");

			for (String key : map.keySet()) {
				value = value.replaceAll(map.get(key), key);
			}
			str = value;
		}
		return str;
	}

	/**
	 * 将s的每个char变成16进制
	 * 
	 * @param s
	 * @return
	 */
	public static String toHexString(String s) {
		if (!isNull(s)) {
			StringBuffer buffer = new StringBuffer();
			for (int i = 0; i < s.length(); i++) {
				int cha = s.charAt(i);
				buffer.append(Integer.toHexString(cha));
			}
			return "0x" + buffer.toString();
		}
		return null;
	}

	/**
	 * trim<br>
	 * 包括去掉 全角半角空格
	 * 
	 * @param src
	 * @return
	 */
	public static String trim(String src) {
		String s = src;
		if (!StringTool.isNull(src)) {
			src = src.trim();

			String regStartSpace = "^[　 ]*";
			String regEndSpace = "[　 ]*$";

			// 连续两个 replaceAll
			// 第一个是去掉前端的空格， 第二个是去掉后端的空格
			s = src.replaceAll(regStartSpace, "").replaceAll(regEndSpace, "");
		}

		return s;
	}

	public static String removeHtmlTag(String s) {
		if (!isNull(s)) {
			return new String(Jsoup.parse(new String(s)).text());
		}
		return null;
	}

	public static List<String> getExpContent(String s, String reg) {
		List<String> contents = new ArrayList<>();

		if (!isNull(s) && !isNull(reg)) {
			// 创建 Pattern 对象
			Pattern r = Pattern.compile(reg, Pattern.MULTILINE);
			// 现在创建 matcher 对象
			Matcher m = r.matcher(s);

			List<Integer> starts = new ArrayList<>();
			List<Integer> ends = new ArrayList<>();
			while (m.find()) {
				starts.add(m.start());
				ends.add(m.end());
			}

			for (int i = 0; i < starts.size(); i++) {
				int start = starts.get(i);
				int end = ends.get(i);

				contents.add(s.substring(start, end));
			}
		}
		return contents;
	}

	/**
	 * 按照一堆exp来分割string
	 * 
	 * @param s
	 * @param splitExps
	 * @return
	 */
	public static List<String> split(String s, List<String> splitExps) {
		List<String> contents = new ArrayList<>();

		if (!StringTool.isNull(s)) {
			List<String> list = new ArrayList<>();

			if (!StringTool.isNull(s)) {
				contents.add(s);
				list.clear();
				list.addAll(contents);
				contents.clear();

				for (String se : splitExps) {
					for (String str : list) {
						contents.addAll(Arrays.asList(str.split(se)));
					}

					list.clear();
					list.addAll(contents);
					contents.clear();
				}
				contents.addAll(list);
			}

			// 元素进行trim，且，去除""元素
			list.clear();
			for (int i = 0; i < contents.size(); i++) {
				String content = contents.get(i);
				contents.set(i, content.trim());
				if (isNull(content)) {
					list.add(content);
				}
			}
			contents.removeAll(list);
		}

		return contents;
	}

	public static int indexCount(String s, String tag) {
		int count = 0;

		if (!isNull(s) && !isNull(tag)) {
			int index = -1;
			while (true) {
				index = s.indexOf(tag, index);
				if (index != -1) {
					count++;
					index += 1;
				} else {
					break;
				}
			}
		}

		return count;

	}

	/**
	 * 统计单词的数目
	 * 
	 * @param s
	 * @return
	 */
	public static int wordCount(String s) {
		int count = 0;
		if (!isNull(s)) {
			String pattern = "\\b\\w+\\b";

			Pattern r = Pattern.compile(pattern, Pattern.MULTILINE);
			Matcher m = r.matcher(s);
			while (m.find()) {
				count++;
			}
		}
		return count;
	}

	public static List<String> getLines(String s) {
		List<String> lines = new ArrayList<>();

		if (!isNull(s)) {
			try {
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(new ByteArrayInputStream(
								s.getBytes())));
				String line = null;
				while ((line = reader.readLine()) != null) {
					if (!isNull(line)) {
						lines.add(line);
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return lines;
	}

	public static String getRegularFieldName(String field) {
		String name = null;
		if (!isNull(field)) {
			String[] ss = field.split("_");
			if (ss.length == 1) {
				name = field;
			} else {
				name = ss[0];
				for (int i = 1; i < ss.length; i++) {
					name += UpperFirstChar(ss[i]);
				}
			}
		}
		return name;
	}

	/**
	 * utf-8 转换成 unicode
	 * 
	 * @author fanhui 2007-3-15
	 * @param utf8Str
	 * @return
	 */
	public static String utf8ToUnicode(String utf8Str) {
		char[] myBuffer = utf8Str.toCharArray();

		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < utf8Str.length(); i++) {
			UnicodeBlock ub = UnicodeBlock.of(myBuffer[i]);
			if (ub == UnicodeBlock.BASIC_LATIN) {
				// 英文及数字等
				sb.append(myBuffer[i]);
			} else if (ub == UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS) {
				// 全角半角字符
				int j = (int) myBuffer[i] - 65248;
				sb.append((char) j);
			} else {
				// 汉字
				short s = (short) myBuffer[i];
				String hexS = Integer.toHexString(s);
				String unicode = "\\u" + hexS;
				sb.append(unicode.toLowerCase());
			}
		}
		return sb.toString();
	}

	/**
	 * unicode 转换成 utf-8
	 * 
	 * @author fanhui 2007-3-15
	 * @param unicodeStr
	 * @return
	 */
	public static String unicodeToUtf8(String unicodeStr) {
		char aChar;
		int len = unicodeStr.length();
		StringBuffer outBuffer = new StringBuffer(len);
		for (int x = 0; x < len;) {
			aChar = unicodeStr.charAt(x++);
			if (aChar == '\\') {
				aChar = unicodeStr.charAt(x++);
				if (aChar == 'u') {
					// Read the xxxx
					int value = 0;
					for (int i = 0; i < 4; i++) {
						aChar = unicodeStr.charAt(x++);
						switch (aChar) {
						case '0':
						case '1':
						case '2':
						case '3':
						case '4':
						case '5':
						case '6':
						case '7':
						case '8':
						case '9':
							value = (value << 4) + aChar - '0';
							break;
						case 'a':
						case 'b':
						case 'c':
						case 'd':
						case 'e':
						case 'f':
							value = (value << 4) + 10 + aChar - 'a';
							break;
						case 'A':
						case 'B':
						case 'C':
						case 'D':
						case 'E':
						case 'F':
							value = (value << 4) + 10 + aChar - 'A';
							break;
						default:
							throw new IllegalArgumentException(
									"Malformed   \\uxxxx   encoding.");
						}
					}
					outBuffer.append((char) value);
				} else {
					if (aChar == 't')
						aChar = '\t';
					else if (aChar == 'r')
						aChar = '\r';
					else if (aChar == 'n')
						aChar = '\n';
					else if (aChar == 'f')
						aChar = '\f';
					outBuffer.append(aChar);
				}
			} else
				outBuffer.append(aChar);
		}
		return outBuffer.toString();
	}

	public static void unicodeToUtf8File(String src) {
		if (FileTool.getInstance().isFileExist(src)) {
			try {
				List<String> contents = FileTool.getInstance()
						.readContentByLine(new FileInputStream(new File(src)));
				if (contents != null) {
					StringBuffer buffer = new StringBuffer();
					for (String content : contents) {
						buffer.append(unicodeToUtf8(content) + "\n");
					}
					FileTool.getInstance().writeData(src + "-utf",
							buffer.toString().getBytes());
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static String unicodeToUtf8Simple(String unicode) {
		String s = null;
		try {
			byte[] utf8 = unicode.getBytes("UTF-8");
			// Convert from UTF-8 to Unicode
			s = new String(utf8, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}

	public static String getPathFromPackage(String packageName) {
		String path = null;
		if (!isNull(packageName)) {
			path = packageName.replace(".", "/");
		}
		return path;
	}
	
	public static boolean isEmail(String email){
		boolean is=false;
		
		if(!isNull(email)){
//			final String emailPattern="/([a-z0-9]*[-_.]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[.][a-z]{2,3}([.][a-z]{2})?/i";
//			final String emailPattern="/([a-z0-9]*[-_.]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[.][a-z]{2,3}([.][a-z]{2})";
			final String emailPattern="^([a-z0-9A-Z]+[-|\\.|_]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
			
			is=!RegExpTool.instance.match(email, emailPattern).isEmpty();
		}
		
		
		return is;
	}
}
