package com.ql.tool;

public class DimensionTool {
	private static DimensionTool instance = new DimensionTool();

	public static DimensionTool getInstance() {
		return instance;
	}

	public boolean isIn(float sx, float sy, float ex, float ey, float dl,
			float dt, float dr, float db) {
		return !(((sx < dl && ex < dl) || (sx > dr) && (ex > dr)) || ((sy < dt && ey < dt) || (sy > db && ey > db)));
	}
}
