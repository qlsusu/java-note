package com.ql.tool;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Printer {
	public static interface PrinterListener {
		public void onLogFinish(String log);
	}

	private PrinterListener listener;

	public void setListener(PrinterListener listener) {
		this.listener = listener;
	}

	public static Printer instance = new Printer();
	private boolean isPrint = false;
	private boolean isLog = false;

	private String printFile;

	public void setPrintFile(String printFile) {
		this.printFile = printFile;
	}

	private ExecutorService threadPool = Executors.newSingleThreadExecutor();

	private Printer() {

	}

	public void setPrint(boolean isPrint) {
		this.isPrint = isPrint;
	}

	public void println(Object msg) {
		if (isPrint) {
			System.out.println(msg);

			if (!StringTool.isNull(printFile)) {
				FileTool.getInstance().writeData(printFile,
						(msg + "\n").getBytes(), true);
			}
		}
	}

	private String logDir;
	private FileOutputStream logFos;
	private long logTime;
	private File logFile;
	private long logFileIndex;

	private final static long MAX_LOG_SIZE = 1024 * 1024 * 1;

	public void startLog(final String logDir) {
		this.logDir = logDir;
		logTime = System.currentTimeMillis();
		if (isLog) {
			threadPool.execute(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					makeLogFile();
				}
			});
		}
	}

	private void makeLogFile() {
		try {
			FileTool.getInstance().mkdirs(logDir);
			logFile = new File(logDir
					+ TimeTool.getInstance().getFullDesc(new Date(logTime))
							.replace(":", ".") + "_" + logFileIndex + ".txt");
			logFileIndex++;
			if (logFos != null) {
				logFos.close();
			}
			logFos = new FileOutputStream(logFile);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setLog(final boolean isLog) {
		threadPool.execute(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Printer.this.isLog = isLog;
			}
		});
	}

	public boolean isLog() {
		return isLog;
	}

	public void forceLog(Object msg) {
		log(msg, true);
	}

	public void log(Object msg) {
		log(msg, false);
	}

	private boolean isLogTimeThread = true;

	public void setLogTimeThread(boolean isLogTimeThread) {
		this.isLogTimeThread = isLogTimeThread;
	}

	public void log(Object msg, final boolean isForce) {
		// 先记录下要打印的东西，防止：
		// 最终打印要在新线程中执行，而msg有可能在被执行时，发生变化
		final String msgString = msg != null ? msg.toString() : null;

		if (msgString != null) {
			final String thread = Thread.currentThread().toString();
			if (isLog || isForce || isPrint) {
				threadPool.submit(new Runnable() {
					@Override
					public void run() {
						// TODO Auto-generated method stub
						if (msgString != null) {
							if (isLog || isForce) {
								try {
									if (logFile == null
											|| (logFile != null && logFile
													.length() >= MAX_LOG_SIZE)) {
										makeLogFile();
									}
									if (logFos != null) {
										logFos.write(((isLogTimeThread ? "["
												+ TimeTool
														.getInstance()
														.getFullDesc(
																new Date(
																		System.currentTimeMillis()))
												+ " " + thread + "]" + " - "
												: "")
												+ msgString + "\n").getBytes());
										logFos.flush();
									}
									if (listener != null) {
										listener.onLogFinish(msgString);
									}
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}

							if (isPrint) {
								println(msgString);
							}
						}
					}
				});
			}
		}
	}

	public void endLog() {
		if (isLog) {
			if (logFos != null) {
				try {
					logFos.close();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public static interface LogBean {
		// 日志样式
		// [2014-08-20 14:34:45 Thread[main,5,main]] - costGetInfobox:11

		public String getHeadField();
	}

	/**
	 * 从日志目录中，得到一个list的logbean
	 * 
	 * @param logDir
	 * @param clz
	 * @return
	 */
	public List<? extends LogBean> getBeanFromLogDir(String logDir,
			Class<? extends LogBean> clz) {
		List<LogBean> beans = new ArrayList<>();

		try {
			File dir = new File(logDir);
			List<File> files = Arrays.asList(dir.listFiles(new FileFilter() {
				@Override
				public boolean accept(File pathname) {
					// TODO Auto-generated method stub
					return pathname.getName().endsWith(".txt");
				}
			}));

			final SimpleDateFormat sdf = new SimpleDateFormat(
					"yyyy-MM-dd HH.mm.ss");
			Collections.sort(files, new Comparator<File>() {
				@Override
				public int compare(File o1, File o2) {
					// TODO Auto-generated method stub
					try {
						long t1 = sdf.parse(
								o1.getName().substring(0,
										o1.getName().indexOf("_"))).getTime();

						long t2 = sdf.parse(
								o2.getName().substring(0,
										o1.getName().indexOf("_"))).getTime();
						if (t1 == t2) {
							String name = o1.getName().replace(".txt", "");
							int num1 = Integer.valueOf(name.substring(name
									.lastIndexOf("_") + 1));

							name = o2.getName().replace(".txt", "");
							int num2 = Integer.valueOf(name.substring(name
									.lastIndexOf("_") + 1));
							return num1 - num2;
						} else {
							return (int) (t1 - t2);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					return 0;
				}
			});

			LogBean bean = clz.newInstance();
			String headField = bean.getHeadField();
			bean = null;
			if (!StringTool.isNull(headField)) {
				for (File f : files) {
					List<String> contents = FileTool.getInstance()
							.readContentByLine(new FileInputStream(f));
					for (String con : contents) {
						try {
							final String endTag = ":";

							int index = con.indexOf(headField);
							if (index != -1) {
								bean = clz.newInstance();
								beans.add(bean);

								String value = con.substring(index
										+ headField.length() + endTag.length());
								Field field = clz.getDeclaredField(headField);
								field.setAccessible(true);
								Object obj = null;
								if (field.getType() == int.class) {
									obj = Integer.valueOf(value);
									field.set(bean, obj);
								} else if (field.getType() == String.class) {
									field.set(bean, value);
								}
							} else if (bean != null) {
								final String splitTag = "]] - ";
								int start = con.indexOf(splitTag);
								if (start != -1) {
									start += splitTag.length();
									int end = con.indexOf(endTag, start + 1);
									if (end != -1) {
										String fieldName = con.substring(start,
												end);
										String value = con.substring(end
												+ endTag.length());
										Field field = clz
												.getDeclaredField(fieldName);
										field.setAccessible(true);
										Object obj = null;
										if (field.getType() == int.class) {
											obj = Integer.valueOf(value);
											field.set(bean, obj);
										} else if (field.getType() == String.class) {
											field.set(bean, value);
										}
									}
								}
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							// e.printStackTrace();
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return beans;
	}
}
