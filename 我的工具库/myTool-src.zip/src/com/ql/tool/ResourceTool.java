package com.ql.tool;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URISyntaxException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



public class ResourceTool {
	private static final Log LOG = LogFactory.getLog(ResourceTool.class);
	
	public static String getClassRootAbsolutePath(String fileName) {
		try {
			if (fileName.startsWith("/")) {
				fileName = fileName.substring(1);
			}

			String path = ResourceTool.class.getClassLoader().getResource("")
					.toURI().getPath();

			path = path.replace("\\", "/");
			if (!path.endsWith("/")) {
				path = path + "/";
			}

			return path + fileName;
		} catch (URISyntaxException e) {

			return "/" + fileName;
		}
	}

	public static InputStream getClassRootFileInputStream(String fileName) {
		try {
			return new FileInputStream(new File(
					getClassRootAbsolutePath(fileName)));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			try {
				if (!fileName.startsWith("/")) {
					fileName = "/" + fileName;
				}
				return ResourceTool.class.getResourceAsStream(fileName);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				LOG.debug(e1.toString());
			}
		}

		return null;
	}

	public static InputStreamReader getClassRootFileInputStreamReader(
			String fileName) {
		try {
			return new InputStreamReader(
					ResourceTool.getClassRootFileInputStream(fileName), "UTF-8");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOG.debug(e.toString());
		}

		return null;
	}

}
