package com.ql.tool;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RandomTool {
	private class EntryGroup {
		private List<String> keys = new ArrayList<String>();
		private List<String> unusedKeys = new ArrayList<String>();

		private String nextKey() {
			if (unusedKeys.isEmpty()) {
				unusedKeys.addAll(keys);
			}

			String key = unusedKeys.get(random.nextInt(unusedKeys.size()));
			unusedKeys.remove(key);

			return key;
		}
	}

	public interface RandomEntry {
		public String getKey();
	}

	private static RandomTool instance = new RandomTool();
	private List<EntryGroup> groups = new ArrayList<RandomTool.EntryGroup>();
	private Random random;

	private RandomTool() {
		random = new Random();
	}

	public static RandomTool getInstance() {
		return instance;
	}

	// public int nextInt(int size) {
	// return random.nextInt(size);
	// }

	public RandomEntry nextEntry(List<? extends RandomEntry> entries) {
		if (entries != null) {
			List<String> keys = new ArrayList<String>();

			for (RandomEntry entry : entries) {
				keys.add(entry.getKey());
			}

			EntryGroup group = findGroup(keys);
			String key = group.nextKey();

			for (RandomEntry entry : entries) {
				if (entry.getKey().equals(key)) {
					return entry;
				}
			}
		}

		return null;
	}

	private EntryGroup findGroup(List<String> keys) {
		EntryGroup group = null;

		boolean isNextCheck;
		if (keys != null) {
			for (EntryGroup g : groups) {
				isNextCheck = false;
				if (g.keys.size() == keys.size()) {
					for (String gk : g.keys) {
						if (!keys.contains(gk)) {
							isNextCheck = true;
							break;
						}
					}
					if (isNextCheck) {
						continue;
					}
					for (String k : keys) {
						if (!g.keys.contains(k)) {
							isNextCheck = true;
							break;
						}
					}
					if (isNextCheck) {
						continue;
					} else {
						group = g;
						break;
					}
				}
			}
		}

		if (group == null) {
			group = new EntryGroup();
			group.keys.addAll(keys);
			groups.add(group);
		}

		return group;
	}

	// public int nextInt(int size) {
	// return random.nextInt(size);
	// }

	public boolean isMeetProbability(int meetNum, int totalNum) {
		return random.nextInt(totalNum) <= (meetNum - 1);
	}

	/**
	 * 从一个list中随机筛选出一部分<br>
	 * 当datas.size<=size时，返回datas本身
	 * 
	 * @param datas
	 * @param size
	 * @return
	 */
	public List<Object> subList(List<Object> datas, int size) {
		List<Object> sub = new ArrayList<>();

		if (!datas.isEmpty()) {
			if (datas.size() <= size) {
				sub = datas;
			} else {
				List<Object> copy = new ArrayList<>();
				copy.addAll(datas);
				for (int i = 0; i < size; i++) {
					sub.add(copy.remove(random.nextInt(copy.size())));
				}
			}
		}

		return sub;
	}

	public int getNumber(int range) {
		return random.nextInt(range);
	}
}
