package com.ql.tool;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.ql.tool.NetTool.NetToolListener;

/**
 * 使用google的stt
 * 
 * @author bill
 * 
 */
public class SttGoogleTool {
	public static interface TtsGoogleToolListener {
		public void onGetText(String text);
	}

	public static class TtsGoogleResult {
		private int status;
		private String id;
		private List<Hypothese> hypotheses = new ArrayList<SttGoogleTool.Hypothese>();

		public int getStatus() {
			return status;
		}

		public String getId() {
			return id;
		}

		public List<Hypothese> getHypotheses() {
			return hypotheses;
		}

	}

	public static class Hypothese {
		private String utterance;
		private double confidence;

		public String getUtterance() {
			return utterance;
		}

		public double getConfidence() {
			return confidence;
		}

	}

	private static SttGoogleTool instance = new SttGoogleTool();

	// private final static String key =
	// "AIzaSyCzksEhvdvrAZRq8NjiAkwzmvigMLZ5w7k";
	// private final static String key =
	// "AIzaSyCDsOKzXR45D-oTMeXx1V5tNaQm6iAa4Lk";

	private final static String key = "AIzaSyBHDrl33hwRp4rMQY0ziRbj8K9LPA6vUCY";

	// private final static String key =
	// "AIzaSyCnl6MRydhw_5fLXIdASxkLJzcJh5iX0M4";

	private final static String STT_GOOGLE_URL = "http://www.google.com/speech-api/v2/recognize?xjerr=1&client=chromium&key="
			+ key + "&lang=";

	// private final static String STT_GOOGLE_URL =
	// "http://www.google.com/speech-api/v2/recognize?xjerr=1&client=chromium&lang=";

	private SttGoogleTool() {

	}

	public static SttGoogleTool getInstance() {
		return instance;
	}

	public void getText(String wav, String lang,
			final TtsGoogleToolListener listener) {
		NetTool net = new NetTool();
		net.addListener(new NetToolListener() {
			@Override
			public void netOperationSuccess(byte[] response) {
				// TODO Auto-generated method stub
				TtsGoogleResult result = (TtsGoogleResult) JsonTool.instance
						.toObject(new String(response), TtsGoogleResult.class);
				if (result != null) {
					List<Hypothese> hys = result.getHypotheses();
					if (!hys.isEmpty()) {
						Collections.sort(hys, new Comparator<Hypothese>() {
							@Override
							public int compare(Hypothese lhs, Hypothese rhs) {
								// TODO Auto-generated method stub
								int comp = -1;
								if (lhs.confidence - rhs.confidence > 0) {
									comp = 1;
								} else if (lhs.confidence == rhs.confidence) {
									comp = 0;
								} else {
									comp = -1;
								}
								return comp;
							}
						});
						if (listener != null
								&& !StringTool.isNull(hys.get(0).utterance)) {
							listener.onGetText(hys.get(0).utterance);
						}
					}
				}
			}

			@Override
			public void netOperationFail() {
				// TODO Auto-generated method stub

			}

			@Override
			public void netError() {
				// TODO Auto-generated method stub

			}
		});
		net.sendData(STT_GOOGLE_URL + lang, wav);
	}
}
