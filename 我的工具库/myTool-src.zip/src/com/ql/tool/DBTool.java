package com.ql.tool;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mchange.v2.c3p0.DataSources;

public final class DBTool {
	private static final Log LOG = LogFactory.getLog(DBTool.class);

	private DataSource ds;

	private DBTool() {
		Map<String, String> map = PropertiesTool.instance
				.getKvFromResource("druid-config.properties");

		Properties properties = new Properties();
		for (Entry<String, String> entry : map.entrySet()) {
			properties.put(entry.getKey(), entry.getValue());
		}
		try {
//			ds = DruidDataSourceFactory.createDataSource(properties);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static DBTool instance = new DBTool();

	public static final DBTool getInstance() {
		return instance;
	}

	public synchronized final Connection getConnection() {
		Connection connection = null;
		try {
			connection = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	/**
	 * 创建表<br>
	 * 以itemid的 incre*10000 进行分割
	 * 
	 * @param tablePrefix
	 */
	public void executeSqlFileWithTable(String sqlFile, List<String> tables) {
		if (FileTool.getInstance().isFileExist(sqlFile) && tables != null) {
			String sqlOriginal = new String(FileTool.getInstance().readContent(
					sqlFile));

			final String tableTag = "{tableName}";
			for (String table : tables) {
				String sql = sqlOriginal.replace(tableTag, table);
				LOG.debug(sql);

				Connection conn = getConnection();
				Statement statement = null;

				try {
					statement = conn.createStatement();
					statement.execute(sql);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					LOG.debug(e.toString());
				} finally {
					close(conn, statement, null);
				}
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					LOG.debug(e.toString());
				}
			}
		}
	}

	protected synchronized final void destroy() {
		try {
			DataSources.destroy(ds);
		} catch (SQLException e) {
			// TODO
		}
	}

	public void close(Connection conn) {
		close(conn, null, null);
	}

	public void close(Statement statement) {
		DbUtils.closeQuietly(statement);
	}

	public void close(ResultSet rs) {
		DbUtils.closeQuietly(rs);
	}

	public void close(Connection conn, Statement statement, ResultSet rs) {
		DbUtils.closeQuietly(conn, statement, rs);
	}

}
