package com.ql.tool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

/**
 * 将一个.properties文件变成一个对象。允许文件中出现嵌套，允许出现{xx}
 * 
 * @author qilu
 * 
 */
public class PropertiesTool {
	public static PropertiesTool instance = new PropertiesTool();

	private PropertiesTool() {

	}

	public Properties getProperties(String file) {
		Properties p = null;
		try {
			p = new Properties();
			p.load(FileTool.getInstance().getFileInputStream(file));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return p;
	}

	public Properties getProperties(File file) {
		Properties p = null;
		try {
			p = new Properties();
			p.load(new FileInputStream(file));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return p;
	}

	public Properties getPropertiesFromResource(String file) {
		Properties p = null;
		try {
			p = new Properties();
			p.load(FileTool.getInstance().getResourceInput(file));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return p;
	}

	public Map<String, String> getKvFromResource(String res) {
		Map<String, String> kv = new HashMap<>();

		Map<String, List<String>> kvs = getKvsFromResource(res);
		if (kvs != null && !kvs.isEmpty()) {
			for (Entry<String, List<String>> entry : kvs.entrySet()) {
				List<String> values = entry.getValue();
				if (values != null && !values.isEmpty()) {
					kv.put(entry.getKey(), values.get(0));
				}
			}
		}

		return kv;
	}

	/**
	 * 获得key-value，从res中<br>
	 * 支持value是[]的情况，如：key=[v1,v2]
	 * 
	 * @param res
	 * @return
	 */
	public Map<String, List<String>> getKvsFromResource(String res) {
		Map<String, List<String>> map = new HashMap<>();
		if (!StringTool.isNull(res)) {
			try {
				BufferedReader reader = new BufferedReader(
						ResourceTool.getClassRootFileInputStreamReader(res));
				String data = null;
				while ((data = reader.readLine()) != null) {
					if (!StringTool.isNull(data) && !data.startsWith("#")) {
						List<String> values = new ArrayList<>();

						String[] kv = new String[2];
						int index = data.indexOf("=");
						kv[0] = data.substring(0, index);
						kv[1] = data.substring(index + 1);
						final String startTag = "[";
						final String endTag = "]";
						String valuesStr = kv[1].startsWith(startTag)
								&& kv[1].endsWith(endTag) ? kv[1].substring(
								startTag.length(),
								kv[1].length() - endTag.length()) : kv[1];
						values = new ArrayList<>(Arrays.asList(valuesStr
								.split(",")));
						map.put(kv[0], values);
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return map;
	}

	public Object toBean(String file, Class<?> clz) {
		Object obj = null;
		if (!StringTool.isNull(file)) {
			obj = toBean(FileTool.getInstance().getFileInputStream(file), clz,
					null);
		}
		return obj;
	}

	public Object toBean(String file, Object src) {
		Object obj = null;
		if (!StringTool.isNull(file)) {
			obj = toBean(FileTool.getInstance().getFileInputStream(file),
					src.getClass(), src);
		}
		return obj;
	}

	public Object toBeanFromResource(String file, Class<?> clz) {
		Object obj = null;
		if (!StringTool.isNull(file)) {
			obj = toBean(FileTool.getInstance().getResourceInput(file), clz,
					null);
		}
		return obj;
	}

	public Object toBean(InputStream is, Class<?> clz, Object src) {
		Object obj = src;

		if (is != null && clz != null) {
			try {
				Properties p = new Properties();
				p.load(is);
				for (Object key : p.keySet()) {
					ArrayList<String> list = new ArrayList<String>();
					String kStr = key.toString();
					int start = 0;
					int end = -1;
					while ((end = kStr.indexOf(".", start)) != -1) {
						list.add(kStr.substring(start, end));
						start = end + 1;
					}
					list.add(kStr.substring(start));

					if (obj == null) {
						obj = clz.newInstance();
					}
					/**
					 * 存在的目的是：obj可能会变成src的成员变量对象
					 */
					Object obj2 = obj;

					for (int i = 0; i < list.size() - 1; i++) {
						obj = generateObj(list.get(i), obj);
					}
					setField(list.get(list.size() - 1), p.getProperty(kStr),
							obj, p);
					obj = obj2;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return obj;
	}

	private Object generateObj(String field, Object obj) {
		Object target = null;
		try {
			Field f = getField(field, obj.getClass());
			if ((target = f.get(obj)) == null) {
				target = f.getType().newInstance();
				f.set(obj, target);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return target;
	}

	/**
	 * 获得field，从public（自己的，或者是继承自父亲的）或者是private中
	 * 
	 * @param name
	 * @param clz
	 * @return
	 */
	private Field getField(String name, Class<?> clz) {
		Field f = null;
		try {
			f = clz.getField(name);
		} catch (Exception e) {
			try {
				f = clz.getDeclaredField(name);
				f.setAccessible(true);
			} catch (Exception e1) {
			}
		}
		return f;
	}

	/**
	 * 设置field的值
	 * 
	 * @param name
	 * @param value
	 * @param obj
	 * @param p
	 *            为了将value中的{xx}变为真实的值
	 */
	@SuppressWarnings("unchecked")
	private void setField(String name, String value, Object obj, Properties p) {
		try {
			/**
			 * 将value中的{xx}变为真实的值
			 */
			if (!StringTool.isNull(value)) {
				while (true) {
					int start = -1;
					int end = -1;
					start = value.indexOf("{");
					end = value.indexOf("}", start);
					if (end == -1) {
						break;
					} else {
						String sub = value.substring(start + 1, end);
						value = value.replace("{" + sub + "}",
								p.getProperty(sub));
					}
				}
			}

			Field f = getField(name, obj.getClass());
			if (f != null) {
				if (value.contains("[")) {
					List<String> list = (List<String>) f.get(obj);
					value = value.substring(1, value.length() - 1);
					String[] ss = value.split(",");
					for (String s : ss) {
						list.add(s.trim());
					}
				} else {
					/**
					 * 暂时只允许value的值类型为string,int,long
					 */
					String type = f.getType().getName();
					Object vObj = null;
					if (type.equals("java.lang.String")) {
						vObj = value;
					} else if (type.equals("int")) {
						vObj = Integer.valueOf(value);
					} else if (type.equals("long")) {
						vObj = Long.valueOf(value);
					}
					f.set(obj, vObj);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Map<String, List<String>> getKvsMap(String res) {
		Map<String, List<String>> map = new HashMap<>();
		if (!StringTool.isNull(res)) {
			try {
				BufferedReader reader = new BufferedReader(
						ResourceTool.getClassRootFileInputStreamReader(res));
				String data = null;
				while ((data = reader.readLine()) != null) {
					if (!StringTool.isNull(data)) {
						List<String> values = new ArrayList<>();

						String[] kv = data.split("=");
						String valuesStr = kv[1].substring(1,
								kv[1].length() - 1);
						values = Arrays.asList(valuesStr.split(","));
						map.put(kv[0], values);
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return map;
	}
}
