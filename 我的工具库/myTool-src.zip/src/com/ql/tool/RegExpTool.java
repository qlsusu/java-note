package com.ql.tool;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExpTool {
	public static RegExpTool instance = new RegExpTool();

	public List<String> match(String source, String exp) {
		List<String> contents = new ArrayList<>();

		if (!StringTool.isNull(source) && !StringTool.isNull(exp)) {
			Pattern r = Pattern
					.compile(exp, Pattern.MULTILINE | Pattern.DOTALL);
			Matcher m = r.matcher(source);
			while (m.find()) {
				contents.add(m.group());
			}
		}

		return contents;
	}

	public List<String> match(String source, String startTag, String endTag,
			boolean isContainsEdge) {
		List<String> contents = new ArrayList<>();

		if (!StringTool.isNull(source) && !StringTool.isNull(startTag)
				&& !StringTool.isNull(endTag)) {
			int startTagLength = startTag.length();
			int endTagLength = endTag.length();

			final Map<String, String> replaceMap = new HashMap<>();
			replaceMap.put("{", "\\{");
			replaceMap.put("}", "\\}");
			replaceMap.put("[", "\\[");
			replaceMap.put("]", "\\]");
			replaceMap.put("|", "\\|");

			for (String key : replaceMap.keySet()) {
				startTag = startTag.replace(key, replaceMap.get(key));
				endTag = endTag.replace(key, replaceMap.get(key));
			}
			String exp = startTag + ".+?" + endTag;
			contents = match(source, exp);

			if (!isContainsEdge) {
				for (int i = 0; i < contents.size(); i++) {
					String content = contents.get(i);

					contents.set(
							i,
							content.substring(startTagLength, content.length()
									- endTagLength));
				}
			}
		}

		return contents;
	}
}
