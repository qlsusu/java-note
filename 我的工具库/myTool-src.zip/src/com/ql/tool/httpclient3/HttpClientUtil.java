package com.ql.tool.httpclient3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ql.tool.StringTool;

/**
 * 
 * <p>
 * Title: HttpClientUtil.java
 * </p>
 * 
 * <p>
 * Description: HTTP methods API
 * </p>
 * 
 * @company Samsung Electronics(China) R & D Center
 * 
 * @author wangpeng
 * 
 * @date Aug 23, 2013 11:36:30 AM
 * 
 * @version 1.0
 */
public class HttpClientUtil {
	private static final Log LOG = LogFactory.getLog(HttpClientUtil.class);

	private static MultiThreadedHttpConnectionManager connectionManager = new MultiThreadedHttpConnectionManager();

	// Since the Configuration has not yet been set, then an unconfigured client
	// is returned.
	private static HttpClient httpClient = new HttpClient(connectionManager);

	static {
		HttpConnectionManagerParams params = connectionManager.getParams();
		// Set the timeout of per connection's creating
		params.setConnectionTimeout(1000 * 60 * 3);
		// Set the timeout of reading data
		params.setSoTimeout(1000 * 60 * 3);
		params.setSendBufferSize(8 * 1024);
		params.setReceiveBufferSize(8 * 1024);
		params.setMaxTotalConnections(20);

		// executeMethod(HttpMethod) seems to ignore the connection timeout on
		// the connection manager.
		// set it explicitly on the HttpClient.
		httpClient.getParams().setConnectionManagerTimeout(1000 * 60 * 3);

		HostConfiguration hostConf = httpClient.getHostConfiguration();

		List<Header> headers = new ArrayList<Header>();

		// Set the User Agent in the header
		headers.add(new Header("User-Agent",
				"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)"));

		// prefer English
		headers.add(new Header("Accept-Language",
				"en-us,en-gb,en;q=0.7,*;q=0.3"));

		// prefer UTF-8
		headers.add(new Header("Accept-Charset",
				"utf-8,ISO-8859-1;q=0.7,*;q=0.7"));

		// prefer understandable formats
		headers.add(new Header(
				"Accept",
				"text/html,application/xml;q=0.9,application/xhtml+xml,text/xml;q=0.9,text/plain;q=0.8,*/*;q=0.5"));

		// accept gzipped contents which only support x-gzip, gzip, deflate,
		// maybe extend others later
		headers.add(new Header("Accept-Encoding",
				"x-gzip, gzip, deflate;q=1.0, identity; q=0.5, *;q=0"));

		hostConf.getParams().setParameter("http.default-headers", headers);
	}

	public static void setProxy(String host, int port) {
		setProxy(host, port, null, null);
	}

	public static void setProxy(String host, int port, String user,
			String password) {
		// 设置代理服务器的ip地址和端口
		httpClient.getHostConfiguration().setProxy(host, port);
		// 使用抢先认证
		httpClient.getParams().setAuthenticationPreemptive(true);
		if (!StringTool.isNull(user) && !StringTool.isNull(password)) {
			// 如果代理需要密码验证，这里设置用户名密码
			httpClient.getState().setProxyCredentials(AuthScope.ANY,
					new UsernamePasswordCredentials(user, password));
		}
	}

	public static synchronized String get(String url) {
		String response = "";

		GetMethod get = new GetMethod(url);

		/**
		 * Sets whether or not the HTTP method should automatically follow HTTP
		 * redirects (status code 302, etc.)
		 */
		get.setFollowRedirects(true);

		/**
		 * Sets whether or not the HTTP method should automatically handle HTTP
		 * authentication challenges (status code 401, etc.)
		 */
		get.setDoAuthentication(true);

		// Set HTTP parameters
		HttpMethodParams params = get.getParams();

		params.makeLenient();
		params.setContentCharset("UTF-8");
		params.setCookiePolicy(CookiePolicy.BROWSER_COMPATIBILITY);
		params.setBooleanParameter(HttpMethodParams.SINGLE_COOKIE_HEADER, true);
		/**
		 * Not sure about this... the default is to retry 3 times; if the
		 * request body was sent the method is not retried, so there is little
		 * danger in retrying...
		 */
		// params.setParameter(HttpMethodParams.RETRY_HANDLER, null);

		try {
			int code = httpClient.executeMethod(get);
			byte[] content = get.getResponseBody();
			if (get != null) {
				get.abort();
			}

			Header[] heads = get.getResponseHeaders();
			Map<String, String> headers = new HashMap<String, String>();
			for (int i = 0; i < heads.length; i++) {
				headers.put(heads[i].getName().toLowerCase(),
						heads[i].getValue());
			}

			// Extract gzip, x-gzip and deflate content
			if (content != null && code == HttpStatus.SC_OK) {
				// check if we have to uncompress it
				String contentEncoding = headers.get("Content-Encoding"
						.toLowerCase());
				if ("gzip".equals(contentEncoding)
						|| "x-gzip".equals(contentEncoding)) {
					content = processGzipEncoded(content);

				} else if ("deflate".equals(contentEncoding)) {
					content = processDeflateEncoded(content);
				}

				String charset = get.getResponseCharSet();
				if (StringTool.isNull(charset)) {
					charset = "UTF-8";
				}
				response = new String(content, charset);
			}
		} catch (HttpException e) {
			LOG.error(e == null ? "NULL" : e.getMessage(), e);
		} catch (IOException e) {
			LOG.error(e == null ? "NULL" : e.getMessage(), e);
		} finally {
			if (get != null) {
				get.releaseConnection();
			}
		}

		return response;
	}

	@SuppressWarnings("deprecation")
	public static synchronized String post(String url, byte[] bs) {
		String response = "";

		PostMethod post = new PostMethod(url);

		/**
		 * Sets whether or not the HTTP method should automatically follow HTTP
		 * redirects (status code 302, etc.)
		 */
		// post.setFollowRedirects(true);

		/**
		 * Sets whether or not the HTTP method should automatically handle HTTP
		 * authentication challenges (status code 401, etc.)
		 */
		post.setDoAuthentication(true);

		// Set HTTP parameters
		HttpMethodParams params = post.getParams();

		params.makeLenient();
		params.setContentCharset("UTF-8");
		params.setCookiePolicy(CookiePolicy.BROWSER_COMPATIBILITY);
		params.setBooleanParameter(HttpMethodParams.SINGLE_COOKIE_HEADER, true);
		/**
		 * Not sure about this... the default is to retry 3 times; if the
		 * request body was sent the method is not retried, so there is little
		 * danger in retrying...
		 */
		// params.setParameter(HttpMethodParams.RETRY_HANDLER, null);

		try {
			String req = new String(bs, "UTF-8");
			post.setRequestBody(req);

			int code = httpClient.executeMethod(post);
			byte[] content = post.getResponseBody();
			if (post != null) {
				post.abort();
			}

			Header[] heads = post.getResponseHeaders();
			Map<String, String> headers = new HashMap<String, String>();
			for (int i = 0; i < heads.length; i++) {
				headers.put(heads[i].getName().toLowerCase(),
						heads[i].getValue());
			}

			// Extract gzip, x-gzip and deflate content
			if (content != null && code == HttpStatus.SC_OK) {
				// check if we have to uncompress it
				String contentEncoding = headers.get("Content-Encoding"
						.toLowerCase());
				if ("gzip".equals(contentEncoding)
						|| "x-gzip".equals(contentEncoding)) {
					content = processGzipEncoded(content);

				} else if ("deflate".equals(contentEncoding)) {
					content = processDeflateEncoded(content);
				}

				String charset = post.getResponseCharSet();
				if (StringTool.isNull(charset)) {
					charset = "UTF-8";
				}
				response = new String(content, charset);
			}

		} catch (HttpException e) {
			// LOG.error(e == null ? "NULL" : e.getMessage(), e);
		} catch (IOException e) {
			// LOG.error(e == null ? "NULL" : e.getMessage(), e);
		} finally {
			if (post != null) {
				post.releaseConnection();
			}
		}

		return response;

	}

	/** gzipped-contents(x-gzip, gzip) uncompressed */
	private static byte[] processGzipEncoded(byte[] compressed)
			throws IOException {

		return GZIPUtils.unzipBestEffort(compressed);
	}

	/** gzipped-contents(deflate) uncompressed */
	private static byte[] processDeflateEncoded(byte[] compressed)
			throws IOException {
		return DeflateUtils.inflateBestEffort(compressed);
	}

	public static void main(String[] argv) {
		try {

			System.out
					.println(HttpClientUtil
							.get("http://conceptnet5.media.mit.edu/data/5.2/search?startLemmas=keyboard&endLemmas=computer"));
		} catch (Exception e) {
			LOG.error("Main test error", e);
		}

	}
}
