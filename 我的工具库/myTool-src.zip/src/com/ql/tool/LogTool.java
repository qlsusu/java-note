package com.ql.tool;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogTool {
	public static LogTool instance = new LogTool();
	private BufferedWriter writer;
	private SimpleDateFormat format;

	private LogTool() {

	}

	public void init(String path) {
		try {
			File f = new File(path);
			if (!f.exists()) {
				f.createNewFile();
			}
			writer = new BufferedWriter(new FileWriter(f));
			format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void log(String content) {
		/**
		 * currently, if writer is null, we don't log any thing, which mean we
		 * turn off logging logic
		 */
		if (writer != null) {
			try {
				writer.write("["
						+ format.format(new Date(System.currentTimeMillis()))
						+ "]:");
				writer.write(content + "\n");
				writer.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void close() {
		try {
			if (writer != null) {
				writer.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
