package com.ql.tool;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * A utility for handler xml such as transforming xml data to bean
 * 
 * @author qilu
 * 
 */
public class XmlToolW3C {
	private static XmlToolW3C instance = new XmlToolW3C();

	private XmlToolW3C() {

	}

	public static XmlToolW3C getInstance() {
		return instance;
	}

	public Object toBean(String file, Class<?> clz, Object src) {
		if (!StringTool.isNull(file) && new File(file).exists()) {
			try {
				return toBean(new FileInputStream(file), clz, src);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}

	public Object toBean(InputStream is, Class<?> clz, Object src) {
		try {
			return toBean(DocumentBuilderFactory.newInstance()
					.newDocumentBuilder().parse(is).getDocumentElement(), clz,
					src);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Parse the element to generate an instance of a class named clz. If the
	 * src is not null, just update its property. Recursion has been considered.
	 * 
	 * @param e
	 * @param clz
	 * @param src
	 * 
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Object toBean(Element e, Class<?> clz, Object src) {
		if (src == null) {
			if (clz == null) {
				return null;
			}
			try {
				src = clz.newInstance();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else {
			clz = src.getClass();
		}

		NodeList nodeList = e.getChildNodes();
		List<Element> eList = new ArrayList<Element>();
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node n = nodeList.item(i);
			if (n.getNodeType() == Node.ELEMENT_NODE) {
				eList.add((Element) n);
			}
		}

		for (Element e1 : eList) {
			String name = e1.getNodeName();
			Field f = null;
			List<Field> fs = new ArrayList<Field>();
			for (Field field : clz.getDeclaredFields()) {
				fs.add(field);
			}
			for (Field field : clz.getSuperclass().getDeclaredFields()) {
				fs.add(field);
			}
			for (Field field : fs) {
				field.setAccessible(true);
				if (field.getName().toLowerCase().equals(name.toLowerCase())) {
					f = field;
				}
			}
			if (f != null) {
				try {
					Class<?> eleClz = null;
					if (f.getType() == List.class) {
						List list = (List) f.get(src);
						if ((eleClz = (Class<?>) ((ParameterizedType) f
								.getGenericType()).getActualTypeArguments()[0]) != String.class) {
							nodeList = e1.getChildNodes();
							List<Element> eList2 = new ArrayList<Element>();
							for (int i = 0; i < nodeList.getLength(); i++) {
								Node n = nodeList.item(i);
								if (n.getNodeType() == Node.ELEMENT_NODE
										&& n.getNodeName().trim()
												.equals(eleClz.getSimpleName())) {
									eList2.add((Element) n);
								}
							}
							for (Element e2 : eList2) {
								list.add(toBean(e2, eleClz, null));
							}
						} else {
							String content = e1.getTextContent().trim();
							if (content.startsWith("[")
									&& content.endsWith("]")) {
								String[] ss = content.substring(1,
										content.length() - 1).split(",");
								for (String s : ss) {
									list.add(s.trim());
								}
							}
						}
					} else if (f.getType() == String.class) {
						f.set(src, e1.getTextContent().trim());
					} else if (f.getType().isPrimitive()) {
						String s = e1.getChildNodes().item(0).getNodeValue()
								.trim();
						if (f.getType() == int.class) {
							f.set(src, Integer.valueOf(s));
						} else if (f.getType() == long.class) {
							f.set(src, Long.valueOf(s));
						} else if (f.getType() == float.class) {
							f.set(src, Float.valueOf(s));
						} else if (f.getType() == double.class) {
							f.set(src, Double.valueOf(s));
						} else if (f.getType() == boolean.class) {
							f.set(src, s.toLowerCase().equals("true") ? true
									: false);
						}
					} else if (f.getType() != byte[].class) {
						f.set(src, toBean(e1, f.getType(), null));
					}
				} catch (Exception e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
			}
		}
		return src;
	}

	public String toXml(Object o) {
		return toXml(o, null);
	}

	/**
	 * transform the bean to XML content
	 * 
	 * @param o
	 * @param clzPropMapping
	 *            the property of the bean class which needs to participate the
	 *            transforming job. If it is null or empty, all the properties
	 *            participate. Recursion has been considered.
	 * @return
	 */
	public String toXml(Object o, Map<Class<?>, List<String>> clzPropMapping) {
		try {
			if (o != null) {
				StringBuffer buf = new StringBuffer();
				Class<?> clz = o.getClass();
				List<String> prop = null;
				List<String> allProp = new ArrayList<String>();
				for (Field f : clz.getDeclaredFields()) {
					f.setAccessible(true);
					allProp.add(f.getName());
				}

				if (clzPropMapping != null) {
					prop = clzPropMapping.get(clz);
					if (prop == null || prop.isEmpty()) {
						prop = allProp;
					}
				} else {
					prop = allProp;
				}
				buf.append("<" + clz.getSimpleName() + ">");
				for (String p : prop) {
					Field f = clz.getDeclaredField(p);
					f.setAccessible(true);
					Object oProp = f.get(o);
					if (oProp != null) {
						buf.append("<" + p + ">");
						if (f.getType() == List.class) {
							if (((ParameterizedType) f.getGenericType())
									.getActualTypeArguments()[0] != String.class) {
								List<?> list = (List<?>) oProp;
								for (Object e : list) {
									String s = toXml(e, clzPropMapping);
									if (!StringTool.isNull(s)) {
										buf.append(s);
									}
								}
							} else {
								buf.append(oProp.toString());
							}
						} else if (f.getType().isPrimitive()
								|| f.getType() == String.class) {
							String value = "";
							if (!oProp.equals("")) {
								value = oProp.toString();
								value = StringTool.becomeXmlSpecialChar(value);
							}
							buf.append(value);
						} else {
							String s = toXml(oProp, clzPropMapping);
							/**
							 * delete the prop's clz.getSimpleName() tag
							 */
							if (!StringTool.isNull(s)) {
								s = s.substring(s.indexOf('>') + 1,
										s.lastIndexOf('<'));
								buf.append(s);
							}
						}
						buf.append("</" + p + ">");
					}
				}
				buf.append("</" + clz.getSimpleName() + ">");
				return buf.toString();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
