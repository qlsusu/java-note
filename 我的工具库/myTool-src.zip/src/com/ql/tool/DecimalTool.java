package com.ql.tool;

import java.math.BigDecimal;

public class DecimalTool {
	private DecimalTool() {

	}

	private static DecimalTool instance = new DecimalTool();

	public static DecimalTool getInstance() {
		return instance;
	}

	/**
	 * 精确到小数点后几位
	 * 
	 * @param value
	 * @param afterDot
	 * @return
	 */
	public double precision(double value, int afterDot) {
		// 如果是后几位，可以采用这种方式
		// String format = "0";
		// if (afterDot > 0) {
		// format += ".";
		// for (int i = 0; i < afterDot; i++) {
		// format += "0";
		// }
		// }
		//
		// DecimalFormat df = new DecimalFormat(format);
		// return Double.valueOf(df.format(value));
		BigDecimal b = new BigDecimal(value);
		return b.setScale(afterDot, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	public int getDotSize(double value) {
		int valueInt = (int) value;
		if (valueInt != value) {
			String s = value + "";
			int index = s.indexOf(".");
			if (index != -1) {
				return s.substring(index + 1).length();
			}

		}
		return 0;
	}

	/**
	 * 获得16进制字符串
	 * 
	 * @param num
	 * @return
	 */
	public String getHexString(int num) {
		return Integer.toHexString(num);
	}

	/**
	 * 获得8进制字符串
	 * 
	 * @param num
	 * @return
	 */
	public String getOctalString(int num) {
		return Integer.toOctalString(num);
	}

	/**
	 * 获得2进制字符串
	 * 
	 * @param num
	 * @return
	 */
	public String getBinaryString(int num) {
		return Integer.toBinaryString(num);
	}

	public int getNumFromHexString(String s) {
		int num = -1;
		if (!StringTool.isNull(s)) {
			num = Integer.parseInt(s, 16);
		}
		return num;
	}

	public int getNumFromOctalString(String s) {
		int num = -1;
		if (!StringTool.isNull(s)) {
			num = Integer.parseInt(s, 8);
		}
		return num;
	}

	public int getNumFromBinaryString(String s) {
		int num = -1;
		if (!StringTool.isNull(s)) {
			num = Integer.parseInt(s, 2);
		}
		return num;
	}
}
