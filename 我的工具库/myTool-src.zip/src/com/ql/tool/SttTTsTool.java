package com.ql.tool;

import java.util.ArrayList;
import java.util.List;

public abstract class SttTTsTool {
	public static interface SttListener {
		/**
		 * 获取了所有的text后的回调
		 * 
		 * @param text
		 */
		public void onGetText(String text);
	}

	public static interface TtsListener {
		public void onPlayPercent(String text, int percent);

		public void onPlayBegin(String text);

		public void onPlayFinish(String text);
	}

	/**
	 * stt
	 * 
	 * @param extra
	 *            协助stt的额外信息，可为空
	 * @return 如果为同步方式，返回，speech对应的text<br>
	 *         如果是异步方式，可为空
	 */
	public abstract String stt(Object extra);

	public abstract void tts(final String text);

	protected SttListener sttListener;

	public void setSttListener(SttListener sttListener) {
		this.sttListener = sttListener;
	}

	protected List<TtsListener> ttsListeners = new ArrayList<SttTTsTool.TtsListener>();

	public void addTtsListener(TtsListener ttsListener) {
		if (ttsListener != null) {
			synchronized (ttsListeners) {
				ttsListeners.add(ttsListener);
			}
		}
	}

	public void removeTtsListener(TtsListener ttsListener) {
		if (ttsListener != null) {
			synchronized (ttsListeners) {
				ttsListeners.remove(ttsListener);
			}
		}
	}
}
