package com.ql.tool;

import java.io.ByteArrayInputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Formatter;
import java.util.Locale;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.ql.tool.NetTool.NetToolListener;

public class TimeTool {
	private static TimeTool instance = new TimeTool();

	private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	private SimpleDateFormat fulFormat = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss");
	public static final long A_DAY_LONG = 1000 * 60 * 60 * 24;
	public static final int TYPE_DAY = 1;
	public static final int TYPE_DAY_MONTH = 2;
	public static final int TYPE_DAY_MONTH_YEAR = 3;
	public static final int TYPE_MONTH = 4;
	public static final int TYPE_MONTH_YEAR = 5;
	public static final int TYPE_YEAR = 6;

	private TimeTool() {

	}

	public static TimeTool getInstance() {
		return instance;
	}

	public Date get24HoursLaterOrEarlier(Date now, boolean isNext) {
		Date date = null;

		long time = isNext ? now.getTime() + A_DAY_LONG : now.getTime()
				- A_DAY_LONG;
		date = new Date(time);
		return date;
	}

	public Date getNextDay(Date now, boolean isNext) {
		return getDate(getDesc(get24HoursLaterOrEarlier(now, true),
				TYPE_DAY_MONTH_YEAR));
	}

	public String getTodayDesc() {
		return getDesc(new Date(System.currentTimeMillis()),
				TYPE_DAY_MONTH_YEAR);
	}

	public String getDesc() {
		return getDesc(new Date());
	}

	public String getDesc(Date date) {
		return getDesc(date, TYPE_DAY_MONTH_YEAR);
	}

	public String getDesc(Date date, int type) {
		String str = format.format(date);
		String[] array = str.split("-");
		String desc = null;
		switch (type) {
		case TYPE_DAY_MONTH_YEAR:
			desc = str;
			break;
		case TYPE_MONTH:
			desc = array[1];
			break;
		case TYPE_MONTH_YEAR:
			desc = array[0] + "-" + array[1];
			break;
		case TYPE_YEAR:
			desc = array[0];
			break;
		default:
			break;
		}
		return desc;
	}

	public String getFullDesc() {
		return getFullDesc(new Date());
	}

	public String getFullDesc(Date date) {
		return fulFormat.format(date);
	}

	public Date getDate(String str) {
		Date date = null;
		try {
			date = format.parse(str);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return date;
	}

	public Date getDateFromFullDesc(String str) {
		Date date = null;
		try {
			date = fulFormat.parse(str);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return date;
	}

	// 获取时间，对应今天0点0分
	public Date getTodayBegin() {
		return getDate(getDesc(new Date(System.currentTimeMillis()),
				TYPE_DAY_MONTH_YEAR));
	}

	// 获取时间，对应now的0点0分
	public Date getTodayBegin(Date now) {
		return getDate(getDesc(now, TYPE_DAY_MONTH_YEAR));
	}

	public String formatSec(long sec) {
		StringBuilder formatBuilder = new StringBuilder();
		Formatter formatter = new Formatter(formatBuilder, Locale.getDefault());
		final Object[] timeArgs = new Object[5];

		String durationFormat = sec < 3600 ? "%2$d:%5$02d"
				: "%1$d:%3$02d:%5$02d";
		/*
		 * Provide multiple arguments so the format can be changed easily by
		 * modifying the xml.
		 */
		formatBuilder.setLength(0);

		final Object[] tempTimeArgs = timeArgs;
		timeArgs[0] = sec / 3600;
		timeArgs[1] = sec / 60;
		timeArgs[2] = (sec / 60) % 60;
		timeArgs[3] = sec;
		timeArgs[4] = sec % 60;

		String s = formatter.format(durationFormat, tempTimeArgs).toString();
		formatter.close();
		return s;
	}

	public long getCurrentUTC() {
		// 1、取得本地时间：
		Calendar cal = Calendar.getInstance();
		// 2、取得时间偏移量：
		int zoneOffset = cal.get(Calendar.ZONE_OFFSET);
		// 3、取得夏令时差：
		int dstOffset = cal.get(Calendar.DST_OFFSET);
		// 4、从本地时间里扣除这些差量，即可以取得UTC时间：
		cal.add(Calendar.MILLISECOND, -(zoneOffset + dstOffset));
		// 之后调用cal.get(int x)或cal.getTimeInMillis()方法所取得的时间即是UTC标准时间。
		long utc = cal.getTimeInMillis();

		return utc;
	}

	public int getHour(long time) {
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(time);

		return c.get(Calendar.HOUR_OF_DAY);
	}

	public int getMinute(long time) {
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(time);

		return c.get(Calendar.MINUTE);
	}

	public int getSecond(long time) {
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(time);

		return c.get(Calendar.SECOND);
	}

	public String getDayInWeek(long time) {
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(time);

		return getDayInWeekDesc(c.get(Calendar.DAY_OF_WEEK));
	}

	private String getDayInWeekDesc(int day) {
		String desc = null;
		switch (day) {
		case Calendar.MONDAY:
			desc = "1";
			break;
		case Calendar.TUESDAY:
			desc = "2";
			break;
		case Calendar.WEDNESDAY:
			desc = "3";
			break;
		case Calendar.THURSDAY:
			desc = "4";
			break;
		case Calendar.FRIDAY:
			desc = "5";
			break;
		case Calendar.SATURDAY:
			desc = "6";
			break;
		case Calendar.SUNDAY:
			desc = "7";
			break;
		default:
			break;
		}

		return desc;
	}

	public String getYear(long time){
		return getDesc(new Date(time), TYPE_YEAR);
	}
	public String getMonth(long time) {
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(time);

		return getMonthDesc(c.get(Calendar.MONTH));
	}

	private String getMonthDesc(int month) {
		String desc = null;
		switch (month) {
		case Calendar.JANUARY:
			desc = "1";
			break;
		case Calendar.FEBRUARY:
			desc = "2";
			break;
		case Calendar.MARCH:
			desc = "3";
			break;
		case Calendar.APRIL:
			desc = "4";
			break;
		case Calendar.MAY:
			desc = "5";
			break;
		case Calendar.JUNE:
			desc = "6";
			break;
		case Calendar.JULY:
			desc = "7";
			break;
		case Calendar.AUGUST:
			desc = "8";
			break;
		case Calendar.SEPTEMBER:
			desc = "9";
			break;
		case Calendar.OCTOBER:
			desc = "10";
			break;
		case Calendar.NOVEMBER:
			desc = "11";
			break;
		case Calendar.DECEMBER:
			desc = "12";
			break;
		default:
			break;
		}
		return desc;
	}

	public String getDay(long time) {
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(time);

		return c.get(Calendar.DAY_OF_MONTH) + "";
	}

	public long getUtcTimeThroughNet() {
		// new york
		return getUtcTimeThroughNet(40.71417, -74.00639);
	}

	public long getUtcTimeThroughNet(double lat, double lng) {
		class Time {
			private long time = -1;
		}
		final Time time = new Time();

		String url = "http://www.earthtools.org/timezone/" + lat + "/" + lng;
		NetTool net = new NetTool();

		net.addListener(new NetToolListener() {
			@Override
			public void netOperationSuccess(byte[] response) {
				// TODO Auto-generated method stub
				if (response != null && response.length > 0) {
					try {
						Element root = DocumentBuilderFactory.newInstance()
								.newDocumentBuilder()
								.parse(new ByteArrayInputStream(response))
								.getDocumentElement();
						NodeList children = root.getChildNodes();

						for (int i = 0; i < children.getLength(); i++) {
							Node node = children.item(i);
							if (node.getNodeType() == Node.ELEMENT_NODE
									&& node.getNodeName().equals("utctime")) {
								Element e = (Element) node;
								String content = e.getTextContent();
								if (!StringTool.isNull(content)) {
									SimpleDateFormat sdf = new SimpleDateFormat(
											"yyyy-MM-dd HH:mm:ss");
									time.time = sdf.parse(content).getTime();
								}
								break;
							}
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

			@Override
			public void netOperationFail() {
				// TODO Auto-generated method stub

			}

			@Override
			public void netError() {
				// TODO Auto-generated method stub

			}
		});

		net.getData(url);

		if (time.time == -1) {
			time.time = getUtcTimeThroughNet(lat, lng);
		}
		return time.time;
	}

	/**
	 * 两个date之间，有多少天
	 * 
	 * @param date1
	 * @param date2
	 * @return
	 */
	public int howManyDays(long date1, long date2) {
		int remainder = (int) ((date1 - date2) % A_DAY_LONG);
		return (int) ((date1 - date2) / A_DAY_LONG + (remainder == 0 ? 0 : 1));
	}

	public long date2long(String datestr, String format) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			Date date = sdf.parse(datestr);
			return date.getTime();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public String long2date(long datelong, String format) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		Date date = new Date();
		date.setTime(datelong);
		return sdf.format(date);
	}

	public boolean isDay() {
		return isDay(System.currentTimeMillis());
	}

	/**
	 * 判断是白天黑夜
	 * 
	 * @param time
	 * @return
	 */
	public boolean isDay(long time) {
		Date date = new Date(time);
		@SuppressWarnings("deprecation")
		int hour = date.getHours();

		return hour >= 6 && hour < 18;
	}

	public boolean isToday(String date) {
		boolean isToday = false;

		if (!StringTool.isNull(date)) {
			System.err.println("date:" + date);
			long time = -1;
			try {
				time = format.parse(date).getTime();
				isToday = time == getTodayBegin().getTime();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return isToday;
	}
}
