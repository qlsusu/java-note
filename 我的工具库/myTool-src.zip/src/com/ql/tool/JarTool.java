package com.ql.tool;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class JarTool {
	public static JarTool instance = new JarTool();

	public static JarTool getInstance() {
		return instance;
	}

	/**
	 * 产生指定的jar
	 * 
	 * @param jarPath
	 * @param res
	 * @return
	 */
	public void createJar(String jarPath, List<Class<?>> clz, List<String> res) {
		final String binDir = "bin";

		if (!StringTool.isNull(jarPath)) {
			String clzStr = "";
			String resStr = "";
			String target = "";

			if (clz != null) {
				for (Class<?> c : clz) {
					clzStr += c.getName().replace(".", "/") + ".class ";
				}
			}
			if (res != null) {
				for (String s : res) {
					resStr += s + " ";
				}
			}
			target += clzStr + resStr;
			if (!StringTool.isNull(target)) {
				try {
					System.out.println("jar cvf " + jarPath + " -C " + binDir
							+ " " + target);
					Process p = Runtime.getRuntime().exec(
							"jar cvf " + jarPath + " -C " + binDir + " "
									+ target);
					waitTillOtherProcessFinish(p);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public void runHadoop(String jarPath, Class<?> mainClz) {
		if (!StringTool.isNull(jarPath) && mainClz != null) {
			try {
				Process p = Runtime.getRuntime().exec(
						"hadoop jar " + jarPath + " " + mainClz.getName());
				waitTillOtherProcessFinish(p);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void waitTillOtherProcessFinish(Process p) {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			while (reader.readLine() != null) {
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void runJar(String jarPath, Class<?> mainClz) {
		if (!StringTool.isNull(jarPath) && mainClz != null) {
			try {
				System.out.println("jave -jar " + jarPath + " "
						+ mainClz.getName());

				Process p = Runtime.getRuntime().exec(
						"jave -jar " + jarPath + " " + mainClz.getName());
				waitTillOtherProcessFinish(p);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
