package com.ql.tool;

import java.io.Reader;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

/**
 * the utility class for json operation: to format a bean class into json
 * format, or construct a bean object from json-pattern string
 * 
 * @author qilu
 * 
 */
public class JsonTool {
	/**
	 * 在 bean->string时，有哪些该被忽略：clz的field属性
	 * 
	 * @author qilu0617
	 * 
	 */
	public static class Skip {
		private Class<?> clz;
		private List<String> fields = new ArrayList<String>();

		public Class<?> getClz() {
			return clz;
		}

		public void setClz(Class<?> clz) {
			this.clz = clz;
		}

		public List<String> getFields() {
			return fields;
		}

		public void setFields(List<String> fields) {
			this.fields = fields;
		}
	}

	public static JsonTool instance = new JsonTool();

	private Gson gson;

	private List<Skip> skips;

	public void init() {
		init(null);
	}

	public List<Skip> getSkips() {
		return skips;
	}

	// public void init(final List<Skip> skips) {
	// this.skips = skips;
	//
	// if (skips == null || skips.isEmpty()) {
	// System.out.println("hhhhh");
	// ExclusionStrategy strategy = new ExclusionStrategy() {
	// @Override
	// public boolean shouldSkipField(FieldAttributes attr) {
	// // TODO Auto-generated method stub
	// return false;
	// }
	//
	// @Override
	// public boolean shouldSkipClass(Class<?> clz) {
	// // TODO Auto-generated method stub
	// // 若返回true，则意味，bean或者bean的属性 属于该class，则被忽略
	// return false;
	// }
	// };
	// setExclusionStrategy(strategy);
	// } else {
	// ExclusionStrategy strategy = new ExclusionStrategy() {
	// @Override
	// public boolean shouldSkipField(FieldAttributes attr) {
	// // TODO Auto-generated method stub
	// for (Skip s : skips) {
	// if (s.fields.contains(attr.getName())
	// && s.clz == attr.getDeclaringClass()) {
	// return true;
	// }
	// }
	// return false;
	// }
	//
	// @Override
	// public boolean shouldSkipClass(Class<?> clz) {
	// // TODO Auto-generated method stub
	// // 若返回true，则意味，bean或者bean的属性 属于该class，则被忽略
	// return false;
	// }
	// };
	// setExclusionStrategy(strategy);
	// }
	// }

	public void init(List<Skip> skips) {
		this.skips = skips;
		if (this.skips == null) {
			this.skips = new ArrayList<>();
		}

		ExclusionStrategy strategy = new ExclusionStrategy() {
			@Override
			public boolean shouldSkipField(FieldAttributes attr) {
				// TODO Auto-generated method stub
				for (Skip s : JsonTool.this.skips) {
					if (s.fields.contains(attr.getName())
							&& attr.getDeclaringClass().isAssignableFrom(s.clz)) {
						return true;
					}
				}
				return false;
			}

			@Override
			public boolean shouldSkipClass(Class<?> clz) {
				// TODO Auto-generated method stub
				// 若返回true，则意味，bean或者bean的属性 属于该class，则被忽略
				return false;
			}
		};

		// 一个ExclusionStrategies，只能被设置一次（设置多次，最后一次不起作用）
		createBuilder();
		builder.setExclusionStrategies(strategy);
		gson = builder.create();
	}

	private GsonBuilder builder;

	public void setOldFieldPattern(boolean isOld) {
		createBuilder();
		builder.setFieldNamingPolicy(isOld ? FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES
				: FieldNamingPolicy.IDENTITY);
		gson = builder.create();
	}

	public void includeFieldsWithAllModifiers() {
		excludeFieldsWithModifiers(new int[] {});
	}

	public void excludeFieldsWithModifiers(int... modifiers) {
		createBuilder();
		builder.excludeFieldsWithModifiers(modifiers);
		gson = builder.create();
	}

	public void setDateFormat(String pattern) {
		createBuilder();
		builder.setDateFormat(pattern);
		gson = builder.create();
	}

	public void setSkips(List<Skip> skips) {
		init(skips);
	}

	private void createBuilder() {
		if (builder == null) {
			builder = new GsonBuilder();
			// builder.setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES);
			// builder.setDateFormat("yyyy-MM-dd HH:mm:ss");

			builder.enableComplexMapKeySerialization();
			builder.setPrettyPrinting();
		}
	}

	private JsonTool() {
		createBuilder();
		gson = builder.create();
	}

	public String toString(Object o) {
		return gson.toJson(o);
	}

	public Object toObject(Reader reader, Class<?> clz) {
		return gson.fromJson(reader, clz);
	}

	public Object toObject(String str, Class<?> clz) {
		return toObject(str, clz, null);
	}

	/**
	 * 将json字符串 转化为 objClz实例，并将prop更新为 对应的类实例<br>
	 * 
	 * @see #changeObject(Object, Map, JsonObject)
	 * 
	 * @param str
	 * @param objClz
	 * @param propClzMap
	 * @return
	 */
	public Object toObject(String str, Class<?> objClz,
			Map<String, Class<?>> propClzMap) {
		Object objRoot = null;

		if (!StringTool.isNull(str)) {
			objRoot = gson.fromJson(str, objClz);
			JsonObject joRoot = (JsonObject) new JsonParser().parse(str);
			changeObject(objRoot, propClzMap, joRoot);
		}

		return objRoot;
	}

	/**
	 * 将obj的某些prop变成特定clz的对象
	 * 
	 * @param objRoot
	 * @param propClzMap
	 *            prop可能为a.b.c，其意味着 最终产生的对象的a的b的c的 class为 propClzMap.get(prop)<br>
	 *            如果prop是list类型，意味着 该list中的元素的类型为 propClzMap.get(prop)<br>
	 *            一个prop只能对应一个类，暂不支持一个prop对应多个class（后续改进...）<br>
	 * @param joRoot
	 */
	public void changeObject(Object objRoot, Map<String, Class<?>> propClzMap,
			JsonObject joRoot) {
		if (objRoot != null && propClzMap != null && !propClzMap.isEmpty()
				&& joRoot != null) {
			for (String prop : propClzMap.keySet()) {
				List<String> ps = new ArrayList<>(Arrays.asList(prop
						.split("\\.")));
				Class<?> clz = propClzMap.get(prop);

				if (ps != null && !ps.isEmpty()) {
					String lastP = ps.remove(ps.size() - 1);
					List<JsonElement> jos = getJe(ps, joRoot);
					List<Object> objs = ReflectTool.instance.getProperty(ps,
							objRoot);

					for (int i = 0; i < jos.size(); i++) {
						changeObjectUsingAtomProp(objs.get(i), jos.get(i),
								lastP, clz);
					}
				}
			}
		}
	}

	/**
	 * 获得property的jsonelement
	 * 
	 * @param prop
	 *            a.b.c形式：获取src的a的b的c的jsonelement
	 * @param src
	 * @return
	 * @see #getJe(List, JsonElement)
	 * @see #getJe(List, JsonElement, int, List)
	 */
	private List<JsonElement> getJe(String prop, JsonObject src) {
		if (src != null && !StringTool.isNull(prop)) {
			return getJe(Arrays.asList(prop.split("\\.")), src);
		}

		return null;
	}

	/**
	 * 获得property的jsonelement
	 * 
	 * @param ps
	 *            [a,b,c]形式：获取src的a的b的c的jsonelement
	 * @param src
	 * @return
	 */
	private List<JsonElement> getJe(List<String> ps, JsonElement src) {
		List<JsonElement> jes = new ArrayList<>();
		getJe(ps, src, 0, jes);
		return jes;
	}

	/**
	 * 获得property的jsonelement<br>
	 * 不允许：<br>
	 * 若property代表list，则不允许该list中的元素为list，后续改进...
	 * 
	 * @param ps
	 *            [a,b,c]形式：获取src的a的b的c的jsonelement
	 * @param src
	 * @param pIndex
	 *            当前在获取src的 ps[index]的 jsonelement
	 * @param jes
	 *            最终的prperty的jsonelement将被放入到该数组中<br>
	 *            为什么使用数组： 当b代表一个list，而c代表一个 非list<br>
	 *            当property代表list，则返回jsonarray，而不是list_jsonobject
	 */
	private void getJe(List<String> ps, JsonElement src, int pIndex,
			List<JsonElement> jes) {
		if (src != null && ps != null && !ps.isEmpty()) {
			try {
				if (!src.isJsonArray()) {
					try {
						JsonElement je = null;

						Set<Map.Entry<String, JsonElement>> set = src
								.getAsJsonObject().entrySet();
						for (Map.Entry<String, JsonElement> entry : set) {
							if (entry.getKey().equals(ps.get(pIndex))) {
								je = entry.getValue();
								break;
							}
						}

						pIndex++;
						if (pIndex == ps.size()) {
							jes.add(je);
						} else {
							getJe(ps, je, pIndex, jes);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					JsonArray array = src.getAsJsonArray();
					Iterator<JsonElement> it = array.iterator();
					while (it.hasNext()) {
						getJe(ps, it.next(), pIndex, jes);
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			jes.add(src);
		}
	}

	/**
	 * 改变obj：将 jo.prop值 转换为clz的实例，后 直接/间接 使用该实例，来更新 obj.prop<br>
	 * 如果prop为 非list类型，则使用clz的对象 直接 进行更新<br>
	 * 如果prop为 list类型，则构建clz对象的list，使用该list来更新obj.prop
	 * 
	 * @param obj
	 * @param je
	 * @param prop
	 * @param clz
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void changeObjectUsingAtomProp(Object obj, JsonElement je,
			String prop, Class<?> clz) {
		try {
			List<JsonObject> jos = new ArrayList<>();
			List<Object> objs = new ArrayList<>();

			if (je.isJsonArray()) {
				Iterator<JsonElement> it = je.getAsJsonArray().iterator();
				while (it.hasNext()) {
					jos.add(it.next().getAsJsonObject());
				}

				List list = (List) obj;
				objs.addAll(list);
			} else {
				jos.add(je.getAsJsonObject());

				objs.add(obj);
			}

			for (int i = 0; i < jos.size(); i++) {
				JsonObject jo = jos.get(i);
				obj = objs.get(i);

				System.out.println("clz:"+obj.getClass());
				System.out.println("prop:"+prop);
				
				Field f = obj.getClass().getDeclaredField(prop);
				f.setAccessible(true);

				Set<Map.Entry<String, JsonElement>> set = jo.entrySet();
				for (Map.Entry<String, JsonElement> entry : set) {
					if (entry.getKey().equals(prop)) {
						if (f.getType() == List.class) {
							List reals = new ArrayList<>();

							JsonArray array = (JsonArray) entry.getValue();
							Iterator<JsonElement> it = array.iterator();
							while (it.hasNext()) {
								JsonElement jele = it.next();
								reals.add(gson.fromJson(jele, clz));
							}
							f.set(obj, reals);
						} else {
							JsonElement real = entry.getValue();
							f.set(obj, gson.fromJson(real, clz));
						}
						break;
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<JsonElement> getJe(String prop, String str) {
		if (!StringTool.isNull(prop) && !StringTool.isNull(str)) {
			System.out.println("str:" + str);
			JsonObject joRoot = (JsonObject) new JsonParser().parse(str);
			return getJe(prop, joRoot);
		}

		return null;
	}

	public Object toObject(String str, Map<String, String> replaces,
			Class<?> clz) {
		if (!StringTool.isNull(str) && replaces != null) {
			for (String key : replaces.keySet()) {
				str = str.replace("\"" + key + "\"", "\"" + replaces.get(key)
						+ "\"");
			}
		}

		return gson.fromJson(str, clz);
	}

	/**
	 * @param str
	 * @param type
	 *            for example: Type type = new TypeToken<List<EntityNormal>>() {
	 *            }.getType();
	 * @return
	 */
	public Object toObject(Reader reader, Type type) {
		return gson.fromJson(reader, type);
	}

	/**
	 * @param str
	 * @param type
	 *            for example: Type type = new TypeToken<List<EntityNormal>>() {
	 *            }.getType();
	 * @return
	 */
	public Object toObject(String str, Type type) {
		return gson.fromJson(str, type);
	}

	private static class MyParameterizedType implements ParameterizedType {
		private Type type;

		private MyParameterizedType(Type type) {
			this.type = type;
		}

		@Override
		public Type[] getActualTypeArguments() {
			return new Type[] { type };
		}

		@Override
		public Type getRawType() {
			return ArrayList.class;
		}

		@Override
		public Type getOwnerType() {
			return null;
		}
	}

	public <T> List<T> toList(String str, Class<T> eleClz) {
		Type type = new MyParameterizedType(eleClz);
		List<T> list = gson.fromJson(str, type);

		return list;
	}

	public <T> List<T> toList(Reader reader, Class<T> eleClz) {
		Type type = new MyParameterizedType(eleClz);
		List<T> list = gson.fromJson(reader, type);

		return list;
	}

	// /**
	// * 对json字符串进行format：如"key_name": 变成 "keyName":
	// *
	// * @param json
	// * @return
	// */
	// public String jsonFormatBeforeToBean(String json) {
	// if (isFieldOldPattern && !StringTool.isNull(json)) {
	// List<String> keys = RegExpTool.instance.match(json, "\"", "\":",
	// false);
	// for (String key : keys) {
	// json = json.replace("\"" + key + "\":",
	// "\"" + StringTool.getRegularFieldName(key) + "\":");
	// }
	// }
	// return json;
	// }

	// public String jsonFormatBeforeToString(String json) {
	// if (isFieldOldPattern && !StringTool.isNull(json)) {
	// List<String> keys = RegExpTool.instance.match(json, "\"", "\":",
	// false);
	// for (String key : keys) {
	// List<String> parts = RegExpTool.instance.match(key,
	// ".[a-z_\\-1-9]+");
	// String newKey = "";
	// for (String part : parts) {
	// newKey += part.toLowerCase() + "_";
	// }
	// newKey = newKey.substring(0, newKey.length() - 1);
	//
	// json = json.replace("\"" + key + "\":", "\"" + newKey + "\":");
	// }
	// }
	// return json;
	// }
	
	public String toStringCustom(Object obj){
		return null;
	}
}
