package com.ql.tool;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.commons.codec.binary.Base64;

public class Base64Tool {
	private Base64Tool() {

	}

	public static Base64Tool instance = new Base64Tool();

	public String encode(String str) {
		String s = null;
		if (!StringTool.isNull(str)) {
			Base64 base64 = new Base64();

			byte[] data = str.getBytes();
			// 使用Base64進行字串編碼
			s = new String(base64.encode(data));
		}

		return s;
	}
	
	public String encode(byte[] data) {
		String s = null;
		if (data!=null) {
			Base64 base64 = new Base64();
			// 使用Base64進行字串編碼
			s = new String(base64.encode(data));
		}

		return s;
	}

	/**
	 * 将file的内容编码成base64
	 * 
	 * @param file
	 * @return
	 */
	public String encodeFile(String file) {
		String s = null;
		if (FileTool.getInstance().isFileExist(file)) {
			Base64 base64 = new Base64();

			byte[] data = FileTool.getInstance().readContent(file);
			// 使用Base64進行字串編碼
			s = new String(base64.encode(data));
		}

		return s;
	}

	/**
	 * 将src的内容编码成base64，并将结果写入到output
	 * 
	 * @param src
	 * @param output
	 */
	public void encodeFile(String src, String output) {
		if (FileTool.getInstance().isFileExist(src)) {
			Base64 base64 = new Base64();

			byte[] data = FileTool.getInstance().readContent(src);
			// 使用Base64進行字串編碼
			FileTool.getInstance().writeData(output, base64.encode(data));
		}
	}

	/**
	 * 将s进行解码，并将解码内容写入到output
	 * 
	 * @param s
	 * @param output
	 */
	public void decode(String s, String output) {
		try {
			Base64 base64 = new Base64();

			byte[] data = base64.decode(s.getBytes());
			FileOutputStream fos = new FileOutputStream(new File(output));
			fos.write(data);
			fos.flush();
			fos.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 将src的内容进行解码，并将解码内容写入到output
	 * 
	 * @param src
	 * @param output
	 */
	public void decodeFile(File src, String output) {
		try {
			Base64 base64 = new Base64();

			String s = FileTool.getInstance()
					.readContentByLine(src.getAbsolutePath()).get(0);
			byte[] data = base64.decode(s.getBytes());
			FileOutputStream fos = new FileOutputStream(new File(output));
			fos.write(data);
			fos.flush();
			fos.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
