package com.ql.tool;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ql.tool.JsonTool.Skip;
import com.ql.tool.httpclient3.HttpClientUtil;

/**
 * A utility that has logic about HTTP communication. It is designed to be a
 * singleton.
 * 
 * @author qilu
 * 
 */
public class NetTool {
	private static final Log LOG = LogFactory.getLog(NetTool.class);
	
	public static interface NetToolListener {
		public abstract void netOperationFail();

		public abstract void netOperationSuccess(byte[] response);

		public abstract void netError();
	}

	private List<NetToolListener> listeners = new ArrayList<NetTool.NetToolListener>();

	// public static NetTool instance = new NetTool();

	public void addListener(NetToolListener listener) {
		listeners.add(listener);
	}

	public void removeListener(NetToolListener listener) {
		listeners.remove(listener);
	}

	/**
	 * get data from input stream of HTTP connection.
	 * 
	 * @param address
	 * @return
	 */
	public byte[] getData(String address) {
		return getData(address, 2);
	}

	public byte[] getDataUsingHttpClient(String address) {
		byte[] data = null;
		String content = HttpClientUtil.get(address);
		if (!StringTool.isNull(content)) {
			data = content.getBytes();
		}
		return data;
	}

	public byte[] getData(String address, int leftFailTimes) {
		HttpURLConnection conn = null;
		byte[] data = null;

		if (StringTool.isNull(address)) {
			return null;
		}

		try {
			LOG.debug("get data from the requested url:"
					+ address);
			conn = getConnection(address);
			conn.setConnectTimeout(6 * 1000);
			conn.setDoInput(true);
			conn.setRequestMethod("GET");
			// conn.setRequestProperty("Accept", "text/html");
			int code = conn.getResponseCode();
			System.out.println("response code:" + code);
			if (code == HttpURLConnection.HTTP_OK) {
				data = new byte[1024];
				int len = -1;
				InputStream is = conn.getInputStream();

				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				while ((len = is.read(data)) != -1) {
					bos.write(data, 0, len);
				}
				data = bos.toByteArray();
				is.close();
				LOG.debug("response data:");
				LOG.debug(new String(data));
				for (NetToolListener listener : listeners) {
					listener.netOperationSuccess(data);
				}
			} else {
				if (leftFailTimes > 0) {
					LOG.debug("net fail,retry");
					data = getData(address, leftFailTimes - 1);
				} else {
					for (NetToolListener listener : listeners) {
						listener.netOperationFail();
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOG.debug("NetManager error:" + e);
			e.printStackTrace();
			if (leftFailTimes > 0) {
				LOG.debug("net error,retry");
				data = getData(address, leftFailTimes - 1);
			} else {
				for (NetToolListener listener : listeners) {
					listener.netError();
				}
				data = null;
			}
		} finally {
			if (conn != null) {
				conn.disconnect();
			}
		}
		return data;
	}

	public void loadData(String address, String file) {
		HttpURLConnection conn = null;
		byte[] data = null;

		if (StringTool.isNull(address)) {
			return;
		}

		try {
			conn = getConnection(address);
			conn.setConnectTimeout(6 * 1000);
			conn.setDoInput(true);
			conn.setRequestMethod("GET");
			int code = conn.getResponseCode();
			if (code == HttpURLConnection.HTTP_OK) {
				InputStream is = conn.getInputStream();
				FileOutputStream fos = null;
				if (is != null) {
					// 临时文件
					File tmpFile = new File(file + ".tmp");
					fos = new FileOutputStream(tmpFile);
					byte[] buf = new byte[1024];
					int ch = -1;
					while ((ch = is.read(buf)) != -1) {
						fos.write(buf, 0, ch);
						fos.flush();
					}
					fos.close();
					is.close();
					// 替换文件
					File dest = new File(file);
					if (dest.exists()) {
						dest.delete();
					}
					tmpFile.renameTo(dest);

					for (NetToolListener listener : listeners) {
						listener.netOperationSuccess(data);
					}
				}
			} else {
				for (NetToolListener listener : listeners) {
					listener.netOperationFail();
				}
			}
		} catch (Exception e) {
			for (NetToolListener listener : listeners) {
				listener.netError();
			}
			e.printStackTrace();
		} finally {
			if (conn != null) {
				conn.disconnect();
			}
		}
	}

	/**
	 * 判断接入点方式（net/wap），来建立连接
	 * 
	 * @param address
	 * @return
	 * @throws Exception
	 */
	private HttpURLConnection getConnection(String address) throws Exception {
		HttpURLConnection conn = null;

		// 设置代理
		// for android
		// String proxyHost = android.net.Proxy.getDefaultHost();
		// if (proxyHost != null) {
		// // wap方式，要加网关
		// java.net.Proxy p = new java.net.Proxy(java.net.Proxy.Type.HTTP,
		// new InetSocketAddress(android.net.Proxy.getDefaultHost(),
		// android.net.Proxy.getDefaultPort()));
		// conn = (HttpURLConnection) new URL(address).openConnection(p);
		// } else {
		// conn = (HttpURLConnection) new URL(address).openConnection();
		// }
		// for desktop
		// SocketAddress addr = new InetSocketAddress("127.0.0.1", 8087);
		// Proxy proxy = new Proxy(Proxy.Type.HTTP, addr);
		// conn = (HttpURLConnection) new URL(address).openConnection(proxy);

		// 一般
		conn = (HttpURLConnection) new URL(address).openConnection();
		return conn;
	}

	public static interface ParamTransform {
		public Map<String, String> getParamTransformMap();
	}

	public static interface RequestInfo extends ParamTransform {
		public List<String> getRequestFields();
	}

	public static interface ResponseInfo extends ParamTransform {
	}

	public final static String HTTP_METHOD_GET = "GET";
	public final static String HTTP_METHOD_POST = "POST";
	public final static String HTTP_METHOD_PUT = "PUT";
	public final static String HTTP_METHOD_DELETE = "DELETE";

	public static interface OnSendListener {
		public void onGetResponse(ResponseInfo response);

		public void onNetOperationFail();

		public void onNetError();
	}

	/**
	 * 传递给服务器的数据，并得到响应<br>
	 * <br>
	 * 数据：<br>
	 * 来自field：RequestInfo.getRequestFields<br>
	 * 转换field的名字：RequestInfo.getParamTransformMap<br>
	 * <br>
	 * 区分method<br>
	 * 如果是get，则将数据map拼接到url上，否则，将数据json写入到流中<br>
	 * 
	 * @param url
	 * @param method
	 * @param request
	 * @param responseClz
	 * @param listener
	 * @return
	 */
	public void send(String url, String method, RequestInfo request,
			final Class<? extends ResponseInfo> responseClz,
			final OnSendListener listener) {
		class ResponseHandler {
			private void handleData(NetTool net) {
				net.addListener(new NetToolListener() {
					@Override
					public void netOperationSuccess(byte[] byteData) {
						// TODO Auto-generated method stub
						String data = new String(byteData);
						if (!StringTool.isNull(data)) {
							if (responseClz != null) {
								try {
									Map<String, String> paramTransformMap = responseClz
											.newInstance()
											.getParamTransformMap();
									if (paramTransformMap != null) {
										for (String key : paramTransformMap
												.keySet()) {
											data = data.replace(
													"\"" + key + "\":",
													"\""
															+ paramTransformMap
																	.get(key)
															+ "\":");
										}
									}
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
							ResponseInfo response = (ResponseInfo) JsonTool.instance
									.toObject(new String(data), responseClz);
							if (listener != null) {
								listener.onGetResponse(response);
							}
						}

					}

					@Override
					public void netOperationFail() {
						// TODO Auto-generated method stub
						if (listener != null) {
							listener.onNetOperationFail();
						}
					}

					@Override
					public void netError() {
						// TODO Auto-generated method stub
						if (listener != null) {
							listener.onNetError();
						}
					}
				});
			}
		}

		if (!StringTool.isNull(url) && !StringTool.isNull(method)
				&& request != null && responseClz != null) {
			NetTool net = new NetTool();
			new ResponseHandler().handleData(net);

			List<String> requestFields = request.getRequestFields();
			if (requestFields == null || requestFields.isEmpty()) {
				requestFields = new ArrayList<String>();
				Field[] fs = request.getClass().getDeclaredFields();
				for (Field f : fs) {
					requestFields.add(f.getName());
				}
			}

			try {
				if (method.equals(HTTP_METHOD_GET)) {
					Map<String, String> params = new HashMap<String, String>();
					Map<String, String> paramTransformMap = request
							.getParamTransformMap();

					for (String field : requestFields) {
						String key = paramTransformMap.containsKey(field) ? paramTransformMap
								.get(field) : field;

						Field f = request.getClass().getDeclaredField(field);
						f.setAccessible(true);
						Object value = f.get(request);
						if (value == null) {
							continue;
						}
						params.put(key, value.toString());
					}
					url = generateRequestUrl(url, params);
					LOG.debug("url is:" + url);

					net.getData(url);
				} else {
					List<Skip> skips = JsonTool.instance.getSkips();
					if (skips == null) {
						skips = new ArrayList<JsonTool.Skip>();
					}
					Skip skip = null;
					for (Skip s : skips) {
						if (s.getClz().equals(request.getClass())) {
							skip = s;
							break;
						}
					}
					if (skip != null) {
						skips.remove(skip);
					}

					skip = new Skip();
					skips.add(skip);
					skip.setClz(request.getClass());

					List<String> allFields = new ArrayList<String>();
					Field[] fs = request.getClass().getDeclaredFields();
					for (Field f : fs) {
						allFields.add(f.getName());
					}
					allFields.removeAll(requestFields);
					skip.setFields(allFields);

					JsonTool.instance.init(skips);

					String send = JsonTool.instance.toString(request);
					Map<String, String> paramTransformMap = request
							.getParamTransformMap();
					if (paramTransformMap != null) {
						for (String key : paramTransformMap.keySet()) {
							send = send.replace("\"" + key + "\":", "\""
									+ paramTransformMap.get(key) + "\":");
						}
					}
					LOG.debug("send data:" + send);

					net.sendData(url, send.getBytes());
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public byte[] sendData(String address, byte[] input) {
		// return sendData(address, input, null);
		return sendDataUsingHttpClient(address, input, null);
	}

	public byte[] sendDataUsingHttpClient(String address, byte[] input,
			String contentType) {
		LOG.debug("send data using httpclient to:" + address);

		byte[] data = null;
		String response = HttpClientUtil.post(address, input);
		if (!StringTool.isNull(response)) {
			data = response.getBytes();
			for (NetToolListener listener : listeners) {
				listener.netOperationSuccess(data);
			}
		} else {
			for (NetToolListener listener : listeners) {
				listener.netOperationFail();
			}
		}
		return data;
	}

	/**
	 * send data to the server
	 * 
	 * @param address
	 * @param input
	 * @return the feed back from the server
	 */
	public byte[] sendData(String address, byte[] input, String contentType) {
		HttpURLConnection conn = null;

		byte[] response = null;
		if (!StringTool.isNull(address) && input != null && input.length > 0) {
			try {
				LOG.debug("send data to the requested url:"
						+ address);
				conn = getConnection(address);
				conn.setConnectTimeout(6 * 1000);
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("content-type", StringTool
						.isNull(contentType) ? "text/html;charset=utf-8"
						: contentType);

				OutputStream os = conn.getOutputStream();
				os.write(input);
				os.close();

				int code = conn.getResponseCode();
				LOG.debug("code is:" + code);
				if (code == HttpURLConnection.HTTP_OK) {
					InputStream is = conn.getInputStream();
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					byte[] data = new byte[1024];
					int len = -1;
					while ((len = is.read(data)) != -1) {
						bos.write(data, 0, len);
					}
					response = bos.toByteArray();
					LOG.debug("server response:"
							+ new String(response));
					for (NetToolListener listener : listeners) {
						listener.netOperationSuccess(response);
					}
				} else {
					for (NetToolListener listener : listeners) {
						listener.netOperationFail();
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				LOG.debug("NetManager error:" + e);
				for (NetToolListener listener : listeners) {
					listener.netError();
				}
				e.printStackTrace();
				response = null;
			} finally {
				if (conn != null) {
					conn.disconnect();
				}
			}
		}
		return response;
	}

	public byte[] sendData(String address, String filePath) {
		return sendData(address, filePath, null);
	}

	public byte[] sendParam(String address, Map<String, String> params) {
		if (params != null && !params.isEmpty()) {
			return sendData(address, generateParams(params).getBytes(),
					"application/x-www-form-urlencoded");
		}
		return null;
	}

	public byte[] sendData(String address, String filePath, String contentType) {
		HttpURLConnection conn = null;

		byte[] response = null;

		File f = new File(filePath);
		if (!StringTool.isNull(address) && f.exists()) {
			try {
				LOG.debug("send data to the requested url:"
						+ address);
				conn = getConnection(address);
				conn.setConnectTimeout(6 * 1000);
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("content-type", StringTool
						.isNull(contentType) ? "text/html;charset=utf-8"
						: contentType);

				OutputStream os = conn.getOutputStream();
				InputStream is = new FileInputStream(f);
				byte[] data = new byte[1024];
				int len = -1;

				while ((len = is.read(data)) != -1) {
					os.write(data, 0, len);
					os.flush();
				}
				is.close();
				os.close();
				int code = conn.getResponseCode();
				LOG.debug("code is:" + code);
				if (code == HttpURLConnection.HTTP_OK) {
					is = conn.getInputStream();
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					data = new byte[1024];
					len = -1;
					while ((len = is.read(data)) != -1) {
						bos.write(data, 0, len);
					}
					response = bos.toByteArray();
					Printer.instance
							.println("response:" + new String(response));
					for (NetToolListener listener : listeners) {
						listener.netOperationSuccess(response);
					}
				} else {
					for (NetToolListener listener : listeners) {
						listener.netOperationFail();
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				LOG.debug("NetManager error:" + e);
				for (NetToolListener listener : listeners) {
					listener.netError();
				}
				e.printStackTrace();
				response = null;
			} finally {
				if (conn != null) {
					conn.disconnect();
				}
			}
		}
		return response;
	}

	/**
	 * decode to get a string
	 * 
	 * @param data
	 * @return
	 */
	public String decode(String data) {
		try {
			return URLDecoder.decode(data, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * encoding a string by using UTF-8 charset
	 * 
	 * @param data
	 * @return
	 */
	public static String encode(String data) {
		try {
			return URLEncoder.encode(data, "UTF-8");
			/**
			 * please note that: data may be null, so catch the Exception
			 */
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

	public static String generateRequestUrl(String base, Map<String, String> map) {
		String url = null;

		if (!StringTool.isNull(base) && map != null) {
			url = base + "?" + generateParams(map);
		}
		return url;
	}

	public static String generateParams(Map<String, String> map) {
		String params = null;
		if (map != null) {
			params = "";
			Iterator<String> it = map.keySet().iterator();
			while (it.hasNext()) {
				String key = it.next();
				if (!StringTool.isNull(key) && !StringTool.isNull(map.get(key))) {
					params += encode(key) + "=" + encode(map.get(key)) + "&";
				}
			}
			params = params.substring(0, params.length() - 1);
		}
		return params;
	}
}
