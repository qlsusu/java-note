package com.ql.tool;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * the utility class for file operation.
 * 
 * @author bill
 * 
 */
public class FileTool {
	private static FileTool instance = new FileTool();

	private FileTool() {

	}

	public static FileTool getInstance() {
		return instance;
	}

	/**
	 * judge whether the file exists or not
	 * 
	 * @param path
	 * @return
	 */
	public boolean isFileExist(String path) {
		if (!StringTool.isNull(path)) {
			return new File(path).exists();
		}
		return false;
	}

	/**
	 * create a new file
	 * 
	 * @param path
	 */
	public void createNewFile(String path) {
		if (!isFileExist(path)) {
			try {
				new File(path).createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void deleteFiles(String path) {
		deleteFiles(path, null);
	}

	public final static int DELETE_WAY_STARTSWITH = 0;
	public final static int DELETE_WAY_ENDSWITH = 1;
	public final static int DELETE_WAY_CONTAINS = 2;

	public void deleteFiles(String path, String tag) {
		deleteFiles(path, DELETE_WAY_CONTAINS, tag);
	}

	/**
	 * delete file
	 * 
	 * @param path
	 */
	public void deleteFiles(String path, int deleteWay, String tag) {
		File file = new File(path);
		if (file.exists()) {
			boolean isContainTag = false;
			if (StringTool.isNull(tag)) {
				isContainTag = true;
			} else {
				String name = file.getName().toLowerCase();
				tag = tag.toLowerCase();
				switch (deleteWay) {
				case DELETE_WAY_STARTSWITH:
					if (name.startsWith(tag)) {
						isContainTag = true;
					}
					break;
				case DELETE_WAY_ENDSWITH:
					if (name.endsWith(tag)) {
						isContainTag = true;
					}
					break;
				case DELETE_WAY_CONTAINS:
					if (name.contains(tag)) {
						isContainTag = true;
					}
					break;
				default:
					break;
				}
			}

			if (isContainTag) {
				List<File> fs = getAllFiles(file.getAbsolutePath());
				for (File f : fs) {
					f.delete();
				}
			} else {
				if (file.isDirectory()) {
					File[] fs = file.listFiles();
					for (File f2 : fs) {
						deleteFiles(f2.getAbsolutePath(), deleteWay, tag);
					}
				}
			}
		}
	}

	/**
	 * 获得path对应的文件（以及 子文件）
	 * 
	 * @param path
	 * @return
	 */
	public List<File> getAllFiles(String path) {
		List<File> files = new ArrayList<>();

		if (!StringTool.isNull(path)) {
			getAllFiles(new File(path), files);
		}

		return files;
	}

	private void getAllFiles(File base, List<File> files) {
		if (base != null && files != null) {
			if (base.exists()) {
				files.add(0, base);
				if (base.isDirectory()) {
					for (File f : base.listFiles()) {
						getAllFiles(f, files);
					}
				}
			}
		}
	}

	public String getParent(String path) {
		String parent = null;
		File f = new File(path);
		if (f.exists()) {
			parent = f.getParent();
		}
		return parent;
	}

	public byte[] readContent(String path) {
		try {
			File f = new File(path);
			if (f.exists()) {
				FileInputStream fis = new FileInputStream(f);
				byte[] data = new byte[1024];
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				int len = -1;
				while ((len = fis.read(data)) != -1) {
					bos.write(data, 0, len);
				}
				data = bos.toByteArray();
				fis.close();
				bos.close();
				return data;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public InputStream getResourceInput(String file) {
		if (!file.startsWith("/")) {
			file = "/" + file;
		}
		return FileTool.class.getResourceAsStream(file);
	}

	public List<String> readContentByLine(String path) {
		List<String> list = null;

		try {
			list = readContentByLine(new FileInputStream(path));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	public List<String> readContentByLine(InputStream is) {
		try {
			List<String> list = new ArrayList<String>();
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(is));
			String str;
			while ((str = reader.readLine()) != null) {
				if (!StringTool.isNull(str)) {
					list.add(str);
				}
			}
			reader.close();
			return list;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 将全部数据覆盖到path对应的文件
	 * 
	 * @param path
	 * @param data
	 */
	public void writeData(String path, byte[] data) {
		writeData(path, data, false);
	}

	/**
	 * 将全部数据覆盖/追加到path对应的文件
	 * 
	 * @param path
	 * @param data
	 * @param isAppend
	 */
	public void writeData(String path, byte[] data, boolean isAppend) {
		if (isFileExist(path) && data != null && data.length > 0) {
			writeData(path, data, 0, data.length, isAppend);
		}
	}

	/**
	 * 将部分数据覆盖/追加到path对应的文件
	 * 
	 * @param path
	 * @param data
	 * @param offset
	 * @param count
	 * @param isAppend
	 */
	public void writeData(String path, byte[] data, int offset, int count,
			boolean isAppend) {
		try {
			if (!StringTool.isNull(path) && data != null && data.length > 0) {
				File f = new File(path);
				if (!f.exists()) {
					f.createNewFile();
				}
				FileOutputStream fos = null;
				if (isAppend) {
					fos = new FileOutputStream(f, true);
				} else {
					fos = new FileOutputStream(f);
				}
				fos.write(data, offset, count);
				fos.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 将流中的数据覆盖到path对应的文件
	 * 
	 * @param path
	 * @param is
	 */
	public void writeData(String path, InputStream is) {
		try {
			if (!StringTool.isNull(path) && is != null) {
				File f = new File(path);
				if (!f.exists()) {
					f.createNewFile();
				}

				// LOG.debug("write file from is:" + path);
				FileOutputStream fos = new FileOutputStream(f);

				byte[] data = new byte[1024];
				int len = -1;
				while ((len = is.read(data)) != -1) {
					fos.write(data, 0, len);
					fos.flush();
				}
				is.close();
				fos.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 将src文件的百分之percent的数据追加到target<br>
	 * 注意：函数完成后，未关闭target
	 * 
	 * @param target
	 * @param srcPath
	 * @param percent
	 */
	public void writeData(OutputStream target, String srcPath, double percent) {
		try {
			File src = new File(srcPath);

			if (target != null && src.isFile() && src.exists()
					&& percent <= 1.0) {

				final int maxUnitRead = 1024;
				byte[] data = new byte[maxUnitRead];
				int len = -1;
				int needRead = (int) (src.length() * percent);

				FileInputStream fis = new FileInputStream(src);
				while (needRead > 0) {
					len = fis.read(data, 0,
							needRead > maxUnitRead ? maxUnitRead : needRead);
					if (len != -1) {
						target.write(data, 0, len);
						target.flush();
					} else {
						break;
					}
					needRead -= len;
				}
				fis.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void mkdirs(String path) {
		File f = new File(path);
		if (!f.exists()) {
			f.mkdirs();
		}
	}

	public long getFileSize(String file) {
		long size = 0;
		File f = new File(file);
		if (f.exists()) {
			size = f.length();
		}
		return size;
	}

	public void writeData(String file, Map<String, String> map) {
		if (map != null && !StringTool.isNull(file)) {
			try {
				File f = new File(file);
				if (!f.exists()) {
					f.createNewFile();
				}
				BufferedWriter writer = new BufferedWriter(new FileWriter(f));

				for (Entry<String, String> entry : map.entrySet()) {
					writer.write(entry.getKey() + "=" + entry.getValue() + "\n");
					writer.flush();
				}
				writer.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public FileInputStream getFileInputStream(String file) {
		FileInputStream fis = null;
		File f = new File(file);
		if (f.exists()) {
			try {
				fis = new FileInputStream(f);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return fis;
	}

	/**
	 * 在target文件后面添加others的byte内容
	 * 
	 * @param target
	 * @param others
	 */
	public void append(String target, List<String> others) {
		try {
			if (!StringTool.isNull(target) && others != null) {
				File file = new File(target);
				if (!file.exists()) {
					file.createNewFile();
				}
				FileOutputStream fos = new FileOutputStream(file);
				FileInputStream fis = null;
				byte[] data = new byte[1024];
				int len = -1;
				for (String s : others) {
					File ap = new File(s);
					if (ap.exists()) {
						fis = new FileInputStream(ap);
						while ((len = fis.read(data)) != -1) {
							fos.write(data, 0, len);
						}
						fos.flush();
						fis.close();
					}
				}
				fos.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 复制单个文件
	 * 
	 * @param oldPath
	 *            String 原文件路径
	 * @param newPath
	 *            String 复制后路径
	 * @return boolean
	 */
	public void copyFile(String oldPath, String newPath) {
		try {
			// int bytesum = 0;
			int byteread = 0;
			File oldfile = new File(oldPath);
			if (oldfile.exists()) {
				InputStream inStream = new FileInputStream(oldPath); // 读入原文件
				FileOutputStream fs = new FileOutputStream(newPath);
				byte[] buffer = new byte[1444];
				while ((byteread = inStream.read(buffer)) != -1) {
					// bytesum += byteread; // 字节数 文件大小
					fs.write(buffer, 0, byteread);
				}
				fs.close();
				inStream.close();
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	/**
	 * 复制单个文件
	 * 
	 * @param oldPath
	 *            String 原文件路径
	 * @param newPath
	 *            String 复制后路径
	 * @return boolean
	 */
	public void copyFile(InputStream inputStream, String newPath) {
		try {
			// int bytesum = 0;
			int byteread = 0;
			FileOutputStream fs = new FileOutputStream(newPath);
			byte[] buffer = new byte[1444];
			while ((byteread = inputStream.read(buffer)) != -1) {
				// bytesum += byteread; // 字节数 文件大小
				fs.write(buffer, 0, byteread);
			}
			fs.close();
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	/**
	 * 复制整个文件夹内容
	 * 
	 * @param oldPath
	 *            String 原文件路径
	 * @param newPath
	 *            String 复制后路径
	 * @return boolean
	 */
	public void copyFolder(String oldPath, String newPath) {
		try {
			(new File(newPath)).mkdirs(); // 如果文件夹不存在 则建立新文件夹
			File a = new File(oldPath);
			String[] file = a.list();
			File temp = null;
			for (int i = 0; i < file.length; i++) {
				if (oldPath.endsWith(File.separator)) {
					temp = new File(oldPath + file[i]);
				} else {
					temp = new File(oldPath + File.separator + file[i]);
				}

				if (temp.isFile()) {
					FileInputStream input = new FileInputStream(temp);
					FileOutputStream output = new FileOutputStream(newPath
							+ "/" + (temp.getName()).toString());
					byte[] b = new byte[1024 * 5];
					int len;
					while ((len = input.read(b)) != -1) {
						output.write(b, 0, len);
					}
					output.flush();
					output.close();
					input.close();
				}
				if (temp.isDirectory()) {// 如果是子文件夹
					copyFolder(oldPath + "/" + file[i], newPath + "/" + file[i]);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 返回文件夹有多少个文件
	 * 
	 * @param path
	 * @return
	 */
	public int getDirSize(String path) {
		int size = -1;
		if (!StringTool.isNull(path)) {
			File dir = new File(path);
			if (dir.exists() && dir.isDirectory()) {
				size = dir.list().length;
			}
		}

		return size;
	}

	public void cleanDirCommit(File file) {
		if (file != null && file.exists()) {
			if (file.isFile()) {
				cleanFileCommit(file);
			} else {
				for (File f : file.listFiles()) {
					if (f.isDirectory()) {
						cleanDirCommit(f);
					} else {
						cleanFileCommit(f);
					}
				}
			}
		}
	}

	/**
	 * 去除文件中的注释<br>
	 * 要求：注释应单独占用 几行，而其中不能包含有效代码
	 * 
	 * @param f
	 */
	public void cleanFileCommit(File f) {
		System.out.println("clean file:" + f);
		final String postfix = ".java";
		if (f != null && f.exists() && f.isFile()
				&& f.getName().endsWith(postfix)) {
			List<String> contents = FileTool.getInstance().readContentByLine(
					f.getAbsolutePath());
			final String[] commitStarts = new String[] { "//", "/**", "/*" };
			final String[] commitEnds = new String[] { "//", "*/", "*/" };

			List<String> valids = new ArrayList<>();

			boolean isInCommit = false;

			for (String content : contents) {
				boolean isContainCs = false;
				boolean isContainCe = false;

				for (int i = 0; i < commitStarts.length; i++) {
					String cs = commitStarts[i];
					String ce = commitEnds[i];

					if (content.trim().startsWith(cs)) {
						isContainCs = true;
						isContainCe = content.contains(ce);
						break;
					} else if (content.contains(ce)) {
						isContainCe = true;
						break;
					}
				}

				if (isContainCs) {
					isInCommit = true;
				}
				if (isInCommit) {
					if (isContainCe) {
						isInCommit = false;
					}
				} else {
					valids.add(content);
				}
			}

			StringBuffer buf = new StringBuffer();
			for (String valid : valids) {
				buf.append(valid + "\n");
			}
			// 如果valids为empty（则file的原始内容均为commit），也写入字符
			buf.append("\n");
			writeData(f.getAbsolutePath(), buf.toString().getBytes());
		}
	}
}