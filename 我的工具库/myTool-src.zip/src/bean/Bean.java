package bean;

import java.util.ArrayList;
import java.util.List;

public class Bean {
	public static class InnerBean {
		private String name;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		private List<Number> numbers = new ArrayList<>();

		public List<Number> getNumbers() {
			return numbers;
		}
	}

	private int age;

	private Object inner;

	private InnerBean realInner;

	public Object getInner() {
		return inner;
	}

	public void setInner(Object inner) {
		this.inner = inner;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public InnerBean getRealInner() {
		return realInner;
	}

	public void setRealInner(InnerBean realInner) {
		this.realInner = realInner;
	}

}
