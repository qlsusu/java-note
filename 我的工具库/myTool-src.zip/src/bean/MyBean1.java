package bean;

public class MyBean1 {
	public Object interface1;
}
