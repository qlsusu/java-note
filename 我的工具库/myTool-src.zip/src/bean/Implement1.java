package bean;

public class Implement1 extends Interface1 {
	public int age;
}
