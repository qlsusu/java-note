package bean;

public class That {
	String name;
	int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void accessThis() {
		final This it = new This();
		it.age = 20;
		System.out.println("this:" + it);

		class Other {
			public void method() {
				System.out.println("inner this:" + it);
				System.out.println(it.age);
			}
		}
		Other other = new Other();
		other.method();
	}
}
