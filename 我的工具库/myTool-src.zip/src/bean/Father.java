package bean;

public class Father {
	public int age;

	protected void fMethod1() {
		System.out.println("father method1");
	}
}
