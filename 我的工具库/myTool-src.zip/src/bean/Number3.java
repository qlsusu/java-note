package bean;

public class Number3 {
	private Number4 number4;

	public Number4 getNumber4() {
		return number4;
	}

	public void setNumber4(Number4 number4) {
		this.number4 = number4;
	}

	public Number3(Number4 number4) {
		super();
		this.number4 = number4;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "number4:" + number4;

	}
}
