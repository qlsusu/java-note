package bean;

public class Interface1 {

}
