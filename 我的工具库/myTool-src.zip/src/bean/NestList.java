package bean;

import java.util.ArrayList;
import java.util.List;

public class NestList {
	public List<List<String>> lists = new ArrayList<>();
	public List<String> list = new ArrayList<>();
}
