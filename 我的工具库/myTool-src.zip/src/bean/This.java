package bean;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class This {
	public String name;
	public int age;
	public That that;
	public List<Integer> values=new ArrayList<>(Arrays.asList(1,2,3));

	public This() {
		System.out.println("this constructor");
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		// return "name:" + name;
		return super.toString();
	}

	public static class Inner {
		private int some;
	}
}
