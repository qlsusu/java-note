package bean;

import java.util.ArrayList;
import java.util.List;

public class Bean1 {
	private List<String> beans = new ArrayList<>();

	public List<String> getBeans() {
		return beans;
	}
}
