package bean;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author qilu0617
 * 
 */
public class Weather extends Bean {

	private String location;
	private String date;
	private String desc;
	private double minTemp;
	private double maxTemp;

	public String getDate() {
		return date;
	}

	public long getDateTime() {
		try {
			return DATE_FORMAT.parse(this.date).getTime();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}

	public String getDesc() {
		return desc;
	}

	public double getMinTemp() {
		return minTemp;
	}

	public double getMaxTemp() {
		return maxTemp;
	}

	public void setDate(String date) {
		this.date = date;
	}

	private final static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(
			"yyyy-MM-dd");

	public void setDate(long time) {
		date = DATE_FORMAT.format(new Date(time * 1000));
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public void setMinTemp(double minTemp) {
		this.minTemp = minTemp;
	}

	public void setMaxTemp(double maxTemp) {
		this.maxTemp = maxTemp;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "(location:" + location + ",date:" + date + ",desc:" + desc
				+ ",minTemp:" + minTemp + ",maxTemp:" + maxTemp + ")";
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public final static String WEATHER_TYPE = "weather";
}
