package bean.json.replace;

import java.util.ArrayList;
import java.util.List;

public class RBean {
	public static class Interface{
		
	}
	
	public static class Implement extends Interface{
		public int age;
	}
	
	public String name;
	public List<Item> items=new ArrayList<>();
	public static class Item{
		public Interface some;
		public String path;
	}
}
