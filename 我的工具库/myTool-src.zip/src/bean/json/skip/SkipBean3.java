package bean.json.skip;

public class SkipBean3 {
	public int p31;
	public int p32;
}
