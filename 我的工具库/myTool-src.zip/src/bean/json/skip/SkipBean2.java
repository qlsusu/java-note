package bean.json.skip;

public class SkipBean2 {

	public int p21;
	public SkipBean3 p22Sb3;

}
