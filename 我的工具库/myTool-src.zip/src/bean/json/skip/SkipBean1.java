package bean.json.skip;

public class SkipBean1 {
	public int p11;
	public SkipBean2 p12Sb2;
}
