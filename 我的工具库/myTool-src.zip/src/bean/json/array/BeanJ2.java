package bean.json.array;

public class BeanJ2 {
	public String name;
}
