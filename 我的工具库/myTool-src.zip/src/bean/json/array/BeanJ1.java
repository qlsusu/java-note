package bean.json.array;

import java.util.Arrays;

public class BeanJ1 {
	public BeanJ2[] beanJ2s;
	public int id=2;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(beanJ2s);
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BeanJ1 other = (BeanJ1) obj;
		if (!Arrays.equals(beanJ2s, other.beanJ2s))
			return false;
		if (id != other.id)
			return false;
		return true;
	}
	
	
}
