package bean.json.father;

public class BeanJFather {
	private int id=1;

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}
}
