package bean.json.father;

public class BeanJSon extends BeanJFather {
	private String name;
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	
	private String id="idSTR";
	
	public String getIdStr() {
		return id;
	}
	
}
