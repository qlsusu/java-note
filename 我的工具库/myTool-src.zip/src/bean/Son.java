package bean;

public class Son extends Father {
	private String name;

	public String getName() {
		return name;
	}

	public void sMethod1() {
		Father father = new Son();
		fMethod1();
	}

}
