package bean.netparam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ql.tool.NetTool.RequestInfo;

public class RequestBean implements RequestInfo {
	private int age;
	private String name;
	private String some;

	@Override
	public Map<String, String> getParamTransformMap() {
		// TODO Auto-generated method stub
		Map<String, String> map = new HashMap<>();
		// map.put("name", "name_his");
		// map.put("name", "some_his");

		return map;
	}

	@Override
	public List<String> getRequestFields() {
		// TODO Auto-generated method stub
		List<String> fields = new ArrayList<>();

		// fields.add("age");
		// fields.add("name");
		return fields;
	}
}
