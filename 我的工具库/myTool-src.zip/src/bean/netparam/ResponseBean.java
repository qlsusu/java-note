package bean.netparam;

public class ResponseBean {

}
