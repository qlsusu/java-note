package bean;

import java.util.ArrayList;
import java.util.List;

public class Result {
	private List<Object> beans = new ArrayList<>();
	private List<Bean> realBean = new ArrayList<>();
	private Bean otherBean;
	private Object otherBean2;

	public List<Object> getBeans() {
		return beans;
	}

	public Bean getOtherBean() {
		return otherBean;
	}

	public void setOtherBean(Bean otherBean) {
		this.otherBean = otherBean;
	}

	public Object getOtherBean2() {
		return otherBean2;
	}

	public void setOtherBean2(Object otherBean2) {
		this.otherBean2 = otherBean2;
	}

	public List<Bean> getRealBean() {
		return realBean;
	}

}
