package bean;

public class Number {
	private Number2 number2;

	public Number2 getNumber2() {
		return number2;
	}

	public void setNumber2(Number2 number2) {
		this.number2 = number2;
	}

}
