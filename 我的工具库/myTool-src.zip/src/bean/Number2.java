package bean;

import java.util.ArrayList;
import java.util.List;

public class Number2 {
	private List<Number3> number3s = new ArrayList<>();

	public List<Number3> getNumber3s() {
		return number3s;
	}

	public void setNumber3s(List<Number3> number3s) {
		this.number3s = number3s;
	}

}
