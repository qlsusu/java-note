package test;

import java.util.List;

public class Bean {
	private String name;
	private int age;
	private List<String> somes;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public List<String> getSomes() {
		return somes;
	}

	public void setSomes(List<String> somes) {
		this.somes = somes;
	}

}
