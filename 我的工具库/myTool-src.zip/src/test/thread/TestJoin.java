package test.thread;

public class TestJoin {
	private int a;
	
	public static void main(String[] args) {
		final TestJoin bean=new TestJoin();
		
		Thread thread1=new Thread(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				while(true){
					System.out.println("in thread1,read a:"+bean.a);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
		thread1.start();
		
		Thread thread2=new Thread(new Runnable() {
			private int count=0;
			@Override
			public void run() {
				// TODO Auto-generated method stub
				while(true){
					System.out.println("in thread2");
					
					bean.a++;
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					count++;
					if(count==5){
						break;
					}
				}
			}
		});
		thread2.start();
		
		try {
			thread2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("asdfasdf");
	}
}
