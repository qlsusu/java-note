package test.thread;

public class TestInterrupt {
	private int a;
	
	public static void main(String[] args) {
		final TestInterrupt bean=new TestInterrupt();
		
		final Thread thread1=new Thread(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				while(true){
					System.out.println("in thread1,read a:"+bean.a);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						System.out.println("exception1");
						e.printStackTrace();
						break;
					}
				}
			}
		});
		thread1.start();
		
		Thread thread2=new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("in thread2");
				thread1.interrupt();
			}
		});
		thread2.start();
		
//		System.out.println("try to join thread1");
//		try {
//			thread1.join();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			System.out.println("exception2");
//			e.printStackTrace();
//		}
		
		System.out.println("in main something else");
	}
}
