package test;

import java.util.ArrayList;
import java.util.List;

public class ResultBean {
	public static class link {
		private String linkArea;
		private String linkUrl;

		public String getLinkArea() {
			return linkArea;
		}

		public String getLinkUrl() {
			return linkUrl;
		}

	}

	private String adtUrl;
	private List<link> links = new ArrayList<ResultBean.link>();

	public String getAdtUrl() {
		return adtUrl;
	}

	public List<link> getLinks() {
		return links;
	}

	public void setAdtUrl(String adtUrl) {
		this.adtUrl = adtUrl;
	}

}
