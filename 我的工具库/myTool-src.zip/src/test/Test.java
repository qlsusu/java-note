package test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.parsers.DocumentBuilderFactory;

import junit.framework.TestCase;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.ElementHandler;
import org.dom4j.ElementPath;
import org.dom4j.io.SAXReader;
import org.jsoup.Jsoup;
import org.jsoup.select.Elements;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import other.SignTool;
import bean.Bean;
import bean.Bean.InnerBean;
import bean.Father;
import bean.Implement1;
import bean.MyBean1;
import bean.NestList;
import bean.Number;
import bean.Number2;
import bean.Number3;
import bean.Number4;
import bean.Result;
import bean.Son;
import bean.That;
import bean.This;
import bean.This.Inner;
import bean.Weather;
import bean.json.array.BeanJ1;
import bean.json.array.BeanJ2;
import bean.json.father.BeanJFather;
import bean.json.father.BeanJSon;
import bean.json.replace.RBean;
import bean.json.replace.RBean.Implement;

import com.google.gson.reflect.TypeToken;
import com.ql.tool.Base64Tool;
import com.ql.tool.CoordinateTool;
import com.ql.tool.DBTool;
import com.ql.tool.DecimalTool;
import com.ql.tool.EncodeTool;
import com.ql.tool.EncryptTool;
import com.ql.tool.FileTool;
import com.ql.tool.JsonTool;
import com.ql.tool.JsonTool.Skip;
import com.ql.tool.ListTool;
import com.ql.tool.MD5;
import com.ql.tool.NetTool;
import com.ql.tool.NetTool.OnSendListener;
import com.ql.tool.NetTool.RequestInfo;
import com.ql.tool.NetTool.ResponseInfo;
import com.ql.tool.Printer;
import com.ql.tool.RandomTool;
import com.ql.tool.ReflectTool;
import com.ql.tool.RegExpTool;
import com.ql.tool.StringConverter;
import com.ql.tool.StringTool;
import com.ql.tool.SttGoogleTool;
import com.ql.tool.SttGoogleTool.TtsGoogleToolListener;
import com.ql.tool.TimeTool;
import com.ql.tool.XmlToolW3C;
import com.samsung.scrc.fileexplorer.entity.DB;
import com.samsung.scrc.fileexplorer.entity.Movie;
import com.samsung.scrc.fileexplorer.entity.Music;
import com.samsung.scrc.fileexplorer.entity.Photo;
import com.samsung.scrc.fileexplorer.rule.RuleConfig;
import com.samsung.scrc.fileexplorer.rule.RuleConfig.Rule.Item;

@SuppressWarnings("deprecation")
public class Test extends TestCase {
	@Override
	protected void setUp() throws Exception {
		// TODO Auto-generated method stub
		super.setUp();
		JsonTool.instance.init(null);
		Printer.instance.setPrint(true);
	}

	private class A {
	}

	private class B extends A {

	}

	@SuppressWarnings("unchecked")
	public void testJson() throws Exception {
		This bean = new This();
		bean.name = "this name";
		bean.that = new That();
		bean.that.setName("that name");
		String json = JsonTool.instance.toString(bean);
		System.out.println(json + "!!!!!!");
		bean = (This) JsonTool.instance.toObject(json, This.class);
		System.out.println("!!!!:" + bean.values);

		Object[] a = null;
		String[] c = null;
		a = c;

		List<Object[]> kk = null;
		List<String[]> kc = null;

		List<? extends A> alist = null;
		List<A> a2list = null;
		List<B> bList = null;
		alist = bList;
		alist = a2list;

		// User user = new User();
		// user.setAge(20);
		// user.setName("his");
		// user.setSex("male");
		//
		// String jsonString = JsonTool.instance.toString(user);

		// User u2 = (User) JsonTool.instance.toObject(jsonString, User.class);
		// System.out.println("age:" + u2.getAge());

		// List<Skip> skips = new ArrayList<>();
		// Skip skip = new Skip();
		// skip.setClz(Reason.class);
		// List<String> fields = new ArrayList<>();
		// fields.add("explanations");
		// skip.setFields(fields);
		// JsonTool.instance.init(skips);

		List<Skip> skips = new ArrayList<>();
		Skip skip = new Skip();
		skips.add(skip);
		skip.setClz(This.class);
		List<String> fields = new ArrayList<>();
		fields.add("name");
		skip.setFields(fields);

		skip = new Skip();
		skips.add(skip);
		skip.setClz(That.class);
		fields = new ArrayList<>();
		fields.add("name");
		skip.setFields(fields);
		JsonTool.instance.init(skips);

		JsonTool.instance.init(skips);
		System.out.println(JsonTool.instance.toString(bean));

		Map<String, String> map = new HashMap<>();
		map.put("key", "v");
		System.out.println(JsonTool.instance.toString(map));

		Set<Integer> set = new HashSet<>();
		set.add(1);
		set.add(2);
		System.out.println(JsonTool.instance.toString(set));

		String s = "[1,2]";
		set = (Set<Integer>) JsonTool.instance.toObject(s, new TypeToken<Set<Integer>>() {
		}.getType());
		System.out.println("set:" + set);

		Set<String> set2 = new HashSet<>();
		set2.add("1");
		System.out.println(JsonTool.instance.toString(set2));

		s = "michael jackson";
		System.out.println("urlencode:" + URLEncoder.encode(s, "utf-8"));

		JsonTool.instance.init();
		Bean3 b = new Bean3();
		b.age = 10;
		System.out.println(JsonTool.instance.toString(b));
	}

	class Bean3 {
		int age;
		Bean2 bean2;

		class Bean2 {
			String name;
		}
	}

	class Bean1 {
		int age;
		Bean2 bean2;
		private boolean isFine;

		class Bean2 {
			String name;
		}
	}

	public void testJson2() {
		This bean = new This();
		bean.age = 2;

		JsonTool.instance.init();
		System.out.println(JsonTool.instance.toString(bean));

		String s = "{\"age1asdfasdf\":2}";
		bean = (This) JsonTool.instance.toObject(s, This.class);
		System.out.println("age:" + bean.age);

		Bean1 b = new Bean1();
		b.age = 20;
		b.bean2 = b.new Bean2();
		b.bean2.name = "hello";
		System.out.println(JsonTool.instance.toString(b));

		Map<String, Bean1> map = new HashMap<>();
		map.put("1", b);

		System.out.println(JsonTool.instance.toString(map));

		Set<Integer> sets = new HashSet<>();
		sets.add(1);
		sets.add(2);
		System.out.println(sets);
		System.out.println(JsonTool.instance.toString(sets));

		Set<String> set2 = new HashSet<>();
		set2.add("1");
		set2.add("2");
		System.out.println(JsonTool.instance.toString(set2));
	}

	public void testJson3() {
		JsonTool.instance.init();

		MyBean1 bean = new MyBean1();
		bean.interface1 = new Implement1();

		String json = JsonTool.instance.toString(bean);
		bean = (MyBean1) JsonTool.instance.toObject(json, MyBean1.class);

		System.out.println(bean.interface1.toString());
	}

	public void testJson4() throws Exception {
		// JsonTool.instance.init();
		//
		// Bean bean = new Bean();
		// List<String> somes = new ArrayList<>();
		// somes.add("1");
		// bean.setSomes(somes);
		//
		// String data = JsonTool.instance.toString(bean);
		// bean = (Bean) JsonTool.instance.toObject(data, Bean.class);
		// System.out.println(bean.getSomes());
		//
		// String s = "%7B%22claims%22%3A%7B%7D%7D";
		// System.out.println(URLDecoder.decode(s, "utf-8"));
	}

	public void testJson5() throws Exception {
		JsonTool.instance.init();

		bean.Bean1 bean = (bean.Bean1) JsonTool.instance.toObject(new FileReader(new File("_data/test_json")), bean.Bean1.class);
		for (Object b : bean.getBeans()) {
			System.out.println(b);
		}
	}

	public void testJson6() throws Exception {
		Map<String, Class<?>> map = new HashMap<>();
		map.put("beans", Weather.class);
		map.put("otherBean", Weather.class);

		String s = new String(FileTool.getInstance().readContent("_data/test_json"));
		System.out.println("s:" + s);
		Result result = (Result) JsonTool.instance.toObject(s, Result.class, map);
		System.out.println(result.getOtherBean().getClass());
		System.out.println(result.getBeans());
	}

	public void testJson7() throws Exception {
		Result result = new Result();
		bean.Bean bean = new bean.Bean();
		result.getBeans().add(bean);
		result.setOtherBean(bean);
		result.setOtherBean2(bean);
		bean.setAge(21);
		InnerBean ib = new InnerBean();
		bean.setInner(ib);
		ib.setName("bill");
		String json = JsonTool.instance.toString(result);
		System.out.println("json:" + json);

		Map<String, Class<?>> map = new HashMap<>();
		map.put("otherBean.inner", InnerBean.class);
		map.put("otherBean2", bean.Bean.class);
		map.put("beans", bean.Bean.class);
		map.put("beans.inner", InnerBean.class);

		System.out.println("show result------------");
		ib = (InnerBean) result.getOtherBean().getInner();
		System.out.println("otherbean.inner.name:" + ib.getName());
		result = (Result) JsonTool.instance.toObject(json, Result.class, map);
		System.out.println("otherbean2.age:" + bean.getAge());
		bean = (bean.Bean) result.getBeans().get(0);
		System.out.println("beans.0.age:" + bean.getAge());
	}

	public void testJson8() throws Exception {
		JsonTool.instance.init();

		bean.Bean1 bean = (bean.Bean1) JsonTool.instance.toObject(new FileReader(new File("_data/test_json")), bean.Bean1.class);
		for (Object b : bean.getBeans()) {
			System.out.println(b);
		}
	}

	public void testJson9() {
		Bean1 bean1 = new Bean1();
		bean1.age = 20;
		String json = JsonTool.instance.toString(bean1);
		System.out.println(json);

		List<Skip> skips = new ArrayList<>();
		Skip skip = new Skip();
		skips.add(skip);
		skip.setClz(Bean1.class);
		skip.setFields(new ArrayList<>(Arrays.asList("age")));
		JsonTool.instance.setSkips(skips);

		System.out.println(JsonTool.instance.toString(bean1));
		;

		System.out.println(JsonTool.instance.getSkips().size());

		JsonTool.instance.setSkips(null);
		System.out.println(JsonTool.instance.toString(bean1));

		bean1 = (Bean1) JsonTool.instance.toObject(json, Bean1.class);
		System.out.println(bean1.age);
	}

	public void testJsonAboutArray1() {
		BeanJ1 beanJ1 = new BeanJ1();
		beanJ1.id = 1;
		BeanJ2 beanJ2 = new BeanJ2();
		beanJ2.name = "hello";
		beanJ1.beanJ2s = new BeanJ2[] { beanJ2 };
		System.out.println(JsonTool.instance.toString(beanJ1));
		System.out.println("---");
		beanJ1 = new BeanJ1();
		System.out.println(JsonTool.instance.toString(beanJ1));
		String json = "{}";
		beanJ1 = (BeanJ1) JsonTool.instance.toObject(json, BeanJ1.class);
		System.out.println(beanJ1.id);
	}

	public void testJsonAboutArray2() throws FileNotFoundException {
		BeanJ1 beanJ1 = (BeanJ1) JsonTool.instance.toObject(new FileReader(new File("_data/json/aboutArray1.txt")), BeanJ1.class);
		System.out.println(beanJ1.beanJ2s[0].name);
	}

	public void testJsonAboutArray3() throws FileNotFoundException {
		BeanJ1 beanJ1 = (BeanJ1) JsonTool.instance.toObject(new FileReader(new File("_data/json/aboutArray2.txt")), BeanJ1.class);
		System.out.println(beanJ1.beanJ2s == null);
	}

	public void testJsonAboutArray4() throws FileNotFoundException {
		BeanJ1 beanJ1 = (BeanJ1) JsonTool.instance.toObject(new FileReader(new File("_data/json/aboutArray3.txt")), BeanJ1.class);
		System.out.println(beanJ1.beanJ2s == null);
		System.out.println(beanJ1.beanJ2s.length);
	}

	public void testJsonAboutFather() {
		BeanJSon son = new BeanJSon();
		son.setId(1);
		son.setName("son");
		System.out.println(JsonTool.instance.toString(son));
	}

	@SuppressWarnings("unchecked")
	public void testJsonMap() {
		JsonTool.instance.init();

		Map<Integer, List<String>> map = new HashMap<>();
		map.put(1, Collections.singletonList("a"));
		String content = JsonTool.instance.toString(map);
		System.out.println(content);

		map = (Map<Integer, List<String>>) JsonTool.instance.toObject(content, new TypeToken<Map<Integer, List<String>>>() {
		}.getType());
		for (int key : map.keySet()) {
			System.out.println(key + ":" + map.get(key));
		}
	}

	public void testJsonList() {
		String s = "[1";
		JsonTool.instance.toList(s, Integer.class);
	}

	public void testNet() throws Exception {
		NetTool net = new NetTool();
		// net.sendData("http://192.168.1.160:9080/tom/data", "_data/max.xml");
		// net.getData("http://schema.org/Person");

		// System.out.println(net.encode("你好吗"));

		// byte[] data =
		// net.getData("http://www.google.com.sg/search?tbm=isch&source=hp&q=cat&btnG=Search+Images&biw=1920&bih=1075&ndsp=1");
		// System.out.println(new String(data));
		//
		// FileOutputStream fos = new FileOutputStream(new File("hello.txt"));
		// fos.write(data);
		// fos.close();

		String url = "http://www.wikidata.org/w/api.php?action=wbgetentities&ids=Q42&format=jsonfm";
		url = "http://test-hk-workbook.oss-cn-qingdao.jianyueyun.com/32/1/2015/32000002.png";
		// url =
		// "http://en.wikipedia.org/w/index.php?title=Douglas_Adams&action=edit";
		Map<String, String> params = new HashMap<>();
		params.put("q", "漯河");
		params.put("mode", "xml");
		url = "http://api.openweathermap.org/data/2.5/weather";
		url = net.generateRequestUrl(url, params);

		byte[] data = net.getData(url);

		// String s = "Slow-Cooker Veggie Chili";
		// System.out.println(net.encode(s));
	}

	public void testNet2() {
		Printer.instance.startLog("_data/log.txt");

		NetTool net = new NetTool();
		byte[] data = net.sendData("http://www.wikidata.org/w/api.php", "_data/wikidata_post.txt");
		// Printer.instance.log(new String(data));
		Printer.instance.endLog();
	}

	public void testNet3() {
		Printer.instance.setPrint(true);
		NetTool net = new NetTool();
		String url = "http://www.wikidata.org/w/api.php?action=wbcreateclaim&entity=Q2831&property=P345&snaktype=value&value=somevalue&bot=1&format=jsonfm";
		url = "http://www.wikidata.org/w/index.php?title=Special:AllPages&from=P197&namespace=120&format=xml";
		url = "http://www.wikidata.org/wiki/Special:AllPages/Property:";
		// net.getData(url);

		url = "http://www.earthtools.org/timezone/40.71417/-74.00639";
		url = "http://api.openweathermap.org/data/2.5/forecast/daily?cnt=7&q=NANJING&appid=34500dcf5727f519e48258a9297dd351&units=metric";
		url = "http://api.openweathermap.org/data/2.5/forecast/daily?cnt=7&q=NANJING&appid=34500dcf5727f519e48258a9297dd351&units=metric";
		url = "http://www.wikidata.org/w/api.php?action=wbgetclaims&entity=q22&format=json";
		url = "http://www.wikidata.org/wiki/Special:AllPages/Property:";
		url = "http://www.freebase.com/?schema";
		url = "http://www.freebase.com/music?schema";
		// net.getData(url);
		// HttpClientUtil.setProxy("127.0.0.1", 8087);
		System.out.println(new String(net.getDataUsingHttpClient(url)));
		;
	}

	private static class RequestBean implements RequestInfo {
		private int age;
		private String name;
		private String some;

		@Override
		public Map<String, String> getParamTransformMap() {
			// TODO Auto-generated method stub
			Map<String, String> map = new HashMap<>();
			map.put("name", "name_his");
			map.put("some", "some_his");

			return map;
		}

		@Override
		public List<String> getRequestFields() {
			// TODO Auto-generated method stub
			List<String> fields = new ArrayList<>();

			fields.add("age");
			fields.add("name");
			return fields;
		}
	}

	public static class ResponseBean implements ResponseInfo {

		@Override
		public Map<String, String> getParamTransformMap() {
			// TODO Auto-generated method stub
			return null;
		}

	}

	public void testNetParamTransformGet() {
		// 可以注释getParamTransformMap和getRequestFields，来看结果
		RequestBean requestBean = new RequestBean();
		requestBean.age = 1;
		requestBean.name = "abc cool name";
		requestBean.some = "456";

		new NetTool().send("http://hello", NetTool.HTTP_METHOD_GET, requestBean, ResponseBean.class, new OnSendListener() {

			@Override
			public void onNetOperationFail() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onNetError() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onGetResponse(ResponseInfo response) {
				// TODO Auto-generated method stub

			}
		});
	}

	public void testNetParamTransformPost() {
		// 可以注释getParamTransformMap和getRequestFields，来看结果
		RequestBean requestBean = new RequestBean();
		requestBean.age = 1;
		requestBean.name = "abc cool name";
		requestBean.some = "456";

		new NetTool().send("http://hello", NetTool.HTTP_METHOD_POST, requestBean, ResponseBean.class, new OnSendListener() {

			@Override
			public void onNetOperationFail() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onNetError() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onGetResponse(ResponseInfo response) {
				// TODO Auto-generated method stub

			}
		});
	}

	public void testWikidataLogin() throws Exception {
		@SuppressWarnings("deprecation")
		HttpClient client = new DefaultHttpClient();
		String url = "http://www.wikidata.org/w/api.php?format=xml";
		HttpPost request = new HttpPost(url);

		// 使用NameValuePair来保存要传递的Post参数
		List<NameValuePair> postParameters = new ArrayList<NameValuePair>();
		// 添加要传递的参数
		postParameters.add(new BasicNameValuePair("action", "login"));
		postParameters.add(new BasicNameValuePair("lgname", "qlsusu"));
		postParameters.add(new BasicNameValuePair("lgpassword", "susu1984"));

		// 实例化UrlEncodedFormEntity对象
		UrlEncodedFormEntity formEntity = new UrlEncodedFormEntity(postParameters);

		// 使用HttpPost对象来设置UrlEncodedFormEntity的Entity
		request.setEntity(formEntity);
		HttpResponse response = client.execute(request);

		// 获得token
		SAXReader reader = new SAXReader();
		Document document = reader.read(response.getEntity().getContent());
		Element root = document.getRootElement();
		Element e = root.element("login");
		String token = e.attributeValue("token");
		postParameters.add(new BasicNameValuePair("lgtoken", token));

		formEntity = new UrlEncodedFormEntity(postParameters);

		// 一次新的请求
		request = new HttpPost(url);
		// 使用HttpPost对象来设置UrlEncodedFormEntity的Entity
		request.setEntity(formEntity);
		response = client.execute(request);
		InputStream is = response.getEntity().getContent();
		byte[] data = new byte[1024];
		int len = -1;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		while ((len = is.read(data)) != -1) {
			bos.write(data, 0, len);
			bos.flush();
		}
		is.close();
		bos.close();
		data = bos.toByteArray();
		System.out.println("response:" + new String(data));
		//
		// BufferedWriter writer = new BufferedWriter(new FileWriter(new File(
		// "_data/wikidata_response.txt")));
		// writer.write(new String(data));
		// writer.flush();
		// writer.close();

		System.out.println("finish");
	}

	public void testHttpClient() throws Exception {
		@SuppressWarnings("deprecation")
		HttpClient client = new DefaultHttpClient();
		String url = "http://www.wikidata.org/w/api.php";
		HttpPost request = new HttpPost(url);
		// 使用NameValuePair来保存要传递的Post参数
		List<NameValuePair> postParameters = new ArrayList<NameValuePair>();
		// 添加要传递的参数
		postParameters.add(new BasicNameValuePair("action", "wbcreateclaim"));
		postParameters.add(new BasicNameValuePair("entity", "Q2831"));
		postParameters.add(new BasicNameValuePair("property", "P345"));
		postParameters.add(new BasicNameValuePair("snaktype", "value"));
		postParameters.add(new BasicNameValuePair("value", "\"avalue\""));
		// postParameters.add(new BasicNameValuePair("token",
		// "\"bc00f8d61b6e7ec51b47e2b8f5241734\""));
		// 实例化UrlEncodedFormEntity对象
		UrlEncodedFormEntity formEntity = new UrlEncodedFormEntity(postParameters);

		// 使用HttpPost对象来设置UrlEncodedFormEntity的Entity
		request.setEntity(formEntity);
		HttpResponse response = client.execute(request);
		InputStream is = response.getEntity().getContent();
		byte[] data = new byte[1024];
		int len = -1;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		while ((len = is.read(data)) != -1) {
			bos.write(data, 0, len);
			bos.flush();
		}
		is.close();
		bos.close();
		data = bos.toByteArray();
		System.out.println("response:" + new String(data));

		BufferedWriter writer = new BufferedWriter(new FileWriter(new File("_data/wikidata_response.txt")));
		writer.write(new String(data));
		writer.flush();
		writer.close();

		System.out.println("finish");
	}

	public void testWikidataApi() throws Exception {
		NetTool net = new NetTool();
		// net.sendData("http://192.168.1.160:9080/tom/data", "_data/max.xml");
		// net.getData("http://schema.org/Person");

		// System.out.println(net.encode("你好吗"));

		// byte[] data =
		// net.getData("http://www.google.com.sg/search?tbm=isch&source=hp&q=cat&btnG=Search+Images&biw=1920&bih=1075&ndsp=1");
		// System.out.println(new String(data));
		//
		// FileOutputStream fos = new FileOutputStream(new File("hello.txt"));
		// fos.write(data);
		// fos.close();

		String url = "https://www.wikidata.org/w/api.php?action=wbgetentities&ids=Q42&format=jsonfm";
		// url =
		// "http://en.wikipedia.org/w/index.php?title=Douglas_Adams&action=edit";

		byte[] data = net.getData(url);
		System.out.println(new String(data, "utf-8"));

		// String s = "Slow-Cooker Veggie Chili";
		// System.out.println(net.encode(s));
	}

	public class Clock {
		private int hour;
		private int minute;

		public int getHour() {
			return hour;
		}

		public void setHour(int hour) {
			this.hour = hour;
		}

		public int getMinute() {
			return minute;
		}

		public void setMinute(int minute) {
			this.minute = minute;
		}

	}

	public void testJsonClock() {
		Clock c = new Clock();
		c.hour = 12;
		c.minute = 20;

		// System.out.println(JsonTool.instance.toString(c));

		Action action = new Action();
		action.content = JsonTool.instance.toString(c);
		// System.out.println("action json:" +
		// JsonTool.instance.toString(action));
	}

	public void testJsonArray() throws Exception {
		JsonTool.instance.init();

		Map<String, List<Object>> map = (Map<String, List<Object>>) JsonTool.instance.toObject(new FileReader(new File("_data/jsonArray.txt")), new TypeToken<Map<String, List<Object>>>() {
		}.getType());
		for (String key : map.keySet()) {
			System.out.println(key);
			System.out.println(map.get(key));
		}
	}

	public static class BeanTest1 {
		private String helloWorld;
		private java.util.Date now = new java.util.Date();
		public String hello;
		public java.util.Date someDate = new java.util.Date();
	}

	public void testJsonFormat() {
		JsonTool.instance.init();
		JsonTool.instance.setOldFieldPattern(true);
		JsonTool.instance.excludeFieldsWithModifiers(Modifier.PRIVATE);
		JsonTool.instance.setDateFormat("yyyy-MM-dd");
		// JsonTool.instance.setFieldOldPattern(true);
		String src = new String(FileTool.getInstance().readContent("_data/json.txt"));

		BeanTest1 bean = (BeanTest1) JsonTool.instance.toObject(src, BeanTest1.class);
		System.out.println(bean.helloWorld);

		System.out.println(JsonTool.instance.toString(bean));

		bean = new BeanTest1();
		bean.helloWorld = "some";
		bean.hello = "slk;j";
		System.out.println(JsonTool.instance.toString(bean));
	}

	public void testJsonReplace() {
		RBean rBean = new RBean();

		rBean.name = "iname";
		bean.json.replace.RBean.Item item = new RBean.Item();
		rBean.items.add(item);
		item.path = "ipath";
		Implement implement = new Implement();
		item.some = implement;
		implement.age = 22;

		System.out.println(JsonTool.instance.toString(rBean));
	}

	public void testJsonReplace2() {
		// RBean rBean=new RBean();
		//
		// rBean.name="iname";
		// bean.json.replace.RBean.Item item=new RBean.Item();
		// rBean.items.add(item);
		// item.path="ipath";
		// Implement implement=new Implement();
		// item.some=implement;
		// implement.age=22;
		//
		// System.out.println(JsonTool.instance.toString(rBean));

		String file = "_data/json/replace/replace1.txt";
		Map<String, Class<?>> propToClz = new HashMap<>();
		propToClz.put("items.some", Implement.class);

		RBean rBean2 = (RBean) JsonTool.instance.toObject(new String(FileTool.getInstance().readContent(file)), RBean.class, propToClz);
		System.out.println(rBean2.items.get(0).some.getClass());
	}

	public void testJsonFather() {
		BeanJSon son = new BeanJSon();
		System.out.println(JsonTool.instance.toString(son));

		String json = "{\"id\": \"hello\"}";
		son = (BeanJSon) JsonTool.instance.toObject(json, BeanJSon.class);
		System.out.println(son.getId());
		System.out.println(son.getIdStr());
	}

	public class Action {
		private String content;
	}

	public void testAngle() {
		// System.out.println(Math.atan(1));
		// System.out.println(Math.PI / 4);
		// System.out.println(180 / Math.PI * Math.atan(1));
	}

	public void testResutTrans() throws Exception {
		FileInputStream fis = new FileInputStream(new File("_data/result.xml"));
		ResultBean result = (ResultBean) XmlToolW3C.getInstance().toBean(fis, ResultBean.class, null);
		// System.out.println("result is null?" + (result == null));

		// System.out.println(result.getAdtUrl());
		// System.out.println(result.getLinks().size());
		// System.out.println(result.getLinks().get(0).getLinkArea());
		// System.out.println(result.getLinks().get(0).getLinkUrl());

		// System.out.println(XmlToolW3C.getInstance().toXml(result));
	}

	public static class TtsHandlerData {
		private String amType;
		private String talkAnim;
		private String text;
		private String voice;

		public String getAmType() {
			return amType;
		}

		public String getTalkAnim() {
			return talkAnim;
		}

		public String getText() {
			return text;
		}

		public String getVoice() {
			return voice;
		}

	}

	public void testInnerClassName() {
		TtsHandlerData data = new TtsHandlerData();
		data.amType = "default";
		data.talkAnim = "tts_speak_1";
		data.text = "hello";
		data.voice = "voice";

		String json = JsonTool.instance.toString(data);
		// System.out.println("json:" + json);
		// System.out.println("class:" + data.getClass().getName());

		// FileTool.writeData("_data/json/json.txt", json.getBytes());
	}

	public void testReadFile() {
		// //System.out.println(new String(FileTool
		// .readContent("_data/json/json.txt")));
	}

	public void testAskBaiduZhidao() {
		long start = System.currentTimeMillis();
		String question = "天气怎么样吗";

		NetTool net = new NetTool();
		String host = "http://wapiknow.baidu.com";
		String url = host + "/index?rn=1&word=" + net.encode(question);
		byte[] resp = net.getData(url);
		url = null;
		if (resp != null && resp.length > 0) {
			BufferedReader reader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(resp)));
			String str = null;
			boolean isNearAnswer = false;
			try {
				while ((str = reader.readLine()) != null) {
					if (str.contains(">全部回答<")) {
						isNearAnswer = true;
					}
					if (isNearAnswer) {
						if (str.contains("href=\"/question")) {
							int begin = str.indexOf("href=\"/question") + "href=\"".length();
							int end = str.indexOf(">", begin) - "\"".length();
							url = host + str.substring(begin, end);
							break;
						}
					}
				}
				reader.close();

				// System.out.println("***********************************");
				if (!StringTool.isNull(url)) {
					resp = net.getData(url);
					reader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(resp)));

					boolean isAnswerStyle1 = false;
					String answer = null;
					isNearAnswer = false;
					while ((str = reader.readLine()) != null) {
						if (str.contains(">最佳答案<")) {
							isNearAnswer = true;
						} else if (str.contains(">推荐答案<")) {
							isNearAnswer = true;
						} else if (str.contains(">最佳推荐答案<")) {
							isNearAnswer = true;
						} else if (str.contains(">精彩回答<")) {
							isNearAnswer = true;
						}
						if (isNearAnswer) {
							if (isAnswerStyle1) {
								answer = str;
								break;
							}

							if (str.contains("<p class=\"ft\">")) {
								isAnswerStyle1 = true;
							} else if (str.contains("<p class=\"ft p1\">")) {
								int index = str.indexOf("<p class=\"ft p1\">") + "<p class=\"ft p1\">".length();
								answer = str.substring(index);
								break;
							}
						}
					}
					reader.close();

					// 去掉<br />等
					if (!StringTool.isNull(answer)) {
						answer = answer.replace("<br />", "\n");
						answer = answer.replace("<br/>", "\n");
						// System.out.println("answer:");
						// System.out.println(answer);
					} else {
						// System.out.println("answer is null");
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// System.out.println("take:" + (System.currentTimeMillis() - start));
	}

	public void testString() throws Exception {
		// String str = "hello";
		//
		// str="hello.world";
		// String[] ss=str.split("\\.");
		// for(String s:ss){
		// System.out.println(s);
		// }
		// // System.out.println(str.substring(0, 2));
		//
		// // 地址示例：江苏省南京市雨花台区丁墙路
		// // String address = "江苏省南京市雨花台区丁墙路";
		// //
		// // // String province, String city, String district
		// // final String provinceTag = "省";
		// // final String cityTag = "市";
		// // final String districtTag1 = "区";
		// // final String districtTag2 = "县";
		// //
		// // int proviceIndex = address.indexOf(provinceTag);
		// // String province = address.substring(0, proviceIndex);
		// // // System.out.println(province);
		// //
		// // int cityIndex = address.indexOf(cityTag, proviceIndex);
		// // String city = address.substring(proviceIndex + 1, cityIndex);
		// // // System.out.println(city);
		// //
		// // int districtIndex = address.indexOf(districtTag1, cityIndex);
		// // if (districtIndex == -1) {
		// // districtIndex = address.indexOf(districtTag2, cityIndex);
		// // }
		// // String district = address.substring(cityIndex + 1, districtIndex);
		// // // System.out.println(district);
		// //
		// // System.out.println(str.substring(0, 2));
		// // System.out.println(str.substring(0, 0));
		//
		// System.out.println(URLDecoder.decode("Shinkage-ry%C5%AB", "utf-8"));
		//
		// Set<Integer> set = new HashSet<>();
		// set.add(1);
		// set.add(2);
		// System.out.println(set);
		//
		// System.out.println(StringTool.firstCharLow("HelloWorld", true));
		//
		// String s = "hello";
		// System.out.println(s + null);

		System.out.println("jkalsjdf;askjdf;");

		String s = "2014-10-25 10:40:25";
		System.out.println(s.split(":").length);

		s = "http://pubsub-1.pubnub.com/publish/pub-c-9d0d75a5-38db-404f-ac2a-884e18b041d8/sub-c-4e25fb64-37c7-11e5-a477-0619f8945a4f/0/qlsusu/0/%7B%22packet%22%3A%7B%22sdpMLineIndex%22%3A0%2C%22sdpMid%22%3A%22audio%22%2C%22candidate%22%3A%22candidate%3A2606308245%201%20udp%201686052607%20121.237.189.239%2023570%20typ%20srflx%20raddr%20172.23.58.2%20rport%2041885%20generation%200%22%7D%2C%22id%22%3A%22%22%2C%22number%22%3A%22Kevin%22%7D?pnsdk=%28Android%206.0%3B%20HUAWEI%20NXT-AL10%20Build%29%20PubNub-Java%2FAndroid%2F";
		s = "/publish/pub-c-9d0d75a5-38db-404f-ac2a-884e18b041d8/sub-c-4e25fb64-37c7-11e5-a477-0619f8945a4f/0yi/0/%7B%22packet%22%3A%7B%22sdpMLineIndex%22%3A0%2C%22sdpMid%22%3A%22audio%22%2C%22candidate%22%3A%22candidate%3A602242288%202%20udp%201686052606%20121.237.189.239%2021749%20typ%20srflx%20raddr%20172.23.58.3%20rport%2057468%20generation%200%22%7D%2C%22id%22%3A%22%22%2C%22number%22%3A%22Kevin%22%7D?pnsdk=%28Android%206.0.1%3B%20MI%20NOTE%20LTE%20Build%29%20PubNub-Java%2FAndroid%2F";
		System.out.println(URLDecoder.decode(s, "utf-8"));

		System.out.println("hello".indexOf("h"));
	}

	public void testString2() {
		String s = "abc_edf_dfasda";
		String[] ss = s.split("_");
		for (String str : ss) {
			System.out.println(str);
		}

		System.out.println("right here");
		System.out.println("because of it");

		s = "2014-10-25 10:40";
		System.out.println(s.split(":").length);
	}

	public void testString3() {
		System.out.println("asdfasdfa");

		String s = "\"hello\"";
		int start = s.indexOf("\"") + 1;
		System.out.println(start);
		int end = s.indexOf("\"", start);
		System.out.println(end);
		System.out.println(s.substring(start, end));
	}

	public void testString4() {
		String a = "hello{13}";
		int start = a.indexOf("{");
		int end = a.indexOf("}", start);
		System.out.println(a.substring(start + 1, end));
	}

	public void testString5() throws Exception {
		String a = "lasjdf.mp3";
		int index = a.lastIndexOf(".");
		System.out.println(a.substring(0, index));
		System.out.println(a.substring(index));

		String b = "		我们	还有";
		System.out.println(b.startsWith("\t\t"));
		System.out.println("this is the right thing all above");

		a = "http://hello/abc";
		System.out.println(a.substring(a.lastIndexOf("/")));

		System.out.println(URLDecoder.decode("\u65e5\u672c", "utf-8"));

		a = ",";
		a = "=";
		System.out.println(URLEncoder.encode(a, "utf-8"));
	}

	public void testString6() throws Exception {
		String file = "_data/p.txt";

		FileWriter writer = new FileWriter(new File(file));

		String s = "name=Most%C3%B3wek,settlement_type=Village,total_type=%26amp%3Bnbsp%3B,coordinates_region=PL,subdivision_type=%5B%5BCountries+of+the+world%7CCountry%5D%5D,subdivision_name=%7B%7Bflag+icon%7CPoland%7D%7D+%5B%5BPoland%5D%5D,subdivision_type1=%5B%5BVoivodeships+of+Poland%7CVoivodeship%5D%5D,subdivision_name1=%5B%5BMasovian+Voivodeship%7CMasovian%5D%5D,subdivision_type2=%5B%5BPowiat%7CCounty%5D%5D,subdivision_name2=%5B%5BOstro%C5%82%C4%99ka+County%5D%5D,subdivision_type3=%5B%5BGmina%5D%5D,subdivision_name3=%5B%5BGmina+Olszewo-Borki%7COlszewo-Borki%5D%5D,pushpin_map=Poland,latd=53,latm=8,latNS=N,longd=21,longm=22,longEW=E";
		String[] pairs = s.split(",");
		for (String p : pairs) {
			String[] kv = p.split("=");
			writer.write("key:" + kv[0] + "\n");
			writer.write(URLDecoder.decode(kv[1], "utf-8") + "\n");
		}

		writer.close();
	}

	public void testString7() throws Exception {
		List<This> beans = new ArrayList<>();
		This bean = new This();
		beans.add(bean);
		bean.name = "bill";

		System.out.println(beans);

		JsonTool.instance.init();
		System.out.println(JsonTool.instance.toString(beans));

		String s = bean.name;
		System.out.println(s.substring(0, s.length() - 1));

		s = "--><ref>(1) Gibbs ([1877], 1967)  <br>(1.1) D'Wamish on the Lake Fork of the D'Wamish River, 152; Sa-ma-mish (Sammamish) and S'kel-tehl-mish on the D'Wamish Lake (now Lake Washington) and environs, 101.  These are the treaty-era names as they appeared.  For simplicity, they are not otherwise mentioned in the article.  <br>(2)  Cf. Boyd (1999)</ref><ref name=Roxberger_in_Davis>Roxberger in Davis (1994), pp. 172&ndash;3</ref>";
		int start = s.indexOf("<");
		int end = s.indexOf(">", start) + 1;
		System.out.println(s.substring(start, end));

		s = "hehllo";
		System.out.println(s.indexOf("h", 1));

		List<Integer> ids = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			ids.add(i);
		}
		if (!ids.isEmpty()) {
			String idsStr = ids.toString();
			idsStr = idsStr.substring(1, idsStr.length() - 1);
			String sql = "SELECT item_id FROM extract_result2 WHERE item_id in (" + idsStr + ")";
			System.out.println(sql);
		}

		System.out.println(URLEncoder.encode("\\x", "utf-8"));

		System.out.println(URLEncoder.encode("Los Angeles", "utf-8"));

		ids = new ArrayList<>();
		ids.add(new Integer(1));
		System.out.println(ids);

		System.out.println("-----------");
		s = "hello,nihao";
		String[] ss = s.split(",");
		for (String str : ss) {
			System.out.println(str);
		}

		s = "[]";
		ss = s.substring(1, s.length() - 1).split(",");
		System.out.println(ss.length);
		System.out.println(ss[0]);
	}

	public void testString8() {
		String line = "hello (,w,'enwiki',asdf),(woasldjf,'hayou,',women),(asdfaf,'enwiki',asldfjk),(asdfasdf,'enwiki',asdfasdf);";

		List<String> datas = new ArrayList<>();

		int from = -1;
		int index = -1;
		while ((index = line.indexOf("'enwiki'", from)) != -1) {
			int start = line.lastIndexOf("(", index);
			int end = line.indexOf("),", index) + 1;
			if (end == 0) {
				end = line.indexOf(");", index) + 1;
			}
			System.out.println(line.substring(start, end));
			from = index + 1;
		}

		line = "hello=a;b";
		System.out.println(line.substring("hello=".length()));

		line = "hello&wohen";
		String[] ss = line.split("&");
		for (String s : ss) {
			System.out.println(s);
		}

		System.out.println(URLDecoder.decode("2014-06-25+10%3A01%3A00"));
		System.out.println(URLDecoder.decode("2014-06-25+12%3A03%3A50"));

		String s = "hello<!--nihaoasdfqwerqwerqw--><111asdflkja;sdf>asdfasdf<asdf1>";
		System.out.println(s.replaceAll("<!--[^>]*-->", ""));

		s = "asafa.  1729";
		System.out.println(s.indexOf("."));
	}

	public void testString9() throws Exception {
		JsonTool.instance.init();

		Map<String, String> map = new HashMap<>();
		map.put("1", "2");

		System.out.println(JsonTool.instance.toString(map));
		System.out.println(map);

		System.out.println(Inner.class.getName());

		String s = "[abc]";
		String[] ss = s.split(",");
		for (String str : ss) {
			System.out.println(str);
		}

		System.out.println(URLDecoder.decode("birth_date", "utf-8"));
		System.out.println(URLEncoder.encode("birth date", "utf-8"));

		String content = "nihabcedf";

		String head = content.substring(0, 3);
		String body = "";
		for (int i = 0; i < 5 - 3 + 1; i++) {
			body += " ";
		}
		String tail = content.substring(5 + 1);
		content = head + body + tail;
		System.out.println("content:" + content);

		System.out.println(URLDecoder.decode("two+24-piece+boxes", "utf-8"));
		System.out.println(URLDecoder.decode("ec-2fm40717db218270s", "utf-8"));

		System.out.println(URLEncoder.encode("정보", "utf-8"));

		s = "G-Dragon_in_Thailand.jpg";
		System.out.println(URLDecoder.decode(s, "utf-8"));

		s = "helo=world";
		ss = s.split("=");
		System.out.println(ss[0]);
		System.out.println(ss[1]);

		s = "<p1>helloasdfasdfasdf</p1>abc";
		System.out.println(StringTool.removeHtmlTag(s));

		System.out.println("----");
		s = "12   N,  45e ";
		// s="12N";
		// s="xxx";
		s = "51:37:01";
		s = "51:37:01N, 3:56:26W";

		ss = s.split("(?i)[(north)|n|(south)|s|(east)|e|(west)|w]");
		// ss = s.split("(?i)[°|º|'|′|’|\"|″|_|:]");
		System.out.println("ss size:" + ss.length);
		for (String str : ss) {
			System.out.println(str);
		}

		String line = "enwiki','3\'(2\\'), ";
		int end = line.indexOf("')");
		System.out.println(line.charAt(end - 1) == "\\".charAt(0));
		System.out.println(line.charAt(end - 1));
		System.out.println("\\".charAt(0));

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println(sdf.format(new java.util.Date(1245859200000l)));

		System.out.println(URLEncoder.encode("hello world", "utf-8"));
	}

	public void testString10() {
		String s = "Recorded|Recorded|Recorded";
		String[] ss = s.split("\\|");

		List<String> list = new ArrayList<>();
		for (String str : ss) {
			String[] ss2 = str.split(":");
			list.add("\"" + ss2[ss2.length - 1] + "\"");
		}

		System.out.println(list);
	}

	public void testString11() throws Exception {
		String template = "";
		String keys = "";
		String langs = "";
		for (int i = 0; i < 9; i++) {
			template += "\"Infobox city\",";
			keys += "\"twin" + (i + 1) + "\",";
			langs += "\"en" + "\",";
		}
		System.out.println(template);
		System.out.println(keys);
		System.out.println(langs);

		String s = "Modèle:Infobox Métier ";
		System.out.println(StringTool.trim(s));

		s = "- ! Song !! Singer(s)";
		String[] ss = s.split("!+");
		for (String str : ss) {
			System.out.println(str);
		}

		String title = "michale_jackson";
		System.out.println(URLDecoder.decode(title, "utf-8"));

		s = "music/artist";
		System.out.println(s.substring(0, s.indexOf("/")));

		s = "hello world";
		System.out.println(URLDecoder.decode(s, "utf-8"));

		s = "nihao helloworld wohen";
		List<String> list = new ArrayList<>(Arrays.asList(s.split("helloworld")));
		System.out.println(list);
	}

	public void testString12() {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();

		// 边界
		final String BOUNDARY = UUID.randomUUID().toString();
		final String PREFIX = "--";
		// 换行符
		final String LINE_END = "\r\n";

		StringBuffer requestBuf = new StringBuffer();
		// 写入格式相关
		requestBuf.append(PREFIX + BOUNDARY + LINE_END);
		requestBuf.append("Content-Disposition: form-data; name=\"userfile\"; filename=\"workAttachment.jpg\"" + LINE_END);
		requestBuf.append("Content-Type: image/jpeg; charset=UTF-8" + LINE_END);
		requestBuf.append("Content-Transfer-Encoding: binary" + LINE_END);
		try {
			requestBuf.append(LINE_END);
			bos.write(requestBuf.toString().getBytes());
			// 写入附件信息
			byte[] data = new byte[1024];
			int len = -1;
			InputStream attachIs = new ByteArrayInputStream("attachdata".getBytes());
			while ((len = attachIs.read(data)) != -1) {
				bos.write(data, 0, len);
			}
			// 写入格式相关信息
			requestBuf = new StringBuffer();
			requestBuf.append(LINE_END);
			requestBuf.append(LINE_END);

			requestBuf.append(PREFIX + BOUNDARY + LINE_END);
			requestBuf.append("Content-Disposition: form-data; name=\"userjson\"" + LINE_END);
			requestBuf.append("Content-Type: text/plain; charset=UTF-8" + LINE_END);
			requestBuf.append("Content-Transfer-Encoding: 8bit" + LINE_END);
			requestBuf.append(LINE_END);

			String requestJsonWhole = "{hello:world}";
			if (requestJsonWhole != null) {
				if (requestJsonWhole.equals("{}")) {
					requestJsonWhole = "";
				}
				requestBuf.append(requestJsonWhole + LINE_END);
			}
			requestBuf.append(LINE_END);
			requestBuf.append(PREFIX + BOUNDARY + PREFIX + LINE_END);

			bos.write(requestBuf.toString().getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.print(new String(bos.toByteArray()));
	}

	public void testString13() {
		String src = "asdfasdf,\n\t" + "id=1\n" + "}]";
		System.out.println(src);

		src = src.replaceAll(",\n\tid=1", "");
		System.out.println("src:" + src);

	}

	public void testRemoveHtmlTag() {
		String s = " any item type<br />";
		System.out.println(StringTool.removeHtmlTag(s));
	}

	public void testCalandar() throws ParseException {
		Calendar ca = Calendar.getInstance();
		ca.setTime(new SimpleDateFormat("MM/dd HH:mm").parse("12/11 23:45"));
		System.out.println(ca.get(Calendar.DAY_OF_MONTH));
		System.out.println(ca.get(Calendar.HOUR_OF_DAY));
		// System.out.println(ca.get(Calendar.MINUTE));

		// long delay = ((clock.getHour() * 60 + clock.getMinute()) - (ca
		// .get(Calendar.HOUR) * 60 + ca.get(Calendar.MINUTE))) * 60000;
	}

	public void testTime() throws Exception {
		long time = System.currentTimeMillis();
		final Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(time);

		// System.out.println("year:" + calendar.get(Calendar.YEAR));
		// System.out.println("month:" + calendar.get(Calendar.MONTH));
		// System.out.println("day:" + calendar.get(Calendar.DAY_OF_MONTH));
		// System.out.println("day in week:" +
		// calendar.get(Calendar.DAY_OF_WEEK));
		// System.out.println("hour:" + calendar.get(Calendar.HOUR_OF_DAY));
		// System.out.println("m:" + calendar.get(Calendar.MINUTE));

		java.util.Date date = new java.util.Date();
		System.out.println(date.getHours());

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyy-MMMMM-dd", Locale.ENGLISH);

		String desc = "1631-December-9";
		date = sdf.parse(desc);

		sdf = new SimpleDateFormat("MMMM. dd, yyyy", Locale.ENGLISH);
		System.out.println(sdf.format(date));
		System.out.println(sdf.parse("Sep. 23, 1924").getTime());

		sdf = new SimpleDateFormat("MMMMM dd, yyyy", Locale.ENGLISH);
		// sdf.parse("December 2, 1982").getTime();
		// sdf.parse("April 1, 1980").getTime();
		sdf.parse("April 1, 1980").getTime();

		String s = "27 May";
		sdf = new SimpleDateFormat("dd MMMMM", Locale.ENGLISH);
		sdf.parse(s);

		s = "October 20, 2005";
		sdf = new SimpleDateFormat("MMMMM dd, yyyy", Locale.ENGLISH);
		sdf.parse(s);

		s = "3 January";
		sdf = new SimpleDateFormat("dd MMMMM", Locale.ENGLISH);
		sdf.parse(s);

		s = "1985 abc";
		sdf = new SimpleDateFormat("yyyy", Locale.ENGLISH);
		sdf.parse(s);

		sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.KOREAN);
		System.out.println(sdf.format(new java.util.Date(1414235432558l)));
		System.out.println(sdf.parse("2014-10-25 10:40:25").getTime());
		System.out.println(1414235432558l - 1414204825000l);

		// 2014-10-25 10:40:25
		// [2014-10-25 10:40:25 Thread[http-bio-8080-exec-8,5,main]] -
		// unitToGive:4000,infobox
		// [2014-10-25 10:40:25 Thread[http-bio-8080-exec-8,5,main]] -
		// unitToGive:10,table
		// [2014-10-25 10:40:30 Thread[http-bio-8080-exec-8,5,main]] -
		// unitToGive:1000,nlp
		// 2014-10-25 11:10:32 Thread[http-bio-8080-exec-6,5,main]] -
		// done:infobox,1414235432558
		// [2014-10-25 12:04:37 Thread[http-bio-8080-exec-12,5,main]] -
		// done:table,1414238677132
		// [2014-10-25 11:45:07 Thread[http-bio-8080-exec-1,5,main]] -
		// done:nlp,1414237507626

		System.out.println(TimeTool.getInstance().getDesc());
		System.out.println(TimeTool.getInstance().getFullDesc());

		DateFormat dateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.ENGLISH);
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		System.out.println(dateFormat.format(new java.util.Date(System.currentTimeMillis())));

		System.out.println(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date(0)));
	}

	public void testTime2() {
		long time = 1439301571000l;
		System.out.println(TimeTool.getInstance().getFullDesc(new java.util.Date(time)));
	}

	public void testWeatherRutine() {
		// net.getData("http://www.google.com/ig/api?weather=Beijing");

		NetTool net = new NetTool();
		// 获取 省代码
		net.getData("http://m.weather.com.cn/data5/city.xml");
		// System.out.println();

		// 获取 市代码
		net.getData("http://m.weather.com.cn/data5/city22.xml");
		// System.out.println();

		// 获取 区代码
		net.getData("http://m.weather.com.cn/data5/city2210.xml");
		// System.out.println();

		// 获取 具体代码
		net.getData("http://m.weather.com.cn/data5/city221001.xml");
		// System.out.println();

		// 获取 天气（6天）
		// 参见：http://www.weather.com.cn/weather/101190104.shtml?
		net.getData("http://m.weather.com.cn/data/" + "101190104" + ".html");
	}

	// public void testGetCityCode() {
	// NetTool net = new NetTool();
	// String data = new String(
	// net.getData("http://m.weather.com.cn/data5/city.xml"));
	// data = data.replace("|", "_");
	// String[] ss = data.split(",");
	// for (String s : ss) {
	// String[] ss2 = s.split("_");
	// //System.out.println("get city code for:" + ss2[1]);
	// getCityCode(ss2[0], ss2[1]);
	// }
	// //System.out.println("testGetCityCode finish");
	// }

	public void testGetCityAddress() {
		// 新街口的经纬度
		double lat = 32.047745;
		double lng = 118.79158;
		String key = "sq17MTbpas5L8lOSEFGzHdlN";

		NetTool net = new NetTool();
		net.getData("http://api.map.baidu.com/geocoder?location=" + lat + "," + lng + "&output=xml&key=" + key);
	}

	// public void testWeatherAPI() {
	// WeatherTool weatherTool = WeatherTool.getInstance();
	// weatherTool.getWeather(32.047745, 118.79158);
	// }

	public void testRegExp() {
		// String reg = "[/ \t\r\n]";
		// String content = "hello world";

		String source = "[$parent]提交了[$course][$workbook]的作业";
		String reg = "\\[\\$.+?\\]";

		System.out.println(RegExpTool.instance.match(source, reg).size());

		System.out.println(RegExpTool.instance.match(source, reg));

		// System.out.println(content.replaceAll(reg, "_"));

	}

	public void testCollections() {
		String s = "hello";
		System.out.println(Collections.singleton(s));
		System.out.println(Collections.singletonList(s));
	}

	public void testWhetherSupperClz() {
		System.out.println(Father.class.isAssignableFrom(Son.class));
		System.out.println(Father.class.isAssignableFrom(Father.class));
		System.out.println(Son.class.isAssignableFrom(Father.class));
	}

	public void testList() {
		List<String> list = new ArrayList<>();
		list.add("1");
		list.add("2");
		list.add("3");
		list.add("4");
		System.out.println(list.subList(0, 2));
		System.out.println(list.subList(2, 4));
		System.out.println(list.subList(0, 4));
		System.out.println("----");

		List<List<?>> lists = ListTool.instance.splitList(list, 5);
		for (List<?> l : lists) {
			System.out.println(l);
		}

		System.out.println(list.subList(0, 1 + 1));
		System.out.println(list.subList(4, 4));

		list.add(4, "5");
		System.out.println(list);

		String s = "hello";
		list.add(s);
		System.out.println(list);
		list.add(s);
		System.out.println(list);

		List<Integer> intList = new ArrayList<>();
		Integer a = new Integer(5);
		intList.add(a);
		System.out.println(intList);
		intList.add(a);
		System.out.println(intList);
	}

	public void testList2() {
		List<String> list = new ArrayList<>();
		list.add("hello");
		list.add("ADFA");
		list.add("alsjdfljasdlfk");
		System.out.println("list:" + list);

		System.out.println(list.subList(1, 1 + 1));
	}

	public void testList3() {
		List<String> list = new ArrayList<>();
		list.add("hello");
		list.add("hellasdfasdo");
		list.add(1, "asdfas");
		System.out.println("list:" + list);
	}

	public void testList4() {
		List<String> list = new ArrayList<>();
		list.add("hello");
		list.add("hello2");
		list.add("hello3");
		list.add("hello4");

		System.out.println(list.subList(list.indexOf("hello2"), list.size()));
		System.out.println(list.subList(0, list.indexOf("hello2") + 1));

		System.out.println(list.subList(0, 2));
		System.out.println(list.subList(2, 4));

		String s1 = null;
		list.add(s1);
		list.add(null);
		System.out.println(list);

		list.clear();
		list.add("1");
		list.add("1");
		System.out.println(list);
		list.remove("1");
		System.out.println(list);
	}

	public void testList5() {
		String[] TEMPLATES = new String[] { "yyyy-MM-dd", "yyyy-MMMMM-dd", "dd MMMMM yyyy", "EEEEE, MMMMM dd, yyyy", "EEEEE, dd MMMMM yyyy", "EEEEE MMMMM dd, yyyy", "EEEEE dd MMMMM yyyy", "MMMMM dd, yyyy", "MMMMMdd, yyyy", "MMMMM, dd yyyy", "MMM. dd, yyyy", "MMM. yyyy", "dd MMMMM, yyyy", "dd MMMMM", "MMMMM yyyy", "MMMMM, yyyy", "MMMMM,yyyy", "yyyy" };
		List<String> ts = new ArrayList<>();

		for (String t : TEMPLATES) {
			t = t.replace("_", " ").replace("-", " ");
			if (!ts.contains(t)) {
				ts.add(t);
			}
		}
		StringBuffer buf = new StringBuffer();
		for (String t : ts) {
			buf.append("\"" + t + "\",");
		}
		System.out.println(buf);

		List<String> lists = new ArrayList<>(Arrays.asList("1", "2", "3"));
		System.out.println(lists.subList(0, 2));

		List<String> others = new ArrayList<>(Arrays.asList("4", "5"));
		lists.addAll(0, others);
		System.out.println(lists);
	}

	public void testThreadPool() throws Exception {
		final CountDownLatch latch = new CountDownLatch(1);

		ScheduledExecutorService threadPool = Executors.newSingleThreadScheduledExecutor();
		threadPool.schedule(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println(System.currentTimeMillis());
				System.out.println("right here");
				latch.countDown();
			}
		}, 1000, TimeUnit.MILLISECONDS);

		System.out.println(System.currentTimeMillis());
		latch.await();
	}

	public void testDouble() {
		double a = 9.30899841478e-05;
		System.out.println(a);
		System.out.println(a > 1);
	}

	public void testDate() throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH:mm:ss");
		// java.util.Date date = sdf.parse("2013.12.31.23:59:59");
		java.util.Date date = sdf.parse("2013.08.20.23:59:59");
		System.out.println(date.getTime());

		sdf = new SimpleDateFormat("yyyyMMdd");
		date = sdf.parse("20140201");
		System.out.println(date.getTime());
		System.out.println(sdf.format(new java.util.Date(1401879600000l)));

		String s = "\".*\"May 2, 2009asdfasdfasdfad";
		sdf = new SimpleDateFormat("\".*\"MMMMM dd, yyyy", Locale.ENGLISH);
		sdf.parse(s);

		s = "Consolidation completed July 1, 2000";
		for (String str : s.split(" ")) {
			System.out.println(str);
		}

		System.out.println(new SimpleDateFormat("yyMMdd").format(new java.util.Date()));

		System.out.println(new Date(0).equals(new Date(0)));

		System.out.println(new Date(System.currentTimeMillis()));

		DateFormat dateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.ENGLISH);
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		System.out.println(dateFormat.format(new java.util.Date(System.currentTimeMillis())));
	}

	public void testFile() {
		String dir = "E:/wikidata_dump/20140705/incre/";
		List<File> fs = Arrays.asList(new File(dir).listFiles(new FileFilter() {
			@Override
			public boolean accept(File file) {
				// TODO Auto-generated method stub
				if (file.isFile() && file.getName().endsWith("-pages-meta-hist-incr.xml.bz2")) {
					return true;
				}

				return false;
			}
		}));
		Collections.sort(fs, new Comparator<File>() {
			@Override
			public int compare(File o1, File o2) {
				// TODO Auto-generated method stub
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

				final String prefix = "wikidatawiki-";
				final String postfix = "-pages-meta-hist-incr.xml.bz2";
				String name = null;

				name = o1.getName();
				String d1 = name.substring(name.indexOf(prefix) + prefix.length(), name.lastIndexOf(postfix));
				name = o2.getName();
				String d2 = name.substring(name.indexOf(prefix) + prefix.length(), name.lastIndexOf(postfix));

				try {
					return (int) (sdf.parse(d1).getTime() - sdf.parse(d2).getTime());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return 0;
			}
		});

		for (File f : fs) {
			System.out.println(f.getName());
		}
	}

	public void testFile2() throws Exception {
		String file = "E:/wikipedia_dump/qianwei_140903/wikipedia_wikidata.sql";

		BufferedReader reader = new BufferedReader(new FileReader(new File(file)));
		String data = null;
		int count = 0;
		while ((data = reader.readLine()) != null) {
			System.out.println(data);
			count++;
			if (count == 50) {
				break;
			}
		}
		reader.close();
	}

	public void testFile3() {
		String dir = "/Users/qlong/Downloads/新壁纸";
		String content = "";
		for (File f : new File(dir).listFiles()) {
			content += "\"" + f.getName() + "\",";
		}
		System.out.println(content);
	}

	public void testFileExplorer() throws Exception {
		DB db = new DB();

		Music music = new Music();
		Field[] fs = music.getClass().getDeclaredFields();
		for (Field f : fs) {
			f.setAccessible(true);
			f.set(music, "");
		}
		db.getMusics().add(music);

		Movie movie = new Movie();
		fs = movie.getClass().getDeclaredFields();
		for (Field f : fs) {
			f.setAccessible(true);
			f.set(movie, "");
		}
		db.getMovies().add(movie);

		Photo photo = new Photo();
		fs = photo.getClass().getDeclaredFields();
		for (Field f : fs) {
			f.setAccessible(true);
			f.set(photo, "");
		}
		db.getPhotos().add(photo);

		System.out.println(XmlToolW3C.getInstance().toXml(db));
	}

	public void testRule() throws Exception {
		RuleConfig config = (RuleConfig) XmlToolW3C.getInstance().toBean(new FileInputStream(new File("_data/rule_config.xml")), RuleConfig.class, null);
		Item item = config.rules.get(0).items.get(1);
		System.out.println(item.field1);
		System.out.println(item.field2);
		System.out.println(item.operator);

	}

	public void testXml() {
		Field[] fs = Son.class.getDeclaredFields();

		for (Field f : fs) {
			System.out.println(f.getName());
		}

		List<String> list = new ArrayList<>();
		list.add("a");
		list.add("");
		list.add("b");
		System.out.println(list);

		NestList bean1 = new NestList();
		list.clear();
		list.add("a");
		bean1.list.addAll(list);
		// bean.lists.add(list);
		System.out.println(XmlToolW3C.getInstance().toXml(bean1));

		List<This> beans = new ArrayList<>();
		This bean = new This();
		bean.name = "bill";
		beans.add(bean);
		System.out.println(XmlToolW3C.getInstance().toXml(beans));
		JsonTool.instance.init();

		System.out.println(JsonTool.instance.toString(beans));

		String str = "[{\"name\":\"bill\",\"age\":0}]";
		beans = (List<This>) JsonTool.instance.toObject(str, new TypeToken<List<This>>() {
		}.getType());
		System.out.println(beans.get(0).name);
	}

	public void testXmlParse() throws Exception {
		String file = "_data/time.xml";

		org.w3c.dom.Element root = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new FileInputStream(new File(file))).getDocumentElement();
		System.out.println(root.getNodeName());
		System.out.println(root.getAttribute("hello1"));
		;

		NodeList children = root.getChildNodes();

		for (int i = 0; i < children.getLength(); i++) {
			Node node = children.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE && node.getNodeName().equals("utctime")) {
				org.w3c.dom.Element e = (org.w3c.dom.Element) node;
				String content = e.getTextContent();
				if (!StringTool.isNull(content)) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String time = sdf.parse(content).getTime() + "";
					for (int j = 0; j < 3; j++) {
						time += RandomTool.getInstance().getNumber(10);
					}

					System.out.println(time);
					System.out.println("2014031110430001");
				}

				break;
			}
		}
	}

	public void testXml2() {
		Bean bean = new Bean();
		bean.setAge(12);

		System.out.println(XmlToolW3C.getInstance().toXml(bean));
	}

	public void testSubList() {
		List<String> list = new ArrayList<>();
		list.add("hello");
		list.add("2");
		list.add("3");

		System.out.println(list.subList(1, 5));
	}

	public void testSet() {
		String s = "hello";
		Set<String> set = new HashSet<>();

		set.add(s);
		set.add("1");
		set.add("hello");
		System.out.println(set);

		s = "hello";
		set.add(s);
		System.out.println(set);

		Set<Bean> set2 = new HashSet<>();
		Bean bean = new Bean();
		// bean.setName("hello");
		set2.add(bean);
		set2.add(bean);
		set2.add(null);
		System.out.println(set2.size());

	}

	public void testCompress() throws Exception, IOException {
		String name = "d:/_study/_data/wikidata/dump/20140106/wikidatawiki-20140106-wb_entity_per_page.sql.gz";
		name = "d:/_study/_data/wikidata/dump/20140106/wikidatawiki-20140106-pages-meta-current.xml.bz2";
		name = "d:/_study/_data/wikidata/dump/20140106/wikidatawiki-20140106-wb_terms.sql.gz";
		name = "E:/wikidata_dump/20140106/wikidatawiki-20140106-pages-meta-current.xml.bz2";
		name = "E:/wikidata_dump/20140705/wikidatawiki-20140705-wb_items_per_site.sql.gz";
		name = "E:/wikidata_dump/20140705/incre/wikidatawiki-20140705-pages-meta-hist-incr.xml.bz2";
		name = "E:/wikipedia_dump/enwiki-20140203-pages-articles.xml.bz2";
		name = "E:/wikipedia_dump/enwiki-20140707-pages-articles1.xml-p000000010p000010000.bz2";
		name = "E:/wikipedia_dump/enwiki-20140924-pages-meta-hist-incr.xml.bz2";
		// name =
		// "E:/wikipedia_dump/enwiki-20140924-stubs-meta-hist-incr.xml.gz";
		// name =
		// "E:/wikipedia_dump/enwiki-20140824-stubs-meta-hist-incr.xml.gz";
		// name =
		// "E:/wikidata_dump/20140705/incre/wikidatawiki-20140705-stubs-meta-hist-incr.xml.gz";
		// name =
		// "d:/_study/_data/wikidata/dump/20140106/wikidatawiki-20140106-pagelinks.sql.gz";

		File f = new File(name);

		InputStream is = null;

		// is = new GzipCompressorInputStream(new FileInputStream(f));
		is = new BZip2CompressorInputStream(new FileInputStream(f));

		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File("_data/compress.txt")));

		int count = 0;
		int max = 5000;
		while (true) {
			String s = reader.readLine();
			System.out.println(s);
			writer.write(s + "\n");
			writer.flush();

			count++;
			if (count == max) {
				break;
			}
		}
		reader.close();
		writer.close();
	}

	public void testCompress2() throws Exception {
		String address = "http://download.wikimedia.org/enwiki/latest/enwiki-latest-pages-articles.xml.bz2";
		address = "http://dumps.wikimedia.org/enwiki/latest/enwiki-latest-pages-articles.xml.bz2";
		address = "http://dumps.wikimedia.org/wikidatawiki/20140226/wikidatawiki-20140226-wb_items_per_site.sql.gz";
		address = "http://dumps.wikimedia.org/wikidatawiki/20140508/wikidatawiki-20140508-pages-articles.xml.bz2";
		address = "http://dumps.wikimedia.org/wikidatawiki/20140508/wikidatawiki-20140508-pages-meta-current.xml.bz2";

		address = "http://dumps.wikimedia.org/enwiki/20140614/enwiki-20140614-pages-meta-current1.xml-p000000010p000010000.bz2";
		address = "http://dumps.wikimedia.org/other/incr/enwiki/20140803/enwiki-20140803-pages-meta-hist-incr.xml.bz2";
		address = "https://dumps.wikimedia.org/enwiki/20140811/enwiki-20140811-pages-articles-multistream.xml.bz2";
		address = "http://dumps.wikimedia.org/enwiki/20140707/enwiki-20140707-pages-articles-multistream.xml.bz2";
		address = "http://dumps.wikimedia.org/enwiki/20140811/enwiki-20140811-pages-meta-history1.xml-p000000010p000003354.bz2";
		address = "http://dumps.wikimedia.org/enwiki/20140811/enwiki-20140811-pages-meta-current1.xml-p000000010p000010000.bz2";
		address = "http://dumps.wikimedia.org/enwiki/20140811/enwiki-20140811-stub-meta-history1.xml.gz";
		address = "http://dumps.wikimedia.org/enwiki/20140811/enwiki-20140811-abstract1.xml";
		address = "http://dumps.wikimedia.org/enwiki/20140811/enwiki-20140811-page.sql.gz";
		address = "http://dumps.wikimedia.org/enwiki/20140811/enwiki-20140811-pages-articles-multistream.xml.bz2";
		address = "http://dumps.wikimedia.org/enwiki/20140811/enwiki-20140811-templatelinks.sql.gz";
		address = "http://dumps.wikimedia.org/enwiki/20140811/enwiki-20140811-pages-articles1.xml-p000000010p000010000.bz2";
		address = "http://dumps.wikimedia.org/enwiki/20140903/enwiki-20140903-stub-articles.xml.gz";

		// address =
		// "http://dumps.wikimedia.org/other/incr/enwiki/20140803/enwiki-20140803-stubs-meta-hist-incr.xml.gz";

		// address =
		// "http://dumps.wikimedia.org/other/incr/wikidatawiki/20140131/wikidatawiki-20140131-pages-meta-hist-incr.xml.bz2";

		System.out.println("address:" + address);

		HttpURLConnection conn = (HttpURLConnection) new URL(address).openConnection();
		conn.setConnectTimeout(6 * 1000);
		conn.setDoInput(true);
		conn.setRequestMethod("GET");
		// conn.setRequestProperty("Accept", "text/html");
		int code = conn.getResponseCode();
		Printer.instance.println("response code:" + code);

		InputStream is = null;
		is = conn.getInputStream();
		is = new GzipCompressorInputStream(is);
		// is = new BZip2CompressorInputStream(is);

		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File("_data/test.txt")));

		int count = 0;
		int max = 10000;
		while (true) {
			String s = reader.readLine();
			System.out.println(s);
			writer.write(s + "\n");
			writer.flush();

			count++;
			if (count == max) {
				break;
			}
		}

		reader.close();
		writer.close();
	}

	public void testPullXml() throws Exception {
		String file = "d:/_study/_data/wikidata/dump/20140106/wikidatawiki-20140106-pages-meta-current.xml.bz2";
		file = "E:/wikipedia_dump/enwiki-20140203-pages-articles.xml.bz2";
		BZip2CompressorInputStream is = new BZip2CompressorInputStream(new FileInputStream(new File(file)));
		System.out.println("hello");

		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		int count = 0;
		while (true) {
			System.out.println(reader.readLine());

			count++;
			if (count == 100) {
				break;
			}
		}

		// SAXParserFactory spf = SAXParserFactory.newInstance();
		// SAXParser saxParser = spf.newSAXParser();
		// saxParser.parse(is, new DefaultHandler() {
		// @Override
		// public void startDocument() throws SAXException {
		// // TODO Auto-generated method stub
		// super.startDocument();
		// }
		//
		// @Override
		// public void endDocument() throws SAXException {
		// // TODO Auto-generated method stub
		// super.endDocument();
		// }
		//
		// @Override
		// public void startElement(String uri, String localName,
		// String qName, Attributes attributes) throws SAXException {
		// // TODO Auto-generated method stub
		// super.startElement(uri, localName, qName, attributes);
		// System.out.println("qname:" + qName);
		// }
		//
		// @Override
		// public void characters(char[] ch, int start, int length)
		// throws SAXException {
		// // TODO Auto-generated method stub
		// super.characters(ch, start, length);
		// System.out.println("new String(ch, start, length):"
		// + new String(ch, start, length));
		// }
		//
		// @Override
		// public void endElement(String uri, String localName, String qName)
		// throws SAXException {
		// // TODO Auto-generated method stub
		// super.endElement(uri, localName, qName);
		// }
		// });

	}

	public void testXmlBig() throws Exception {
		String file = "e:/wikidata_dump/20140106/wikidatawiki-20140106-pages-meta-current.xml.bz2";
		BZip2CompressorInputStream is = new BZip2CompressorInputStream(new FileInputStream(new File(file)));
		System.out.println("hello");

		SAXReader reader = new SAXReader();
		reader.setDefaultHandler(new ElementHandler() {

			@Override
			public void onStart(ElementPath elementPath) {
				// TODO Auto-generated method stub
				System.out.println("onstart");
				Element e = elementPath.getCurrent();
				System.out.println("e:" + e.getName());
			}

			@Override
			public void onEnd(ElementPath elementPath) {
				// TODO Auto-generated method stub
				System.out.println("onend");
				Element e = elementPath.getCurrent();
				System.out.println("e:" + e.getName());
			}
		});
		System.out.println("begin to read");
		reader.read(is);
		System.out.println("kkkk");
	}

	public void testSql() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// Load the JDBC driver
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);

			// Create a connection to the database
			String url = "jdbc:mysql://localhost:3306/wikidata";
			String username = "root";
			String password = "";
			conn = DriverManager.getConnection(url, username, password);

			stmt = conn.createStatement();

			String selection = "term_entity_id,term_language,term_text,term_type";
			String where = "term_entity_type='item' AND term_type='label' AND term_entity_id = " + 2665190;
			String sql = "SELECT " + selection + " FROM wb_terms WHERE " + where + " ORDER BY term_entity_id desc LIMIT " + "1";

			String title = "1968 Winter Olympics";
			title = "candy";
			title = "Neubukow";
			title = "Cneoglossa longipennis";
			title = "Bruchidius hargreavesi";

			sql = "select * from wikipedia_article_en where title in( \"" + URLEncoder.encode(title, "utf-8") + "\")";

			System.out.println("sql:" + sql);
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				System.out.println("title:" + rs.getString("title"));
				System.out.println("source:" + rs.getString("text"));

				// System.out.println(rs.getInt("term_entity_id"));
				// System.out.println(rs.getString("term_language"));
				//
				// InputStream is = rs.getBinaryStream("term_text");
				// byte[] data = new byte[1024];
				// int len = is.read(data);
				// System.out.println(new String(data, 0, len, "utf-8"));
				//
				// System.out.println(rs.getString("term_text"));
				// System.out.println(rs.getString("term_type"));
			}
		} catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (Exception ee) {
				ee.printStackTrace();
			}
		}
	}

	public void testSql2() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// Load the JDBC driver
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);

			// Create a connection to the database
			String url = "jdbc:mysql://localhost:3306/wikidata_test";
			String username = "root";
			String password = "";
			conn = DriverManager.getConnection(url, username, password);

			stmt = conn.createStatement();

			String selection = "*";
			String entityId = "2655935";
			entityId = "2665190";
			String where = "item_id=" + entityId;
			where = "term_entity_id=" + entityId + " AND term_type='label' AND term_language='en'";
			String table = "wb_terms";
			String sql = "SELECT " + selection + " FROM " + table + " WHERE " + where;
			System.out.println("sql:" + sql);
			// rs = stmt.executeQuery(sql);

			String value = null;
			// while (rs.next()) {
			// InputStream is = rs.getBinaryStream("term_text");
			// int len = -1;
			// byte[] data = new byte[1024];
			// len = is.read(data);
			//
			// value = new String(data, 0, len);
			// System.out.println("value:" + value);
			// }

			// System.out.println("DSFADF:"+new
			// String(value.getBytes(),"UTF-8"));

			sql = new String(FileTool.getInstance().readContent("_data/extract_fail_table.sql"));
			stmt.execute(sql);

			sql = "INSERT INTO extract_fail(item_id,lang1,label) VALUES(?,?,?)";

			PreparedStatement prest = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
			prest.setInt(1, 123);
			prest.setString(2, "en");
			prest.setString(3, URLEncoder.encode("Shinkage-ryū", "utf-8"));
			prest.addBatch();

			prest.executeBatch();
			prest.close();
			System.out.println("finish inserting");

			sql = "SELECT * from extract_fail";
			System.out.println("here");
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				System.out.println(rs.getString("label"));
			}
		} catch (Exception e) {
			// handle the exception
			e.printStackTrace();
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (Exception ee) {
				ee.printStackTrace();
			}
		}
	}

	public void testSql3() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// Load the JDBC driver
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);

			// Create a connection to the database
			String url = "jdbc:mysql://localhost:3306/wikidata";
			String username = "root";
			String password = "";
			conn = DriverManager.getConnection(url, username, password);

			stmt = conn.createStatement();

			String selection = "label,date";
			String table = "incre_dump";
			String where = "date=?";
			String sql = "SELECT " + selection + " FROM " + table + " WHERE " + where + " LIMIT 1";
			PreparedStatement prest = conn.prepareStatement(sql);

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			prest.setDate(1, new Date(sdf.parse("2014-01-31").getTime()));
			rs = prest.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString("label"));
				System.out.println(rs.getDate("date"));
			}
		} catch (Exception e) {
			// handle the exception
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (Exception ee) {
				ee.printStackTrace();
			}
		}

	}

	public void testSql4() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// Load the JDBC driver
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);

			// Create a connection to the database
			String url = "jdbc:mysql://localhost:3306/wikidata";
			String username = "root";
			String password = "";
			conn = DriverManager.getConnection(url, username, password);

			stmt = conn.createStatement();

			String condition = "hello%";
			condition = condition.replaceAll("%", "\\%");

			String sql = "select * from wb_terms where term_entity_id=3856193";

			Statement statement = conn.createStatement();
			rs = statement.executeQuery(sql);
			while (rs.next()) {
				System.out.println(rs.getString("term_type"));
				System.out.println(rs.getString("term_language"));
				System.out.println(rs.getString("term_text"));
			}
		} catch (Exception e) {
			// handle the exception
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (Exception ee) {
				ee.printStackTrace();
			}
		}
	}

	public void testSql5() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// Load the JDBC driver
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);

			// Create a connection to the database
			String url = "jdbc:mysql://localhost:3306/wikidata";
			String username = "root";
			String password = "";
			conn = DriverManager.getConnection(url, username, password);

			stmt = conn.createStatement();

			String sql = "select * from wb_terms where term_entity_id=3856193";
			PreparedStatement prest = conn.prepareStatement(sql);

			rs = prest.executeQuery();
			while (rs.next()) {
				// System.out.println(rs.getString("term_entity_id"));
				System.out.println(rs.getString("term_type"));
				System.out.println(rs.getString("term_language"));
				System.out.println(rs.getString("term_text"));
			}
		} catch (Exception e) {
			// handle the exception
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (Exception ee) {
				ee.printStackTrace();
			}
		}
	}

	public void testSql6() {
		Connection conn = null;
		Statement statement = null;
		ResultSet rs = null;
		while (true) {
			long start;
			List<Integer> ids = new ArrayList<>();
			try {
				conn = DBTool.getInstance().getConnection();

				start = System.currentTimeMillis();
				statement = conn.createStatement();

				int limitSize = 1000;
				String subSelect = "select ips_item_id from wb_items_per_site2 where ips_site_id != 'enwiki' limit " + limitSize;
				statement = conn.createStatement();
				rs = statement.executeQuery(subSelect);
				System.out.println("select cost:" + (System.currentTimeMillis() - start));

				while (rs.next()) {
					int id = rs.getInt(1);
					ids.add(id);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				DBTool.getInstance().close(conn, statement, rs);
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			PreparedStatement preparedStatement = null;
			if (!ids.isEmpty()) {
				try {
					String sql = "delete from wb_items_per_site_tmp2 where ips_item_id in (";
					start = System.currentTimeMillis();
					conn = DBTool.getInstance().getConnection();

					String idStr = "";
					for (int id : ids) {
						idStr = idStr + id + ",";
					}
					if (idStr.endsWith(",")) {
						idStr = idStr.substring(0, idStr.length() - 1);
					}
					sql = sql + idStr + ")";
					// System.out.println(sql);
					preparedStatement = conn.prepareStatement(sql);

					preparedStatement.executeUpdate();

					System.out.println("delete cost:" + (System.currentTimeMillis() - start));

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					DBTool.getInstance().close(conn, preparedStatement, null);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} else {
				break;
			}
		}

		System.out.println("all things has been deleted");
	}

	public void testException() {
		try {
			int a = 0;
			System.out.println(1 / a);

		} catch (Exception e) {

			for (StackTraceElement e1 : e.getStackTrace()) {
				System.out.println(e1);
			}
		}
	}

	public void testMap() {
		Map<String, String> map = new HashMap<>();
		map.put("hello", "1");
		map.put("hello", "2");
		map.put("good", "adfasdf");

		System.out.println(map);

	}

	public void testProperty() throws Exception {
		Properties p = new Properties();

		p.put("hello", "http://hello/he's");
		p.put("ko", "정보");

		p.store(new FileWriter(new File("_data/pro.properties")), null);
		System.out.println(p.get("ko"));
	}

	public void testProperty2() throws Exception {
		Properties p = new Properties();
		p.load(new FileInputStream(new File("_data/pro.properties")));
		System.out.println(p.get("hello"));

		p.put("k1", "[藝人]");
		p.store(new FileOutputStream(new File("_data/pro.properties")), null);

		// List<String> list=new ArrayList<>();
		// list.add("1");
		// p.put("k2", list);
		// p.store(new FileOutputStream(new File("_data/pro.properties")),
		// null);
	}

	public void testBase64EncodeStr() {
		System.out.println(Base64Tool.instance.encode("_data/_fish_m.bin"));
	}

	public void testBase64EncodeFile() {
		String file = "pay_sdk_140531";
		file = "s";
		file = "swift";
		file = "paySdk_140614";
		file = "th.bl";
		file = "src.txt";
		Base64Tool.instance.encodeFile("_data/fromever/" + file + ".zip", "_data/toho/_" + file + "_p");
	}

	public void testBase64DecodeFile() {
		String file = null;
		file = "_data/fromever/src.txt";
		String output = "_data/fromever/target.zip";
		Base64Tool.instance.decodeFile(new File(file), output);
	}

	public void testFloat() {
		System.out.println(Float.valueOf("1.3217614E7"));
		System.out.println((int) Float.valueOf("1.3217614E7").floatValue());
	}

	public void testNumber() throws Exception {
		String str = "1, 3 50, 695, 000";
		// long value = Long.valueOf(str);
		// System.out.println(value);

		DecimalFormat format = new DecimalFormat(",###");
		System.out.println(format.format(123456));
		System.out.println(format.parse("1,350,695,000"));

		int a = 0x10;
		System.out.println(a);
		System.out.println(a >> 1);

		System.out.println(Math.log10(1000));

		double value = 1.234;
		value = 1;
		value = 1.1;
		System.out.println(DecimalTool.getInstance().getDotSize(value));

		System.out.println(Integer.valueOf("0"));
	}

	public void testInt() {
		// System.out.println(Integer.valueOf("1"));
		// System.out.println(Long.valueOf("2014031110430001"));
		//
		// System.out.println(Integer.parseInt("ABFX", 16));
		//
		// System.out.println(Double.valueOf("asdfsadf"));
		// System.out.println("3wwqer");
		// 214
		// a5d6
		System.out.println(Integer.toHexString(214));
	}

	public void testGetDms() {
		double[] dms = CoordinateTool.getIntance().getDms(108.90593);
		for (int i = 0; i < dms.length; i++) {
			System.out.println(dms[i]);
		}
	}

	public void testGetDdd() {
		int d = 27;
		int m = 28;
		double s = 14.71;
		System.out.println(CoordinateTool.getIntance().getDdd(d, m, s));
	}

	public void testDecimalFormat() {
		double d = 12.1234567891;
		System.out.println(DecimalTool.getInstance().precision(d, 0));
		System.out.println(DecimalTool.getInstance().precision(d, 5));

		double f = 79.1666666666666;
		BigDecimal b = new BigDecimal(f);
		double f1 = b.setScale(-2, BigDecimal.ROUND_HALF_UP).doubleValue();
		System.out.println("f=" + f1);
	}

	public void testGetTimeThroughNet() {
		System.out.println(TimeTool.getInstance().getUtcTimeThroughNet());
	}

	public void testEncode() throws Exception {
		String s = "abc";
		System.out.println(MD5.getMD5Str(s));
		System.out.println(EncodeTool.instance.encode(s, EncodeTool.MD5));
		System.out.println(EncodeTool.instance.encode(s, EncodeTool.SHA1));

		s = "michael jackson";
		System.out.println(URLEncoder.encode(s, "utf-8"));
	}

	public void testGoogleStt() {
		SttGoogleTool.getInstance().getText("_data/wave/1400752884809.wav", "en-us", new TtsGoogleToolListener() {

			@Override
			public void onGetText(String text) {
				// TODO Auto-generated method stub
				System.out.println(text);
			}
		});
	}

	public void testInnerAccess() {
		new That().accessThis();
	}

	public void testHexString() {
		String s = "enwiki";

		s = "Bishōjo game";
		s = " ";
		System.out.println(StringConverter.str2HexStr(s));

		// StringBuffer buffer = new StringBuffer();
		// for (int i = 0; i < s.length(); i++) {
		// int cha = s.charAt(i);
		// buffer.append(Integer.toHexString(cha));
		// }
		// System.out.println("content:" + buffer.toString());
	}

	private String testKey(String s, String keyString) throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
		SecretKeySpec key = new SecretKeySpec((keyString).getBytes("UTF-8"), "HmacSHA1");
		Mac mac = Mac.getInstance("HmacSHA1");
		mac.init(key);

		byte[] bytes = mac.doFinal(s.getBytes("UTF-8"));

		return new String(Base64.encodeBase64(bytes));
	}

	public void testGetToken() {
		String user = "cp_bus_api1.126.com";
		// String time = "2014-06-25 10:01:00";
		String time = TimeTool.getInstance().getFullDesc(new java.util.Date());
		System.out.println("time:" + time);
		String key = "21232F297A57A5A743894A0E4A801FC3";

		String sign = EncodeTool.getInstance().encode(user + "#" + time + "#" + key, EncodeTool.MD5);

		System.out.println("sign:" + sign);

		Map<String, String> map = new HashMap<>();
		map.put("timestamp", time);
		map.put("appuser", user);
		map.put("signature", sign);

		String token = null;
		final String tokenTag = "token=";
		byte[] data = new NetTool().getData(NetTool.generateRequestUrl("https://sandbox.3payer.com/component/accessToken", map));
		if (data != null && data.length > 0) {
			String resp = new String(data);
			String[] ss = resp.split("&");
			for (String s : ss) {
				int index = s.indexOf(tokenTag);
				if (index != -1) {
					token = s.substring(index + tokenTag.length());
				}
			}
		}
		System.out.println("token:" + token);
	}

	public void testQueryPayChannel() {
		String sign = SignTool.getInstance().sign(Arrays.asList(new String[] { "1", "2", "1000", "1" }));
		System.out.println("sign:" + sign);

		System.out.println("content:" + new String(FileTool.getInstance().readContent("_data/queryChannel")));

		new NetTool().sendData("https://sandbox.3payer.com/component/querySdkPayChannel", FileTool.getInstance().readContent("_data/queryChannel"));
	}

	// public void testReflect() {
	// List<bean.Bean> beans = new ArrayList<>();
	// bean.Bean bean = new Bean();
	// beans.add(bean);
	// bean.setAge(12);
	// InnerBean ib = new InnerBean();
	// bean.setRealInner(ib);
	// ib.setName("bill");
	// Number number = new Number();
	// ib.getNumbers().add(number);
	// number.setNumber2(new Number2(1));
	// number = new Number();
	// ib.getNumbers().add(number);
	// number.setNumber2(new Number2(2));
	// number = new Number();
	// ib.getNumbers().add(number);
	// number.setNumber2(new Number2(3));
	// //
	// bean = new Bean();
	// beans.add(bean);
	// bean.setAge(13);
	// ib = new InnerBean();
	// bean.setRealInner(ib);
	// ib.setName("sheme");
	// number = new Number();
	// ib.getNumbers().add(number);
	// number.setNumber2(new Number2(4));
	// number = new Number();
	// ib.getNumbers().add(number);
	// number.setNumber2(new Number2(5));
	// number = new Number();
	// ib.getNumbers().add(number);
	// number.setNumber2(new Number2(6));
	//
	// List<String> ps = new ArrayList<>();
	// ps.add("realInner");
	// ps.add("numbers");
	// ps.add("number2");
	// List<Object> pos = ReflectTool.instance.getProperty(ps, beans);
	// System.out.println("pos size:" + pos.size());
	// System.out.println("pos ele class:" + pos.get(0).getClass());
	// // System.out.println(((InnerBean) pos.get(1)).getName());
	//
	// for (Object po : pos) {
	// Number2 number2 = (Number2) po;
	// System.out.println("value:" + number2.getValue());
	// }
	//
	// }

	public void testReflect2() {
		Result result = new Result();
		List<bean.Bean> beans = result.getRealBean();
		// bean
		bean.Bean bean = new Bean();
		beans.add(bean);
		bean.setAge(12);
		InnerBean ib = new InnerBean();
		bean.setRealInner(ib);
		ib.setName("bill");
		Number number = new Number();
		ib.getNumbers().add(number);
		Number2 number2 = new Number2();
		number.setNumber2(number2);
		List<Number3> number3s = new ArrayList<>();
		number2.setNumber3s(number3s);
		number3s.add(new Number3(new Number4(1)));
		number3s.add(new Number3(new Number4(2)));
		//
		number = new Number();
		ib.getNumbers().add(number);
		number2 = new Number2();
		number.setNumber2(number2);
		number3s = new ArrayList<>();
		number2.setNumber3s(number3s);
		number3s.add(new Number3(new Number4(3)));
		number3s.add(new Number3(new Number4(4)));
		// bean
		bean = new Bean();
		beans.add(bean);
		bean.setAge(13);
		ib = new InnerBean();
		bean.setRealInner(ib);
		ib.setName("sheme");
		//
		number = new Number();
		ib.getNumbers().add(number);
		number2 = new Number2();
		number.setNumber2(number2);
		number3s = new ArrayList<>();
		number2.setNumber3s(number3s);
		number3s.add(new Number3(new Number4(5)));
		number3s.add(new Number3(new Number4(6)));
		//
		number = new Number();
		ib.getNumbers().add(number);
		number2 = new Number2();
		number.setNumber2(number2);
		number3s = new ArrayList<>();
		number2.setNumber3s(number3s);
		number3s.add(new Number3(new Number4(7)));
		number3s.add(new Number3(new Number4(8)));

		List<String> ps = new ArrayList<>();
		ps.add("realBean");
		ps.add("realInner");
		ps.add("numbers");
		ps.add("number2");
		ps.add("number3s");
		// ps.add("number4");
		List<Object> pos = ReflectTool.instance.getProperty(ps, result);
		// System.out.println("pos size:" + pos.size());
		// System.out.println("pos ele class:" + pos.get(0).getClass());
		// // System.out.println(((InnerBean) pos.get(1)).getName());
		//
		// for (Object po : pos) {
		// Number4 number4 = (Number4) po;
		// System.out.println("value:" + number4.getValue());
		// }

		System.out.println(pos);
	}

	class BeanAbc {
		private boolean flag1;
		private Boolean flag2;
	}

	public void testReflect3() {

	}

	// public void testCoord() {
	// String s = "34° 35' 48\" North";
	// String[] ss = CoordinateTool.getIntance().splitDms(s);
	// for (String str : ss) {
	// System.out.println(str);
	// }
	// }

	public void testCoord2() {
		String s = "34° 35' 48\" North  43° 40' 37\" East ";
		s = "34°35'      48\"North44°45'58\"           East";
		s = "34°35'48\"North44°45'58\"East";
		s = "34° 35' 48\" North ";
		s = "   44°    45'    58\"  East  ";
		s = "   44°      East  ";
		s = "   45'       East  ";

		s = "37º36'22' N";
		s = "19°06′20″N";
		s = "120 45′ 40.72″ E";
		s = "9.33°N";
		s = "07º13'S";
		s = "06′20″N";
		s = "19°06′20″N 96°06′28″W";
		s = "14 57′ 35.15″ N, 120 45′ 40.72″ E";
		// s = "9.33°N 76.68°E";
		// s = "06°20'S-111°28'E";
		// // 有问题
		// s = "-31.955002,115.858469";
		// s = "26°42'48.52\"N/ 81°36'35.98\"W";
		// s = " 37°32'22.52\"S, 143°49'52.23\"E";
		// s=" 15° 52' 60 N ,  74° 34' 60 E";
		s = "53°53'23\"N. 1°36'45\"W.";
		s = "46.84972";
		s = "40.614637 N, 75.165496 W";
		s = "37º36'22' N";
		s = "120 45′ 40.72″ E";
		s = "06′20″N";
		s = "19°06′20″N 96°06′28″W";
		s = "14 57′ 35.15″ N, 120 45′ 40.72″ E";
		s = "06°20'S-111°28'E";
		s = "-31.955002,115.858469";
		s = "26°42'48.52\"N/ 81°36'35.98\"W";
		s = "15° 52' 60 N ,  74° 34' 60 E";
		s = "53°53'23\"N. 1°36'45\"W.";
		s = "51 14 47.15 N, 0 46 37.44 E";
		s = "43°04'12\"93 N 79°57'05\"73 W";

		System.out.println("s:" + s);
		List<String[]> dmsds = CoordinateTool.getIntance().splitDmsd(s);

		for (String[] dmsd : dmsds) {
			System.out.println("-----------");
			for (String data : dmsd) {
				System.out.println(data);
			}
		}
	}

	public void testExp() {
		String line = "This order was placed for QT3104564! OK?";
		line = "(Ra.adsf.qeklrj) view.findViewById(R.id.ok).setOnClickListener(new OnCl\n" + "(R.id.yes)";
		line = "import com.sq.pay.result.PayResult;";
		line = "(1) Jane Wilson Smith (1922–1992, married until her death) (2) Bertie Murphy Deming Smith (born ca. 1925, married until his death)";

		// line = line.replaceAll("\\D", "");
		// System.out.println("line:" + line);
		// line = "(2006) [[Regnery Publishing]]";
		line = "S.3 (Springbok I): 19 April 1923 S.3a (Springbok II): 25 March 1925 S.3b (Chamois): 14 March 1927";
		line = "abc";
		line = "1337 SW Washington Street [[Portland, Oregon]]{{citation|last=Oregon Parks and Recreation Department|authorlink= Oregon Parks and Recreation Department|date=October 19, 2009|title=Oregon National Register List|url=http://www.oregonheritage.org/OPRD/HCD/NATREG/docs/oregon_nr_list.pdf|accessdate=April 2, 2010}}";
		line = "{{gbmappin";
		line = "Hathazari, [[Bangladesh]] {{Location map|Bangladesh|label=Hailakandi Airfield |marksize=6|mark=Red_pog.svg |lat_dir=N|lat_deg=22|lat_min=30|lat_sec=02 |lon_dir=E|lon_deg=091|lon_min=48|lon_sec=27 |width=300}}";
		line = "http://www.espncricinfo.com/ci/content/player/12622.html Cricinfo";
		line = "http://www.espncricinfo.com/ci/content/player/12622.html Cricinfo ";
		line = "www.espncricinfo.com/ci/content/player/12622.html Cricinfo ";
		line = "http://www.espncricinfo.com/ci/content/player/12622.html Cricinfo http://abc hello";
		line = "(1) Father Francis Miller (2) Thomas Justin Miller (born 1949) (3) Kenneth Gerard Miller (born 1951) (4) John Miller (5) Normand Cleophas Miller (born 1965) (6) Mrs. Jeanine Billeaud (born1957) (7) Julie McCarthy born 1959 (8) Carmel Soileau (born 1963)";
		line = "(1)hello";
		line = "{{abc}} {{bcd}}";
		line = "{{army|USA}} {{army|CSA}} Engineers";
		line = "minor planet (Q1022867), in particular asteroids - asteroid (Q3863)";
		line = "(asdf_)12346(qfasdf)";
		line = "\"key1\" in en:template:template1";
		line = "'CBS=' in nl:Sjabloon:Infobox gemeente Nederland";
		line = "en:template:infobox video game : engine";
		line = "'Gemeindeschlüssel' in de:Vorlage:Infobox Ort in Japan";
		line = "parliament in Template:Infobox UK legislation, but more general";
		line = "en:Template:Infobox disease field MeshID";
		line = "Template:Taxobox : \"fossil_range\" - see Template:Taxobox (Q52496)";
		line = "en:Template:Infobox ice hockey player (league)";
		line = "someid";
		line = "asdf ";
		line = "hello world(big good)";
		line = "aaa{{{asdfasdf {{asdfasdf {{helloasdfljl}} }}} }}abd {{adf}}";
		line = "{|hello    {|hello|}nihao         |}nihao       {|hello|}nihao";
		// line = new String(FileTool.getInstance().readContent(
		// "_data/content/test.txt"));
		line = "kkk123abc456";
		line = "hello123World";
		line = "[$parent]提交了[$course][$workbook]的作业";

		String pattern = "(.*)(\\d+)(.*)";
		pattern = "^(all)\\b(\\s*)\\(\\d+\\)$";
		pattern = "^(all)\\b\\(\\d+\\)$";
		pattern = "R\\.\\w+\\.\\w+";
		pattern = "\\(.*?\\)";
		pattern = "\\d";
		pattern = "(?i)\\{\\{\\s*(coor|gbmappingsmall|gbmapping)";
		pattern = "lat.+lon.+";
		pattern = "(http://|www).+?\\s";
		pattern = "\\(\\d\\)";
		pattern = "\\{\\{.+?\\}\\}";
		pattern = "(?i)\\{\\{\\s*army.*?\\}\\}";
		pattern = "\\(Q\\d+\\)";
		pattern = "\\(.+?\\)";
		pattern = "\".+\"\\sin\\s(en|fr):(template):.+";
		pattern = "\".+\"";
		pattern = "(en|fr):(template):";
		pattern = "\".+\"\\sin\\s(en|fr):(template):";
		pattern = "\"";
		pattern = "\"\\sin\\s(en|fr):(template):.+";
		pattern = "(?i)'.+='\\sin\\s(en|nl):(template|Sjabloon):.+";
		// pattern = "(?i)(en|nl):(template|Sjabloon):.+\\s:\\s.+";
		pattern = "(?i)(en|nl):(template|Sjabloon):.+\\s:\\s.+";
		pattern = "(?i).+\\sin\\s(en|nl|de|ru|it|zh):(template|Sjabloon|Vorlage|Шаблон):.+";
		pattern = "(?i)(en|nl|de|ru|es|it|zh|fr):(template|Sjabloon|Vorlage|Шаблон|Plantilla):.+:\\sfield\\s.+";
		pattern = "(?i)(template|Sjabloon|Vorlage|Шаблон|Plantilla):.+\\s:\\s\".+\"";
		pattern = "(?i)(en|nl|de|ru|es|it|zh|fr|sv):(template|Sjabloon|Vorlage|Шаблон|Plantilla):.+\\s\\(.+\\)";
		pattern = "(id)$";
		pattern = "\\w$";
		pattern = "\\b\\w+\\b";
		pattern = "\\{\\{.+?\\}\\}";
		pattern = "\\d+";
		pattern = ".[a-z_\\-1-9]+";
		pattern = "\\[\\$.+?\\]";
		// pattern = "\\{\\|.+?\\|\\}";
		System.out.println("pattern:" + pattern);

		// System.out.println(line.split(pattern).length);
		// 创建 Pattern 对象
		Pattern r = Pattern.compile(pattern, Pattern.MULTILINE | Pattern.DOTALL);
		// 现在创建 matcher 对象
		Matcher m = r.matcher(line);
		while (m.find()) {
			System.out.println(m.group());
			System.out.println();
			// System.out.println("start:" + m.start());
			// System.out.println("end:" + m.end());
			// System.out.println(line.substring(m.end()));
		}

	}

	public void testModifyAndroidResUsingResourceTool() throws Exception {
		// 按指定模式在字符串查找

		String dir = "_data/modifyAndroidResUsingResourceTool/";
		handleFile(new File(dir));
	}

	private void handleFile(File file) throws Exception {
		System.out.println("handle file:" + file.getAbsolutePath());
		if (file.isDirectory()) {
			for (File f : file.listFiles()) {
				handleFile(f);
			}
		} else {
			String pattern = "R\\.\\w+\\.\\w+";
			String line = new String(FileTool.getInstance().readContent(file.getAbsolutePath()), "utf-8");

			// 创建 Pattern 对象
			Pattern r = Pattern.compile(pattern, Pattern.MULTILINE);
			// 现在创建 matcher 对象
			Matcher m = r.matcher(line);

			List<Integer> starts = new ArrayList<>();
			List<Integer> ends = new ArrayList<>();

			while (m.find()) {
				starts.add(m.start());
				ends.add(m.end());
			}

			for (int i = starts.size() - 1; i >= 0; i--) {
				int start = starts.get(i);
				int end = ends.get(i);
				String content = line.substring(start, end);

				line = line.substring(0, start) + "ResourceTool.getResource(\"" + content + "\")" + line.substring(end);
			}

			FileTool.getInstance().writeData(file.getAbsolutePath(), line.getBytes());
		}
	}

	public void testSystemProperty() {
		System.out.println(System.getProperties());
	}

	public void testJsoup() {
		// List<String> theList=TableExtractAPI
		// .getTablesByUrl("http://en.wikipedia.org/wiki/American_Chess_Congress");
		// System.out.println(theList);

		String url = null;
		url = "E:/wikipedia_dump/html_article_sunfang/wikitable2/000f2784f0491eec74127d862fe9322e";
		url = "_data/michael_jackson_html.txt";
		List<String> tables = getTablesByUrl(url);
		System.out.println("table size:" + tables.size());
		if (tables != null && !tables.isEmpty()) {
			System.out.println(tables.get(0));
		}
	}

	private List<String> getTablesByUrl(String url) {
		List<String> rstList = new ArrayList<String>();
		org.jsoup.nodes.Document doc = null;
		try {
			doc = Jsoup.parse(new String(FileTool.getInstance().readContent(url)));
		} catch (Exception e) {
			// Exceptionm
			e.printStackTrace();
		}
		bar(doc, rstList);
		return rstList;
	}

	private void bar(org.jsoup.nodes.Document doc, List<String> rst) {
		Elements tableEles = doc.getElementsByTag("table");

		for (org.jsoup.nodes.Element tableEle : tableEles) {
			for (org.jsoup.nodes.Element chileEle : tableEle.children()) {
				if (!chileEle.getElementsByTag("table").isEmpty()) {
					continue;
				}
			}
			if (tableEle.outerHtml().contains("wikitable")) {
				rst.add(tableEle.outerHtml());
			}
		}
	}

	public void testGetTime() {

	}

	public void testJar() throws Exception {
		String file = "/config/domainTypeMaker-config.xml";
		InputStream is = getClass().getResourceAsStream(file);
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		System.out.println(reader.readLine());
	}

	public void testCleanDir() {
		String path = null;

		path = "D:/_study/_data/android/-笔记-141104/";
		path = "_data/swift/";
		path = "C:/Users/qilu0617/Desktop/in.desktop/to/toss/";
		path = "/Users/qlong/Downloads/huiyi.rar Folder";
		// path = "D:/workspace_eclipse/paySdk";
		FileTool.getInstance().deleteFiles(path, FileTool.DELETE_WAY_STARTSWITH, "._");
	}

	public void testCleanCommit() {
		String path = "_data/cleanCommit/";
		path = "C:/Users/qilu0617/Desktop/in.desktop/qilu-code/prevent/";

		FileTool.getInstance().cleanDirCommit(new File(path));
	}

	public void testGetLatestDir() {
		System.out.println(getLastestDir().getAbsolutePath());
	}

	private File getLastestDir() {
		File latest = null;

		File dir = new File("_data/mindnote/");

		List<File> fs = new ArrayList<File>(Arrays.asList(dir.listFiles(new FileFilter() {
			@Override
			public boolean accept(File pathname) {
				// TODO Auto-generated method stub
				return pathname.isDirectory() && pathname.getName().startsWith("files-");
			}
		})));
		Collections.sort(fs, new Comparator<File>() {
			private SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");

			@Override
			public int compare(File lhs, File rhs) {
				// TODO Auto-generated method stub
				long[] times1 = getTime(lhs.getName());
				long[] times2 = getTime(rhs.getName());

				if (times1[0] != times2[0]) {
					return (int) (times1[0] - times2[0]);
				} else {
					return (int) (times1[1] - times2[1]);
				}
			}

			private long[] getTime(String str) {
				long[] times = new long[2];
				if (!StringTool.isNull(str)) {
					String[] ss = str.split("-");
					if (ss.length == 3) {
						try {
							times[0] = sdf.parse(ss[1]).getTime();
							times[1] = Long.valueOf(ss[2]);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				return times;
			}
		});

		latest = fs.get(fs.size() - 1);

		return latest;
	}

	public void testNum() {
		// acd0ea
		System.out.println(DecimalTool.getInstance().getHexString(-4210753));

	}

	public void testCleanSvn() {
		String path = "/Users/qlong/smartsvn/3qii/3Payer_SDK_huawei/talkingface-sdk-huawei";
		String tag = ".svn";
		FileTool.getInstance().deleteFiles(path, tag);
		System.out.println("finish");
	}

	public void testMath() {
		int x = 1;
		int y = 1;

		// System.out.println(Math.atan(y/x));

		System.out.println(Math.sin(30));
	}

	public void testHuakaiImageDownloadV2HeaderConstruct() {
		String keyId = "STS.pFR821P0Y77MO9icyhWt";
		String keySecret = "utWLIF1A75V2qBM00dbtQymmqx30n2REvbl3iktA";
		String secToken = "CAEStQMIARKAATWwTbElCyoZ+mmMi7j4iZwATTzJor45GtwalA21pLFaVCg4Pp0mtt9OJqjR9zkjJLZtHLlSfWOX4pqdS7ZurfXH5iMeSL+oPUEbSa3dXc4j31RifhdDHgdszMqkOB4IPr68kYE79lsPZU5yFJ8nxe9Qb99Cf4mf8I+eR7dKfWHVGhhTVFMucEZSODIxUDBZNzdNTzlpY3loV3QiEjM1MDA3NTA0NjA0NjE3NTQxMSoNNTY3Y2M2OGFhZDZmOTDRlNW7nSo6BlJzYU1ENUKNAQoBMRqHAQoFQWxsb3cSLQoMQWN0aW9uRXF1YWxzEgZBY3Rpb24aFQoJb3NzOkxpc3QqCghvc3M6R2V0KhJPCg5SZXNvdXJjZUVxdWFscxIIUmVzb3VyY2UaMwoxYWNzOm9zczoqOjEzMTQ5MDU0ODUyMDUzOTk6dGVzdC1oay11c2VyL2hlbGxvLnBkZkoQMTMxNDkwNTQ4NTIwNTM5OVIFMjY4NDJaD0Fzc3VtZWRSb2xlVXNlcmAAahIzNTAwNzUwNDYwNDYxNzU0MTFyEnNlcnZpY2UtdXNlci1vc3Mtcg==";

		// 'Content-Md5' => $content_md5,
		// 'Content-Type' => $content_type,
		// 'Date' => $dt,
		// 'Host' => $host,
		// 'x-oss-security-token' => $sec_token,
		// 'Authorization' => $auth

		String contentMd5 = "";
		String contentType = "application/x-www-form-urlencoded";
		String date = "Fri, 25 Dec 2015 04:31:06 GMT";

		String path = "/test-hk-user/hello.pdf";

		String str_to_sign = "GET\n" + contentMd5 + "\n" + contentType + "\n" + date + "\n" + "x-oss-security-token:" + secToken + "\n" + path;

		String signature = SignTool.getInstance().singUsingHMAC_SHA1(str_to_sign, keySecret);

		System.out.println(signature);
		String auth = "OSS " + keyId + ":" + signature;
		System.out.println("auth:" + auth);
	}

	public void testEmail() {
		String email = "qlsusu@163.com";

		System.out.println("isemail:" + StringTool.isEmail(email));
	}

	private class LevelFile {
		private int level;
		private File f;
	}

	private class FileEle {
		private File f;
		private File[] fs;
		private File dir;
	}

	public static void main(String[] args) {
		// new Test().testTransformToEclipseAndroidProject();
		new Test().testJsonList();
	}

	/**
	 * 将studio工程转化成为eclipse工程
	 */
	public void testTransformToEclipseAndroidProject() {
		System.out.println("testTransformToEclipseAndroidProject!!!");

		// 目录中，第几层是工程的名字
		String rootDir = "/Users/qlong/_study/_data/android/android recipes-v4/source code/";
		final String distRootDir = "/Users/qlong/_study/_data/android/android recipes-v4/source code-eclipse/";
		final int nameAtLevel = 2;

		final String containerTag = "src";
		final String contentTag = "main";
		final String codeTag = "java";

		FileTool.getInstance().mkdirs(distRootDir);

		handleFile(new File(rootDir), 0, new FileHandler() {
			@Override
			public boolean handle(File f, int level) {
				// TODO Auto-generated method stub
				boolean isCanHandle = false;

				if (level == nameAtLevel) {
					isCanHandle = true;

					// 项目名字
					String projectName = f.getName();
					for (File containerFile : f.listFiles()) {
						if (containerFile.getName().equals(containerTag)) {
							for (File contentFile : containerFile.listFiles()) {
								if (contentFile.getName().equals(contentTag)) {
									File distDir = new File(distRootDir + projectName + "/");
									// 内容拷贝
									FileTool.getInstance().copyFolder(contentFile.getAbsolutePath(), distDir.getAbsolutePath());
									// 重命名 codeTag为src
									for (File codeFile : distDir.listFiles()) {
										if (codeFile.getName().equals(codeTag)) {
											codeFile.renameTo(new File(distRootDir + projectName + "/" + "src"));
											break;
										}
									}
									// 复制.classpath文件
									FileTool.getInstance().copyFile("_data/toEclipseAndroidProject/classpath", distDir.getAbsolutePath() + "/.classpath");
									// 复制.project文件
									String content = new String(FileTool.getInstance().readContent("_data/toEclipseAndroidProject/project"));
									content = content.replace("<name></name>", "<name>" + projectName + "</name>");
									FileTool.getInstance().createNewFile(distDir.getAbsolutePath() + "/.project");
									FileTool.getInstance().writeData(distDir.getAbsolutePath() + "/.project", content.getBytes());
									// 复制project.properties文件
									FileTool.getInstance().copyFile("_data/toEclipseAndroidProject/project.properties", distDir.getAbsolutePath() + "/project.properties");
									// 调整androidmanifest.xml
									content = new String(FileTool.getInstance().readContent(distDir.getAbsolutePath() + "/AndroidManifest.xml"));
									content = content.replace("</manifest>", "<uses-sdk android:minSdkVersion=\"10\" android:targetSdkVersion=\"22\" /></manifest>");
									FileTool.getInstance().writeData(distDir.getAbsolutePath() + "/AndroidManifest.xml", content.getBytes());
									break;
								}
							}

							break;
						}
					}
				}

				return isCanHandle;
			}
		});
	}

	private abstract class FileHandler {
		/**
		 * 是否能handle这个文件
		 * 
		 * @param f
		 * @param level
		 * @return
		 */
		public abstract boolean handle(File f, int level);
	}

	private void handleFile(File dir, int level, FileHandler handler) {
		System.out.println("handleFile:" + dir.getAbsolutePath() + ",level:" + level);
		if (dir.isDirectory()) {
			level++;
			for (File f : dir.listFiles()) {
				boolean isCanHandled = handler.handle(f, level);
				if (!isCanHandled) {
					handleFile(f, level, handler);
				}
			}
		}
	}

	public void testBit() {
		int value = 3;
		System.out.println(value << 2);
	}

	

}