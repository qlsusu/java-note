/**
 * 2010-4-20
 */
package test;

import static org.junit.Assert.assertEquals;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.ql.tool.compress.GZipUtils;
import com.ql.tool.compress.TarUtils;

/**
 * Tar测试
 * 
 * @author <a href="mailto:zlex.dongliang@gmail.com">梁栋</a>
 * @since 1.0
 */
public class TarUtilsTest {
	private String inputStr;

	// private String name = "data.xml";

	@Before
	public void before() {
		StringBuilder sb = new StringBuilder();
		sb.append("<?xml version=\"1.0\" encoding=\"utf-8\" ?>");
		sb.append("\r\n");
		sb.append("<dataGroup>");
		sb.append("\r\n\t");
		sb.append("<dataItem>");
		sb.append("\r\n\t\t");
		sb.append("<data>");
		sb.append("Test");
		sb.append("</data>");
		sb.append("\r\n\t");
		sb.append("<dataItem>");
		sb.append("\r\n");
		sb.append("</dataGroup>");

		inputStr = sb.toString();
	}

	@Test
	public void testArchiveFile() throws Exception {

		byte[] contentOfEntry = inputStr.getBytes();

		String path = "_data/compress/hello1.txt";

		FileOutputStream fos = new FileOutputStream(path);

		fos.write(contentOfEntry);
		fos.flush();
		fos.close();

		TarUtils.archive(path);

		TarUtils.dearchive(path + ".tar");

		File file = new File(path);

		FileInputStream fis = new FileInputStream(file);

		DataInputStream dis = new DataInputStream(fis);

		byte[] data = new byte[(int) file.length()];

		dis.readFully(data);

		fis.close();

		String outputStr = new String(data);
		assertEquals(inputStr, outputStr);

	}

	@Test
	public void testArchiveDir() throws Exception {
		String path = "_data/compress";
		TarUtils.archive(path);

		TarUtils.dearchive(path + ".tar", "d:/fds");
	}

	@Test
	public void testArchiveDirWithIgnore() throws Exception {
		List<String> ignoreFileList = new ArrayList<String>();
		// ignoreFileList.add("hello2.txt");

		ignoreFileList.add(".metadata");
		ignoreFileList.add("bin");
		ignoreFileList.add("gen");
		ignoreFileList.add("_data");
		ignoreFileList.add("_version");
		ignoreFileList.add(".settings");
		ignoreFileList.add(".svn");
		TarUtils.setIgnoreFileList(ignoreFileList);

		File root = new File("D:/android_workspace");
		File[] fs = root.listFiles();

		for (File f : fs) {
			try {
				if (!f.getName().equals(".metadata")) {
					// System.out.println("archive file:" + f.getName());
					TarUtils.archive(f);
					// System.out.println("finish archive file:" + f.getName());
					GZipUtils.compress(f.getAbsolutePath() + ".tar");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Test
	public void testTarGzip() throws Exception {
		String path = "_data/compress";
		TarUtils.archive(path);

		GZipUtils.compress(path + ".tar");
	}
}
