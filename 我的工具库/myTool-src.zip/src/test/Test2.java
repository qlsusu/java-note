package test;

import bean.Father;

public class Test2 {
	public static void main(String[] args) {
		Father f = new Father();
		System.out.println("age is:" + f.age);
	}
}
