package test;

import java.util.ArrayList;
import java.util.List;

import com.ql.tool.JsonTool;
import com.ql.tool.JsonTool.Skip;

public class MyMain {
	public static void main(String[] args) {
		MyMain obj = new MyMain();
		// obj.test1();
		obj.testJsonExclusiveStrategy();
	}

	public void test1() {
		List<ResultBean> list = new ArrayList<ResultBean>();

		ResultBean bean = new ResultBean();
		bean.setAdtUrl("1");
		list.add(bean);

		bean = new ResultBean();
		bean.setAdtUrl("2");
		list.add(bean);

		// System.out.println(XmlToolW3C.getInstance().toXml(list));
	}

	private void testJsonExclusiveStrategy() {
		Skip skip = new Skip();
		skip.setClz(Bean.class);
		List<String> fields = new ArrayList<>();
		fields.add("name");
		skip.setFields(fields);
		List<Skip> skips = new ArrayList<Skip>();
		skips.add(skip);

		JsonTool.instance.init(skips);

		Bean bean = new Bean();
		bean.setName("bill");
		bean.setAge(20);
		// System.out.println(JsonTool.instance.toString(bean));
	}
}
