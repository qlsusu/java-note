package test.hash;

import java.util.HashSet;

import junit.framework.TestCase;

public class TestHash extends TestCase{
	public void testHash(){
		HashSet<Bean> beans=new HashSet<>();
		
		Bean bean1=new Bean();
		bean1.id=1;
		Bean bean2=new Bean();
		bean2.id=1;
		
		System.out.println(bean1.equals(bean2));
		beans.add(bean1);
		beans.add(bean2);
		System.out.println("beans size:"+beans.size());
	}
}
