package test;

public class TestMain {
	public static void main(String[] args) {
		for (String s : args) {
			System.out.println("args:" + s);
		}
	}
}
