package other;

import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import com.ql.tool.Base64Tool;
import com.ql.tool.StringTool;

public class SignTool {
	private static SignTool instance = new SignTool();
	private final static String PRIVATE_KEY = "MIIBVgIBADANBgkqhkiG9w0BAQEFAASCAUAwggE8AgEAAkEAwH8BgGv4UWGhgpCRD8Qoes2A9dRTQQhHrLdb7xtGTN7Xd1biAM8VScmAsa5NAx4wLZxAo1F/Stly5i6akiU1FwIDAQABAkEAqEUdwe4gJrvKnMDVHcwiep70EXDmyh170j6CzfSwsnZBw5niqKul/45w+/nMj0BnbtkBpNPO1tWv1NW1BTfqeQIhAOc7jrHfo+7638ga43oAkYL3zVVkX5PVpjvfxpn5/asDAiEA1R1JGcVUP6KcoHhkwDFMxLxwndCxwvFf9dJfLpgbB10CIQCqS7iZ04UeWfE5pGPn1EdWVz4IJ7YkYHLfIb1YZT6nFQIgEUYOZshXy9CiYV9gyzMzxb6AYkpIHkTyQjqK/HvXtQECIQCpSMEOPHyRB1seUmVNbmmf3qhl1Uemlw9RvXXT5+TN4Q==";

	public static SignTool getInstance() {
		return instance;
	}

	private SignTool() {

	}

	private static final String SIGN_ALGORITHMS = "SHA1WithRSA";

	/**
	 * 构建签名
	 * 
	 * @param eles
	 * @return
	 */
	public String sign(List<String> eles) {
		String sign = null;
		if (eles != null) {
			String src = "";
			final String lineTag = "#";
			boolean isEleEmpty = false;
			for (String ele : eles) {
				if (StringTool.isNull(ele)) {
					isEleEmpty = true;
					break;
				} else {
					src += ele + lineTag;
				}
			}
			if (src.endsWith(lineTag)) {
				src = src.substring(0, src.length() - lineTag.length());
			}
			if (!isEleEmpty) {
				sign = sign(src, PRIVATE_KEY);
			}
		}
		return sign;
	}

	/**
	 * RSA签名
	 * 
	 * @param content
	 *            待签名数据
	 * @param privateKey
	 *            商户私钥
	 * @return 签名值
	 */
	public String sign(String content, String privateKey) {
		final String charset = "utf-8";
		try {
			System.out.println("content:" + content);

			PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(Base64.decode(privateKey));
			KeyFactory keyf = KeyFactory.getInstance("RSA");
			PrivateKey priKey = keyf.generatePrivate(priPKCS8);
			java.security.Signature signature = java.security.Signature.getInstance(SIGN_ALGORITHMS);
			signature.initSign(priKey);
			signature.update(content.getBytes(charset));
			byte[] signed = signature.sign();

			System.out.println("base64encode:" + new String(Base64.encode(signed)));

			return new String(Base64.encode(signed));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * 计算 HMAC-SHA1 签名
	 * 最后再用base64 encode
	 */
	public String singUsingHMAC_SHA1(String data, String key) {
		String result=null;

		try {
			final String HMAC_SHA1_ALGORITHM = "HmacSHA1";
			// get an hmac_sha1 key from the raw key bytes
			SecretKeySpec signingKey = new SecretKeySpec(key.getBytes(), HMAC_SHA1_ALGORITHM);

			// get an hmac_sha1 Mac instance and initialize with the signing key
			Mac mac = Mac.getInstance(HMAC_SHA1_ALGORITHM);
			mac.init(signingKey);

			// compute the hmac on input data bytes
			byte[] rawHmac = mac.doFinal(data.getBytes());

			// base64-encode the hmac
//			result = Encoding.EncodeBase64(rawHmac);
			result=Base64Tool.instance.encode(rawHmac);
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		return result;
	}
}
