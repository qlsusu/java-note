import java.util.Scanner;

/*
 As the name of the class should be Solution, using Solution.java as the filename is recommended.
 In any case, you can execute your program by running 'java Solution' command.
 */
class Solution {
	static int N = 100;
	static int n, AnswerN;
	static int[][] map = new int[N][N];

	public static void main(String args[]) throws Exception {
		int T;
		/*
		 * The method below means that the program will read from input.txt,
		 * instead of standard(keyboard) input. To test your program, you may
		 * save input data in input.txt file, and call below method to read from
		 * the file when using nextInt() method. You may remove the comment
		 * symbols(//) in the below statement and use it. But before submission,
		 * you must remove the freopen function or rewrite comment symbols(//).
		 */
		// System.setIn(new FileInputStream("res/sample_input.txt"));

		/*
		 * Make new scanner from standard input System.in, and read data.
		 */
		Scanner sc = new Scanner(System.in);

		T = sc.nextInt();

		for (int test_case = 1; test_case <= T; test_case++) {
			/*
			 * Read each test case from standard input.
			 */
			n = sc.nextInt();
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					map[i][j] = sc.nextInt();

				}
			}

			// List<String> contents = FileTool.getInstance().readContentByLine(
			// "_data/exam.txt");
			// n = Integer.valueOf(contents.remove(0));
			//
			// for (int i = 0; i < contents.size(); i++) {
			// String content = contents.get(i);
			// String[] ss = content.split(" ");
			// for (int j = 0; j < ss.length; j++) {
			// map[i][j] = Integer.valueOf(ss[j]);
			// }
			// }

			// ///////////////////////////////////////////////////////////////////////////////////////////
			/*
			 * Please, implement your algorithm from this section.
			 */
			// ///////////////////////////////////////////////////////////////////////////////////////////
			AnswerN = 0;

			final int left = 0;
			final int right = 1;
			final int up = 2;
			final int down = 3;
			int direction = right;

			final int mirror1 = 1;
			final int mirror2 = 2;

			int row = 0;
			int col = 0;

			boolean isPass = true;
			do {
				isPass = true;
				switch (direction) {
				case right:
					for (int i = col + 1; i < N; i++) {
						int next = map[row][i];

						if (next == mirror1) {
							isPass = false;
							AnswerN++;

							direction = up;

							col = i;
							break;
						} else if (next == mirror2) {
							isPass = false;
							AnswerN++;

							direction = down;
							col = i;
							break;
						}
					}
					break;
				case left:
					for (int i = col - 1; i >= 0; i--) {
						int next = map[row][i];

						if (next == mirror1) {
							isPass = false;
							AnswerN++;

							direction = down;

							col = i;
							break;
						} else if (next == mirror2) {
							isPass = false;
							AnswerN++;

							direction = up;
							col = i;
							break;
						}
					}
					break;
				case up:
					for (int i = row - 1; i >= 0; i--) {
						int next = map[i][col];

						if (next == mirror1) {
							isPass = false;
							AnswerN++;

							direction = right;

							row = i;
							break;
						} else if (next == mirror2) {
							isPass = false;
							AnswerN++;

							direction = left;
							row = i;
							break;
						}
					}
					break;
				case down:
					for (int i = row + 1; i < N; i++) {
						int next = map[i][col];

						if (next == mirror1) {
							isPass = false;
							AnswerN++;

							direction = left;

							row = i;
							break;
						} else if (next == mirror2) {
							isPass = false;
							AnswerN++;

							direction = right;
							row = i;
							break;
						}
					}
					break;
				default:
					break;
				}
			} while (!isPass);

			// Print the answer to standard output(screen).
			System.out.println("#" + test_case + " " + AnswerN);
		}
	}
}
