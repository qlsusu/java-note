package bean;

import org.springframework.beans.factory.annotation.Required;

public class Bean2 {
    public Bean2() {
        System.out.println("bean2 constructor");
    }

    private String name;

    private Bean1 bean1;

    public String getName() {
        return name;
    }

    public Bean1 getBean1() {
        return bean1;
    }

    public void setBean1(Bean1 bean1) {
        this.bean1 = bean1;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void init() {
        System.out.println("bean2 init");
    }

    public void destroy() {
        System.out.println("bean2 destroy");
    }
}
