package bean;

public class Bean1 {
    public Bean1() {
        System.out.println("bean1 constructor");
    }

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void init() {
        System.out.println("bean1 init");
    }

    public void destroy() {
        System.out.println("bean1 destroy");
    }

    public void logic() {
        System.out.println("Bean1.logic,name:" + name);
    }
}
