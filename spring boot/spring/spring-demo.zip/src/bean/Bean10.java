package bean;

import org.springframework.core.io.Resource;

public class Bean10 {
    private Resource resource;

    public Resource getResource() {
        return resource;
    }

    public void setResource(Resource resource) {
        this.resource = resource;
    }
}
