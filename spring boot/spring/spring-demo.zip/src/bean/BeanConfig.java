package bean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfig {
    @Bean("bean1FromConfig")
    public Bean1 getBean() {
        Bean1 bean1 = new Bean1();
        bean1.setName("bean1FromConfig");
        return bean1;
    }
}
