package bean;

import java.util.List;
import java.util.Map;
import java.util.Properties;

public class Bean4 {
    private List<Bean1> beans;

    private int[] numbers;

    private Map<String, Bean1> nameToBean1;

    private Properties properties;

    public Properties getProperties() {
        return properties;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    public Map<String, Bean1> getNameToBean1() {
        return nameToBean1;
    }

    public void setNameToBean1(Map<String, Bean1> nameToBean1) {
        this.nameToBean1 = nameToBean1;
    }

    public int[] getNumbers() {
        return numbers;
    }

    public void setNumbers(int[] numbers) {
        this.numbers = numbers;
    }

    public List<Bean1> getBeans() {
        return beans;
    }

    public void setBeans(List<Bean1> beans) {
        this.beans = beans;
    }

}
