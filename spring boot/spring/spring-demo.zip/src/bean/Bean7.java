package bean;

public class Bean7 {
    private Bean6 bean6;

    public Bean6 getBean6() {
        return bean6;
    }

    public void setBean6(Bean6 bean6) {
        this.bean6 = bean6;
    }
}
