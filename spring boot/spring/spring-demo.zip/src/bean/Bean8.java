package bean;

public class Bean8 {
    public Bean1 makeBean1() {
        System.out.println("Bean8.makeBean1");
        return null;
    }

    public Bean2 makeBean2() {
        System.out.println("Bean8.makeBean2");
        Bean2 bean2 = new Bean2();
        bean2.setName("nameOfBean2");
        return bean2;
    }
}
