package bean;

public class Bean9 {
    public void logic() {
        System.out.println("logic");
    }

    public void logic(String str1, String str2) {
        System.out.println("logic:" + str1 + "," + str2);
    }
}
