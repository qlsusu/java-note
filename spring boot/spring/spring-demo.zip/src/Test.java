import bean.*;
import org.junit.After;
import org.junit.Before;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Map;
import java.util.Properties;

public class Test {
    private AbstractApplicationContext context;

    @Before
    public void before() {
        context = new ClassPathXmlApplicationContext("classpath:spring-config.xml");
    }

    @org.junit.Test
    public void simple() {
        Bean1 bean = (Bean1) context.getBean("bean1");
        System.out.println("name:" + bean.getName());
    }

    @org.junit.Test
    public void testImport() {
        Bean2 bean2 = (Bean2) context.getBean("bean2");
        System.out.println("bean2.name:" + bean2.getName());
    }

    @org.junit.Test
    public void config() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:spring-config-annotation.xml");
        Bean1 bean1FromConfig = (Bean1) context.getBean("bean1FromConfig");
        System.out.println("name:" + bean1FromConfig.getName());
    }

    @org.junit.Test
    public void constructor() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:spring-config3.xml");
        Bean3 bean1FromConfig = (Bean3) context.getBean("bean3");
        System.out.println(bean1FromConfig.getName2());
    }

    @org.junit.Test
    public void list() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:spring-config-list.xml");
        Bean4 bean = (Bean4) context.getBean("bean4");
        System.out.println(bean.getBeans().get(0).getName());

        System.out.println(bean.getNumbers()[0]);

        Map.Entry<String, Bean1> entry = bean.getNameToBean1().entrySet().iterator().next();
        System.out.println(entry.getKey() + "," + entry.getValue().getName());

        Properties properties = bean.getProperties();
        for (String key : properties.stringPropertyNames()) {
            System.out.println(key + ":" + properties.getProperty(key));
        }
    }

    @org.junit.Test
    public void innerBean() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:spring-config-innerbean.xml");
        Bean2 bean = (Bean2) context.getBean("bean2");
        System.out.println(bean.getBean1().getName());
    }

    @org.junit.Test
    public void nullValue() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:spring-config-null.xml");
        Bean2 bean = (Bean2) context.getBean("bean2");
        System.out.println("bean1 is null?:" + (bean.getBean1() == null));
    }

    @org.junit.Test
    public void navigation() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:spring-config-navigation.xml");
        Bean2 bean2 = (Bean2) context.getBean("bean2");
        Bean5 bean5 = (Bean5) context.getBean("bean5");
        System.out.println(bean5.getBean2().getName());
    }

    @org.junit.Test
    public void p() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:spring-config-p.xml");
        Bean2 bean2 = (Bean2) context.getBean("bean2");
        System.out.println(bean2.getBean1().getName());
    }

    @org.junit.Test
    public void circle() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:spring-config-circle.xml");
        Bean7 bean7 = (Bean7) context.getBean("bean7");
        Bean6 bean6 = (Bean6) context.getBean("bean6");
        System.out.println(bean7.getBean6() == bean6);
        System.out.println(bean6.getBean7() == bean7);
    }

    @org.junit.Test
    public void dependson() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:spring-config-dependson.xml");
    }

    @org.junit.Test
    public void autoWireCandidate() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:spring-config-autowire-candidate.xml");
        Bean2 bean2 = (Bean2) context.getBean("bean2");
        System.out.println(bean2.getBean1().getName());
    }

    @org.junit.Test
    public void dependCheck() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:spring-config-depend-check.xml");
        Bean2 bean2 = (Bean2) context.getBean("bean2");
    }


    @After
    public void after() {
        context.destroy();
    }
}
