import bean.*;
import org.junit.After;
import org.junit.Before;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import java.io.*;
import java.util.Map;
import java.util.Properties;

public class Test {
    private AbstractApplicationContext context;

    @Before
    public void before() {
        context = new ClassPathXmlApplicationContext("classpath:config/spring-config.xml");
    }

    @org.junit.Test
    public void simple() {
        Bean1 bean = (Bean1) context.getBean("bean1");
        System.out.println("name:" + bean.getName());
    }

    /**
     * config中的import
     */
    @org.junit.Test
    public void testImport() {
        Bean2 bean2 = (Bean2) context.getBean("bean2");
        System.out.println("bean2.name:" + bean2.getName());
    }

    /**
     * @Configuration 和 @Bean
     */
    @org.junit.Test
    public void config() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-annotation.xml");
        Bean1 bean1FromConfig = (Bean1) context.getBean("bean1FromConfig");
        System.out.println("name:" + bean1FromConfig.getName());
    }

    /**
     * config中配置 构造函数中的 参数依赖
     */
    @org.junit.Test
    public void constructor() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config3.xml");
        Bean3 bean1FromConfig = (Bean3) context.getBean("bean3");
        System.out.println(bean1FromConfig.getName2());
    }

    /**
     * config中 配置 集合性质（如：list, set, map, []） 的参数
     */
    @org.junit.Test
    public void list() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-collection.xml");
        Bean4 bean = (Bean4) context.getBean("bean4");
        System.out.println(bean.getBeans().get(0).getName());

        System.out.println(bean.getNumbers()[0]);

        Map.Entry<String, Bean1> entry = bean.getNameToBean1().entrySet().iterator().next();
        System.out.println(entry.getKey() + "," + entry.getValue().getName());

        Properties properties = bean.getProperties();
        for (String key : properties.stringPropertyNames()) {
            System.out.println(key + ":" + properties.getProperty(key));
        }
    }

    /**
     * config中，配置inner bean（为 Bean.someBean所用，但外部不可见）
     */
    @org.junit.Test
    public void innerBean() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-innerbean.xml");
        Bean2 bean = (Bean2) context.getBean("bean2");
        System.out.println(bean.getBean1().getName());
    }

    /**
     * config中，配置 Bean.someBean=null
     */
    @org.junit.Test
    public void nullValue() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-null.xml");
        Bean2 bean = (Bean2) context.getBean("bean2");
        System.out.println("bean1 is null?:" + (bean.getBean1() == null));
    }

    /**
     * config中，配置Bean.someBean.someField
     */
    @org.junit.Test
    public void navigation() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-navigation.xml");
        Bean2 bean2 = (Bean2) context.getBean("bean2");
        Bean5 bean5 = (Bean5) context.getBean("bean5");
        System.out.println(bean5.getBean2().getName());
    }

    /**
     * config中，p:的使用（简化 属性配置）
     */
    @org.junit.Test
    public void p() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-p.xml");
        Bean2 bean2 = (Bean2) context.getBean("bean2");
        System.out.println(bean2.getBean1().getName());
    }

    /**
     * config中，配置循环依赖（尽量不要出现这种情况）
     */
    @org.junit.Test
    public void circle() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-circle.xml");
        Bean7 bean7 = (Bean7) context.getBean("bean7");
        Bean6 bean6 = (Bean6) context.getBean("bean6");
        System.out.println(bean7.getBean6() == bean6);
        System.out.println(bean6.getBean7() == bean7);
    }

    /**
     * config中，bean1 dependson bean2，则bean2要先于bean1被构建
     */
    @org.junit.Test
    public void dependsOn() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-dependson.xml");
    }

    /**
     * config中，autowire的使用
     */
    @org.junit.Test
    public void autoWireCandidate() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-autowire-candidate.xml");
        Bean2 bean2 = (Bean2) context.getBean("bean2");
        System.out.println(bean2.getBean1().getName());
    }

    @org.junit.Test
    public void dependCheck() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-depend-check.xml");
        Bean2 bean2 = (Bean2) context.getBean("bean2");
    }

    /**
     * config中，lookup-method（在类中定义的方法并不会被真实执行，该方法的返回值为 byType autoWire的结果）
     */
    @org.junit.Test
    public void lookup() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-lookup.xml");
        Bean8 bean8 = (Bean8) context.getBean("bean8");
        //通过cglib生成的类：bean.Bean8$$EnhancerBySpringCGLIB$$6c3576e6
        //无论Bean8是否是 抽象的
        System.out.println("class:" + bean8.getClass());
        Bean1 bean1 = bean8.makeBean1();
        System.out.println("bean1.name:" + bean1.getName());
        Bean2 bean2 = bean8.makeBean2();
        System.out.println("bean2.name:" + bean2.getName());
    }

    /**
     * MethodReplacer的使用
     */
    @org.junit.Test
    public void methodReplacer() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-methodreplace.xml");
        Bean9 bean9 = (Bean9) context.getBean("bean9");
        bean9.logic();
        bean9.logic("str1", "str2");
    }

    /**
     * Resource的使用
     */
    @org.junit.Test
    public void resource() {
        System.out.println(new File(".").getAbsolutePath());
        Resource resource = new FileSystemResource("src/spring-config-p.xml");
        readResource(resource);

        //此时的资源路径 是相对于 Bean9.class 的资源路径的 父级
        resource = new ClassPathResource("bean-resource.txt", Bean9.class);
        readResource(resource);
    }

    private void readResource(Resource resource) {
        System.out.println("--------------");
        if (resource.exists()) {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(resource.getInputStream()));
                System.out.println("content:" + reader.readLine());
                reader.close();
                System.out.println("resource open?:" + resource.isOpen());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * config中，为Bean赋予 Resource类型的成员变量
     */
    @org.junit.Test
    public void giveResource() {
        System.out.println(new File(".").getAbsolutePath());
        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-giveresource.xml");
        Bean10 bean10 = (Bean10) context.getBean("bean10");
        readResource(bean10.getResource());
    }

    /**
     * classpath: classpath*: 的使用（其中，classpath:不能解析通配符）
     */
    @org.junit.Test
    public void resourcePattern() {
        String pattern = "LICENSE-junit.txt";
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        Resource resource = resolver.getResource("classpath:" + pattern);
        try {
            System.out.println(resource.getURI());
        } catch (IOException e) {
            e.printStackTrace();
        }

        pattern = "LICENSE*.txt";
        resource = resolver.getResource("classpath:" + pattern);
        System.out.println("resource exist?:" + resource.exists());

        pattern = "LICENSE*.txt";
        try {
            Resource[] resources = resolver.getResources("classpath*:" + pattern);
            System.out.println("size:" + resources.length);
            for (Resource resource1 : resources) {
                System.out.println("uri:" + resource1.getURI());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        pattern = "LICENSE-junit.txt";
        try {
            Resource[] resources = resolver.getResources("classpath*:" + pattern);
            System.out.println("size:" + resources.length);
            for (Resource resource1 : resources) {
                System.out.println("uri:" + resource1.getURI());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @After
    public void after() {
        context.destroy();
    }
}
