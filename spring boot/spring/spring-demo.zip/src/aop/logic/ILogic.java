package aop.logic;

public interface ILogic {
    int logic(int number) throws RuntimeException;
}
