package aop.logic;

public class Logic5Sub extends Logic5{

}
