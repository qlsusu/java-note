package aop.logic.impl;

import aop.logic.ILogic;

public class Logic1 implements ILogic {
    @Override
    public int logic(int number) throws RuntimeException {
        System.out.println("Logic1.logic,number:" + number);
        if (number == -1) {
            System.out.println("error happen, throw exception");
            throw new IllegalArgumentException("wrong number");
        }
        return -1;
    }
}
