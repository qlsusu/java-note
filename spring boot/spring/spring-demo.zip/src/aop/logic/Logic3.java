package aop.logic;

public class Logic3 {
    public void logic(int number, String name) {
        System.out.println("Logic3.logic,number:" + number + ",name:" + name);
    }

    public void logic2(int number, String name, String desc) {
        System.out.println("Logic3.logic2,number:" + number + ",name:" + name + ",desc:" + desc);
    }

    public void logic3(String name, int number) {
        System.out.println("Logic3.logic3,name:" + name + ",number:" + number);
    }
}
