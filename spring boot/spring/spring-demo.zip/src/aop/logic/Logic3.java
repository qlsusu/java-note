package aop.logic;

public class Logic3 {
    public void logic(int number, String name) {
        System.out.println("Logic3.logic,number:" + number + ",name:" + name);
    }
}
