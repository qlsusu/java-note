package aop.logic;

import aop.annotation.MarkForClass;
import aop.annotation.MarkForMethod;

public class Logic6 {
    @MarkForMethod
    public void logic(){
        System.out.println("Logic6.logic");
    }

    @MarkForMethod
    public void logic2(){
        System.out.println("Logic6.logic2");
    }
}
