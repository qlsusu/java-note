package aop.logic;

public class Logic6Sub extends Logic6 {
    @Override
    public void logic() {
        super.logic();
    }
}
