package aop.logic;

public class Logic2 {
    public void logic(){
        System.out.println("Logic2.logic");
    }
}
