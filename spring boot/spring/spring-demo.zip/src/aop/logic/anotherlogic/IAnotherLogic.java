package aop.logic.anotherlogic;

public interface IAnotherLogic {
    void anotherLogic();
}
