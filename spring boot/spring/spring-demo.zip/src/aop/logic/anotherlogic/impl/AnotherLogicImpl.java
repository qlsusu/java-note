package aop.logic.anotherlogic.impl;

import aop.logic.anotherlogic.IAnotherLogic;

public class AnotherLogicImpl implements IAnotherLogic {
    @Override
    public void anotherLogic() {
        System.out.println("anotherLogic");
    }
}
