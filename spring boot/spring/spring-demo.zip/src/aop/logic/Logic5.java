package aop.logic;

import aop.annotation.MarkForClass;

@MarkForClass
public class Logic5 {
    public void logic(){
        System.out.println("Logic5.logic");
    }
}
