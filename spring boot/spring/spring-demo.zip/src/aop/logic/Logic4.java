package aop.logic;

public class Logic4 {
    public String logic() {
        System.out.println("Logic4.logic");
        return "logic";
    }

    public void logicThrowException(boolean isThrowRightException) throws RuntimeException {
        System.out.println("Logic4.logicThrowException");
        if (isThrowRightException) {
            throw new IllegalArgumentException("illegal state");
        } else {
            throw new IllegalStateException();
        }
    }

    public void logic2(String str) {
        System.out.println("Logic4.logic2,str:" + str);
    }
}
