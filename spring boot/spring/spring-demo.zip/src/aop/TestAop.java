package aop;

import aop.logic.ILogic;
import aop.logic.Logic2;
import aop.logic.Logic3;
import aop.logic.Logic4;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAop {
    private AbstractApplicationContext context;

    @Before
    public void before() {
        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop1.xml");
    }

    /**
     * aop，目标对象 为接口
     */
    @org.junit.Test
    public void aop1() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop1.xml");
        ILogic logic = (ILogic) context.getBean("logic1");
        //class com.sun.proxy.$Proxy8
        System.out.println("class:" + logic.getClass());

        System.out.println("---------------------------");
        logic.logic(0);

        System.out.println("---------------------------");
        try {
            logic.logic(-1);
        } catch (RuntimeException e) {
            System.out.println("exception caught:" + e.getMessage());
        } finally {
            System.out.println("finally");
        }
    }

    /**
     * aop，目标对象 不为接口
     */
    @org.junit.Test
    public void aop2() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop2.xml");
        //目标对象 不一定实现了 接口
        Logic2 logic = (Logic2) context.getBean("logic2");
        //class aop.logic.Logic2$$EnhancerBySpringCGLIB$$6b15a8c7
        System.out.println("class:" + logic.getClass());
        logic.logic();
    }

    /**
     * aop，多个aspect的情况
     */
    @org.junit.Test
    public void aopMoreAspects() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-moreaspect.xml");
        ILogic logic = (ILogic) context.getBean("logic1");
        logic.logic(0);
    }

    /**
     * aop，around advice
     */
    @org.junit.Test
    public void aopAround1() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-around1.xml");
        ILogic logic = (ILogic) context.getBean("logic1");
        logic.logic(0);
    }

    /**
     * aop，around advice
     */
    @org.junit.Test
    public void aopAround2() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-around2.xml");
        ILogic logic = (ILogic) context.getBean("logic1");
        try {
            logic.logic(0);
        } catch (RuntimeException e) {
            System.out.println("error happens:" + e.getMessage());
        } finally {
            System.out.println("finally");
        }
    }

    /**
     * aop，around advice
     * 调用目标的方法
     */
    @org.junit.Test
    public void aopAround3() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-around3.xml");
        ILogic logic = (ILogic) context.getBean("logic1");
        try {
            logic.logic(0);
        } catch (RuntimeException e) {
            System.out.println("error happens:" + e.getMessage());
        } finally {
            System.out.println("finally");
        }
    }

    /**
     * aop，有参数的情况
     */
    @org.junit.Test
    public void aopArg() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-arg.xml");
        Logic3 logic3 = (Logic3) context.getBean("logic3");
        try {
            logic3.logic(100, "bill");
        } catch (RuntimeException e) {
            System.out.println("error happens:" + e.getMessage());
        } finally {
            System.out.println("finally");
        }
    }

    @Test
    public void afterReturning() {
        context.destroy();
        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-afterreturning.xml");

        Logic4 logic4 = (Logic4) context.getBean("logic4");
        logic4.logic();
    }

    @Test
    public void afterThrowing() {
        context.destroy();
        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-afterthrowing.xml");

        Logic4 logic4 = (Logic4) context.getBean("logic4");
        try {
            logic4.logicThrowException(true);
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
        }
    }

    /**
     * aop:after
     * after方法 使用 logic中的实参（而不是返回值）
     */
    @Test
    public void aopAfter() {
        context.destroy();
        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-after.xml");

        Logic4 logic4 = (Logic4) context.getBean("logic4");
        logic4.logic2("hello");
    }

    @After
    public void after() {
        context.destroy();
    }
}
