package aop;

import aop.logic.*;
import aop.logic.anotherlogic.IAnotherLogic;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAop {
    private AbstractApplicationContext context;

    @Before
    public void before() {
        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop1.xml");
    }

    /**
     * aop，目标对象 为接口
     */
    @org.junit.Test
    public void aop1() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop1.xml");
        ILogic logic = (ILogic) context.getBean("logic1");
        //class com.sun.proxy.$Proxy8
        System.out.println("class:" + logic.getClass());

        System.out.println("---------------------------");
        logic.logic(0);

        System.out.println("---------------------------");
        try {
            logic.logic(-1);
        } catch (RuntimeException e) {
            System.out.println("exception caught:" + e.getMessage());
        } finally {
            System.out.println("finally");
        }
    }

    /**
     * aop，目标对象 不为接口
     */
    @org.junit.Test
    public void aop2() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop2.xml");
        //目标对象 不一定实现了 接口
        Logic2 logic = (Logic2) context.getBean("logic2");
        //class aop.logic.Logic2$$EnhancerBySpringCGLIB$$6b15a8c7
        System.out.println("class:" + logic.getClass());
        logic.logic();
    }

    /**
     * aop，多个aspect的情况
     */
    @org.junit.Test
    public void aopMoreAspects() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-moreaspect.xml");
        ILogic logic = (ILogic) context.getBean("logic1");
        logic.logic(0);
    }

    /**
     * aop，around advice
     */
    @org.junit.Test
    public void aopAround1() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-around1.xml");
        ILogic logic = (ILogic) context.getBean("logic1");
        logic.logic(0);
    }

    /**
     * aop，around advice
     */
    @org.junit.Test
    public void aopAround2() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-around2.xml");
        ILogic logic = (ILogic) context.getBean("logic1");
        try {
            logic.logic(0);
        } catch (RuntimeException e) {
            System.out.println("error happens:" + e.getMessage());
        } finally {
            System.out.println("finally");
        }
    }

    /**
     * aop，around advice
     * 调用目标的方法，参照于：{@link aop.aspect.Aspect1#around3(ProceedingJoinPoint)}
     */
    @org.junit.Test
    public void aopAround3() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-around3.xml");
        ILogic logic = (ILogic) context.getBean("logic1");
        try {
            logic.logic(0);
        } catch (RuntimeException e) {
            System.out.println("error happens:" + e.getMessage());
        } finally {
            System.out.println("finally");
        }
    }

    /**
     * aop，有参数的情况
     */
    @org.junit.Test
    public void aopArg() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-arg.xml");
        Logic3 logic3 = (Logic3) context.getBean("logic3");
        try {
            //下述方法被切入，因为：参数个数，参数类型，参数顺序 一致
            logic3.logic(100, "bill");
            //下述方法并没有被切入，因为 参数个数不符
            logic3.logic2(100, "bill", "sheme");
            //下述方法并没有被切入，因为 参数顺序不符
            logic3.logic3("bill", 100);
        } catch (RuntimeException e) {
            System.out.println("error happens:" + e.getMessage());
        } finally {
            System.out.println("finally");
        }
    }

    @Test
    public void afterReturning() {
        context.destroy();
        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-afterreturning.xml");

        Logic4 logic4 = (Logic4) context.getBean("logic4");
        logic4.logic();
    }

    @Test
    public void afterThrowing() {
        context.destroy();
        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-afterthrowing.xml");

        Logic4 logic4 = (Logic4) context.getBean("logic4");
        try {
            logic4.logicThrowException(true);
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
        }
    }

    /**
     * 当目标方法 抛出的 异常 属于 advice方法的 所接受的异常时（自身类 或 子类）
     */
    @Test
    public void afterThrowing2() {
        context.destroy();
        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-afterthrowing2.xml");

        Logic4 logic4 = (Logic4) context.getBean("logic4");
        try {
            logic4.logicThrowException(true);
        } catch (RuntimeException e) {
//            e.printStackTrace();
            System.out.println("get error");
        } finally {
        }
    }

    /**
     * aop:after
     * after方法 使用 logic中的实参（而不是返回值）
     */
    @Test
    public void aopAfter() {
        context.destroy();
        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-after.xml");

        Logic4 logic4 = (Logic4) context.getBean("logic4");
        logic4.logic2("hello");
    }

    /**
     * 一个类拥有另外一个接口
     */
    @Test
    public void testAnotherInterface() {
        context.destroy();
        context = new ClassPathXmlApplicationContext("classpath:aop/config/spring-config-aop-another_interface.xml");

        ILogic logic1 = (ILogic) context.getBean("logic1");
        logic1.logic(2);

        IAnotherLogic anotherLogic = (IAnotherLogic) context.getBean("logic1");
        anotherLogic.anotherLogic();
    }

    @Test
    public void testAnnotation() {
        context.destroy();
        context = new ClassPathXmlApplicationContext("classpath:aop/config/annotation/spring-config-aop-annotation.xml");

        Logic4 Logic4 = (Logic4) context.getBean("logic4");
        Logic4.logic2("hello");
    }

    @Test
    public void testThis() {
        context.destroy();
        context = new ClassPathXmlApplicationContext("classpath:aop/config/annotation/spring-config-aop-this.xml");

        ILogic Logic1 = (ILogic) context.getBean("logic1");
        Logic1.logic(100);
    }

    @Test
    public void testThis2() {
        context.destroy();
        context = new ClassPathXmlApplicationContext("classpath:aop/config/annotation/spring-config-aop-this2.xml");

        ILogic Logic1 = (ILogic) context.getBean("logic1");
        Logic1.logic(100);
    }

    @Test
    public void withinTargetAnnotation() {
        context.destroy();
        context = new ClassPathXmlApplicationContext("classpath:aop/config/annotation/spring-config-aop-within_target_annotation.xml");

        Logic5 Logic5 = (Logic5) context.getBean("logic5");
        Logic5.logic();

        System.out.println("----------------------");
        Logic5Sub logic5Sub = (Logic5Sub) context.getBean("logic5Sub");
        logic5Sub.logic();

        System.out.println("----------------------");
        Logic6 logic6 = (Logic6) context.getBean("logic6");
        logic6.logic();
        logic6.logic2();

        System.out.println("----------------------");
        Logic6Sub logic6Sub = (Logic6Sub) context.getBean("logic6Sub");
        logic6Sub.logic();
        logic6Sub.logic2();
    }

    /**
     * ordered接口的使用：影响aspect的执行顺序
     */
    @Test
    public void order() {
        context.destroy();
        context = new ClassPathXmlApplicationContext("classpath:aop/config/annotation/spring-config-aop-order.xml");

        Logic4 logic4 = (Logic4) context.getBean("logic4");
        logic4.logic2("bill");
    }


    @After
    public void after() {
        context.destroy();
    }
}
