package aop.aspect;

import aop.logic.ILogic;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;

public class Aspect1 {
    public void before() {
        System.out.println("Aspect1.before!!!!!!!!!!");
    }

    public void after() {
        System.out.println("Aspect1.after!!!!!!!!!!!!!!!!");
    }

    public void afterReturn() {
        System.out.println("Aspect1.afterReturn!!!!!!!!!!!!!!!!");
    }

    public void afterThrowing() {
        System.out.println("Aspect1.afterThrowing!!!!!!!!!!!!!!!!");
    }

    /**
     * 该方法需要有返回值
     * 因为其参照于 目标 {@link ILogic#logic(int)}
     *
     * @return
     */
    public int around1() throws RuntimeException {
        System.out.println("Aspect1.around1!!!!!!!!!!!!!!!!");
        return 0;
    }

    public int around2() throws RuntimeException {
        System.out.println("Aspect1.around1!!!!!!!!!!!!!!!!");
        throw new IllegalArgumentException("wrong arg in advice");
    }

    public int around3(ProceedingJoinPoint joinPoint) throws RuntimeException {
        System.out.println("Aspect1.around3!!!!!!!!!!!!!!!!");
        try {
            //调用 目标对象的方法
            return (int) joinPoint.proceed(new Object[]{100});
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        return -1;
    }
}
