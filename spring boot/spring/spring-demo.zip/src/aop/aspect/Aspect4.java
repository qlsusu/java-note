package aop.aspect;

public class Aspect4 {
    public void afterReturning(String str) {
        System.out.println("Aspect4.afterReturning,str:" + str);
    }
}
