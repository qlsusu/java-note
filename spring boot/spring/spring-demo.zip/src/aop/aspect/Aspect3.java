package aop.aspect;

public class Aspect3 {
//    public void before() {
//        System.out.println("Aspect3.before!!!!!!!!!!,number2:");
//    }

    public void before(String name2, int number2) {
        System.out.println("Aspect3.before!!!!!!!!!!,number2:" + number2 + ",name2:" + name2);
    }

    //不能定义该方法
    //因为，已经存在一个方法1 和其同名
    //且方法1 和 本方法 都候选成为 advisor
//    public void before() {
//        System.out.println("Aspect3.before!!!!!!!!!!");
//    }

    public void after(int number2, String name2) {
        System.out.println("Aspect3.after!!!!!!!!!!,number2:" + number2 + ",name2:" + name2);
    }
}
