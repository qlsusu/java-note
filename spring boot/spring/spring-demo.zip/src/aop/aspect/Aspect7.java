package aop.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.Ordered;

@Aspect
public class Aspect7 implements Ordered {
    @Pointcut(value = "execution(* aop.logic..*.*(..)) && args(str2)")
    public void pointcut(String str2) {
        //此处的逻辑不会执行
        //仅仅是定义pointcut
        System.out.println("pointcut, str2:" + str2);
    }

    @Before(value = "pointcut(str3)")
    public void beforeAdvice(String str3) {
        System.out.println("Aspect7.beforeAdvice,str3:" + str3);
    }

    @Before(value = "pointcut(str3)")
    public void beforeAdvice2(String str3) {
        System.out.println("Aspect7.beforeAdvice2,str3:" + str3);
    }

    @Override
    public int getOrder() {
        return 1;
    }
}
