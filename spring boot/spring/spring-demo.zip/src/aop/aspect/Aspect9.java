package aop.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class Aspect9 {
    @Before(value = "execution(* aop.logic..*.*(..)) && args(number)")
    public void beforeAdvice(int number) {
        System.out.println("Aspect9.afterAdvice,number:" + number);
    }
}
