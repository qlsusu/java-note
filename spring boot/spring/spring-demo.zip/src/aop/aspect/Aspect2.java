package aop.aspect;

public class Aspect2 {
    public void before(){
        System.out.println("Aspect2.before!!!!!!!!!!");
    }

    public void after(){
        System.out.println("Aspect2.after!!!!!!!!!!!!!!!!");
    }
}
