package aop.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class AspectWithin {
    @After("@within(aop.annotation.MarkForClass)")
    public void afterAdvice() {
        System.out.println("AspectWithin.afterAdvice" );
    }
}
