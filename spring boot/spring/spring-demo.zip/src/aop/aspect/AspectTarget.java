package aop.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class AspectTarget {
    @After("@target(aop.annotation.MarkForClass)")
    public void afterAdvice() {
        System.out.println("AspectTarget.afterAdvice" );
    }
}
