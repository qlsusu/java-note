package aop.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class Aspect8 {
    //this作用于代理对象（而非目标对象）
    //什么是代理对象：
    //如：对于ILogic来讲，Aspect9#beforeAdvice对应的对象 就为代理对象（其由AOP生成，而非 客户手动生成）
    @Before("this(aop.logic.ILogic)")
    public void after() {
        System.out.println("Aspect8.after");
    }
}
