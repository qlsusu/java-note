package aop.aspect;

public class Aspect6 {
    public void after(String str2) {
        System.out.println("Aspect6.after,str2:"+str2);
    }
}
