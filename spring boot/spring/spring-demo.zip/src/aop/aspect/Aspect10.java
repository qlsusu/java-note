package aop.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.Ordered;

@Aspect
public class Aspect10 implements Ordered {
    @Before("target(aop.logic.Logic4) && args(str)")
    public void beforeAdvice(String str) {
        System.out.println("Aspect10.beforeAdvice,str:" + str);
    }

    @Override
    public int getOrder() {
        return 0;
    }
}
