package aop.aspect;

public class Aspect5 {
    public void afterThrowing(IllegalArgumentException e) {
        System.out.println("Aspect5.afterThrowing,exception:" + e.getMessage());
    }

    public void afterThrowing2(RuntimeException e) {
        System.out.println("Aspect5.afterThrowing2,exception:" + e.getMessage());
    }


}
