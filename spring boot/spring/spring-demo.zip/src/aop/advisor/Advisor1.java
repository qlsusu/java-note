package aop.advisor;

import org.springframework.aop.BeforeAdvice;

public class Advisor1 implements BeforeAdvice {
    void before(){
        System.out.println("Advisor1.before");
    }
}
