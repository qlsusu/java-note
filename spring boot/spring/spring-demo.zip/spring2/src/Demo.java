import bean.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.Resource;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Demo {
    private AbstractApplicationContext context;

    @Before
    public void before() {
        System.out.println("create context");
        context = new ClassPathXmlApplicationContext("classpath:config/spring-config.xml");
//        AbstractApplicationContext context = new FileSystemXmlApplicationContext("src/config/spring-config.xml");
    }

    @Test
    public void basic() {
        System.out.println("get bean1");
        Bean1 bean = (Bean1) context.getBean("bean1");

        System.out.println("bean1.name:" + bean.getName());
        System.out.println("bean1.bean2.name:" + bean.getBean2().getBean2Name());
    }

    @Test
    public void lazyInit() {
        //参见bean1
    }

    @Test
    public void constructorArgs() {
        //参见bean1
    }

    @Test
    public void scopePrototype() {
        //scope默认为singleton
        Bean1 bean1 = (Bean1) context.getBean("beanPrototype");
        Bean1 bean2 = (Bean1) context.getBean("beanPrototype");
        System.out.println("bean1 is bean2?" + (bean1 == bean2));
    }

    @Test
    public void initDestroyMethod() {
        //额外说明：Beans标签中 可以配置 default-init-method和default-destroy-method
        System.out.println("----------------");
    }

    @Test
    public void applicationContextAware() {
        //有一个bean是在乎ApplicationContext的，那么在构建了该bean后（init method之后），会为其提供ApplicationContext
        //如：Bean4
        System.out.println("-----------------");
    }

    @Test
    public void publishEvent() {
        System.out.println("-----------------");
        Bean4 bean = (Bean4) context.getBean("bean4");
        bean.publishEvent();
    }

    @Test
    public void autoWired() {
        //清理操作
        context.destroy();

        System.out.println("------------------");
        //bean1有属性bean2，而bean2在config.xml中声明了
        //那么根据default-autowire="byName"，bean1.bean2=bean2
        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-autowire.xml");
        Bean1 bean = (Bean1) context.getBean("bean1");
        System.out.println(bean.getBean2().getBean2Name());
    }

    @Test
    public void loadResource() {
        System.out.println("-----------------");
        Resource resource = context.getResource("classpath:resource/hello.txt");
        try {
            BufferedReader read = new BufferedReader(new InputStreamReader(resource.getInputStream()));
            System.out.println(read.readLine());
            read.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void componentScan() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-componentscan.xml");
        Bean6 bean = (Bean6) context.getBean("beanx");
        bean.logic();
    }

    @Test
    public void requiredSetterMethod() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-required.xml");
        System.out.println(context.getBean("bean7"));
    }

    @Test
    public void autoWiredAnnotation() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-required.xml");
        Bean7 bean = (Bean7) context.getBean("bean7");
        System.out.println("bean1.name:" + bean.getBean1().getName());
    }

    @Test
    public void autoWiredAnnotation2() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-required.xml");
        Bean8 bean = (Bean8) context.getBean("bean8");
        System.out.println("context is equal?:" + (context == bean.getContext()));
        bean.getBean1sInfo();
    }

    @Test
    public void qualifier() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-required.xml");
        Bean7 bean = (Bean7) context.getBean("bean7");
        System.out.println(bean.getBean1().getName());
    }

    @Test
    public void configurationBean() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-configurationbean.xml");
        Bean1 bean = (Bean1) context.getBean("bean1");
        System.out.println(bean.getName());
    }

    @Test
    public void propertyHolder() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-propertyplaceholder.xml");
        Bean1 bean = (Bean1) context.getBean("bean1");
        System.out.println(bean.getName());
    }

    @Test
    public void propertyHolder2() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-componentscan.xml");
        Bean9 bean = (Bean9) context.getBean("bean9");
        System.out.println(bean.getName());
    }

    @Test
    public void scopeProxyMode() {
        context.destroy();

        context = new ClassPathXmlApplicationContext("classpath:config/spring-config-componentscan.xml");
        Bean11 bean = (Bean11) context.getBean("bean11");
        System.out.println(bean.getBean10().getClass());

        //对于proxyMode为ScopedProxyMode.INTERFACES的形式，参见：https://blog.csdn.net/u014785687/article/details/76338282
        Bean11.BeanInterface beanInterface = bean.getBean12();
        System.out.println(beanInterface.getClass());
    }

    @After
    public void after() {
        System.out.println("----------------------");
        System.out.println("destroy context");
        context.destroy();
    }
}
