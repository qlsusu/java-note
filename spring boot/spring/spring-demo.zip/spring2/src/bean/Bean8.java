package bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

@Component
public class Bean8 {
    //一些众所周知的类 可被自动autowired，而不用在 config.xml中来设置
    //如：ApplicationContext, BeanFactory, Environment, ResourceLoader, ApplicationEventPublisher, MessageSource
    @Autowired
    private ApplicationContext context;

    @Autowired(required = false)
    @Order
    private Set<Bean1> bean1s;

    public ApplicationContext getContext() {
        return context;
    }

    public void getBean1sInfo() {
        for (Bean1 bean : bean1s) {
            System.out.println(bean.getName());
        }
    }
}
