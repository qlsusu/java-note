package bean;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("beanx")
@Scope
public class Bean6 {
    public void logic() {
        System.out.println("bean6.logic");
    }
}
