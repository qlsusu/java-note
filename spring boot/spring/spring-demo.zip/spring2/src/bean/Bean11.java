package bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Bean11 {
    public interface BeanInterface {
        void logic();
    }

    @Autowired
    @Qualifier("bean10")
    private Bean10 bean10;

    @Autowired
    @Qualifier("bean12")
    private BeanInterface bean12;

    public Bean10 getBean10() {
        return bean10;
    }

    public void setBean10(Bean10 bean10) {
        this.bean10 = bean10;
    }

    public BeanInterface getBean12() {
        return bean12;
    }

    public void setBean12(BeanInterface bean12) {
        this.bean12 = bean12;
    }
}
