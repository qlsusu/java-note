package bean;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

@Component("bean10")
@Scope(scopeName = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Bean10 {
   
}
