package bean;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationEvent;

public class Bean4 implements ApplicationContextAware {
    public static class MyApplicationEvent extends ApplicationEvent {
        private String desc;

        public MyApplicationEvent(Object source) {
            super(source);
            desc = (String) source;
        }

        @Override
        public String toString() {
            return desc;
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        System.out.println("setApplicationContext");
        context = applicationContext;
    }

    private ApplicationContext context;

    public void publishEvent() {
        System.out.println("publishEvent");
        //publishEvent，系统会找到哪个bean实现ApplicationListener<Bean4.MyApplicationEvent>
        //并调用它的onApplicationEvent回调
        context.publishEvent(new MyApplicationEvent("myEvent"));
    }
}
