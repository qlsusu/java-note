package config;

import bean.Bean1;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyConfig {

    @Bean(name = "bean1")
    public Bean1 getBean1(){
        Bean1 bean= new Bean1();
        bean.setName("xxname");
        return bean;
    }

}
