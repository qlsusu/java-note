package aop.aspect;

public class Aspect1 {
    public void afterReturning(String str) {
        System.out.println("Aspect1.afterReturning,str:" + str);
    }
}
