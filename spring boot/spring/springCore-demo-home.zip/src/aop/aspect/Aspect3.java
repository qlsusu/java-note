package aop.aspect;

public class Aspect3 {
    public void after(String str2) {
        System.out.println("Aspect3.after,str2:"+str2);
    }
}
