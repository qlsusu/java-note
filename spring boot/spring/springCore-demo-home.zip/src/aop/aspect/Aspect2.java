package aop.aspect;

public class Aspect2 {
    public void afterThrowing(IllegalArgumentException e) {
        System.out.println("Aspect2.afterThrowing,exception:" + e.getMessage());
    }



}
