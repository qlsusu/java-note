package aop;

import aop.logic.Logic2;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Demo2 {
    private AbstractApplicationContext context;

    @Before
    public void before() {
        System.out.println("create context");
        context = new ClassPathXmlApplicationContext("classpath:aop/spring-config-aop-afterreturning.xml");
//        AbstractApplicationContext context = new FileSystemXmlApplicationContext("src/config/spring-config.xml");
    }

    @Test
    public void afterReturning(){
        Logic2 logic2= (Logic2) context.getBean("logic2");
        logic2.logic();
    }

    @Test
    public void afterThrowing(){
        context.destroy();
        context=new ClassPathXmlApplicationContext("classpath:aop/spring-config-aop-afterthrowing.xml");

        Logic2 logic2= (Logic2) context.getBean("logic2");
        try {
            logic2.logicThrowException(true);
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
        }
    }

    @Test
    public void aopAfter(){
        context.destroy();
        context=new ClassPathXmlApplicationContext("classpath:aop/spring-config-aop-after.xml");

        Logic2 logic2= (Logic2) context.getBean("logic2");
        logic2.logic2("hello");
    }

    @After
    public void after() {
        System.out.println("----------------------");
        System.out.println("destroy context");
        context.destroy();
    }
}
