package bean;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

@Component("bean12")
@Scope(scopeName = "session", proxyMode = ScopedProxyMode.INTERFACES)
public class Bean12 implements Bean11.BeanInterface {
    @Override
    public void logic() {
        System.out.println("bean10.logic");
    }
}
