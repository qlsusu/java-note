package bean;

public class Bean2 {
    private String bean2Name;

    public Bean2() {
        System.out.println("Bean2.constructor");
    }

    public String getBean2Name() {
        return bean2Name;
    }

    public void setBean2Name(String bean2Name) {
        this.bean2Name = bean2Name;
    }
}
