package bean;

import org.springframework.context.ApplicationListener;

public class Bean5 implements ApplicationListener<Bean4.MyApplicationEvent> {
    @Override
    public void onApplicationEvent(Bean4.MyApplicationEvent myApplicationEvent) {
        System.out.println("onApplicationEvent:" + myApplicationEvent);
    }
}
