package bean;

public class Bean1 {
    private String name;
    private int age;
    private Bean2 bean2;
    private String str1;

    public Bean1() {
        System.out.println("Bean1.constructor");
    }

    public Bean1(Bean2 bean2, String str1) {
        System.out.println("bean1.constructor with arg");
        this.bean2 = bean2;
        this.str1 = str1;
    }

    public Bean2 getBean2() {
        return bean2;
    }

    public void setBean2(Bean2 bean2) {
        this.bean2 = bean2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
