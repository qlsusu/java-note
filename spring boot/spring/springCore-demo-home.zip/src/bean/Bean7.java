package bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;

public class Bean7 {
    private String name;
    @Autowired
    @Qualifier("bean12")
    private Bean1 bean1;

    //使用autowired时，依赖的属性 默认 必须要被设置
    //如果需要 不强制 被设置，那么使用required=false
    @Autowired(required = false)
    private Bean2 bean2;

    public String getName() {
        return name;
    }

    @Required
    public void setName(String name) {
        this.name = name;
    }

    public Bean1 getBean1() {
        return bean1;
    }

    public void setBean1(Bean1 bean1) {
        this.bean1 = bean1;
    }
}
