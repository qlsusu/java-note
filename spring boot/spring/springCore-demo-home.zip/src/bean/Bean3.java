package bean;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Bean3 implements InitializingBean, DisposableBean {
    private String name;

    public Bean3() {
        System.out.println("Bean3.constructor");
    }

    public void setName(String name) {
        System.out.println("setName");
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        System.out.println("afterPropertiesSet");
    }

    public void initMethod() {
        System.out.println("initMethod");
    }

    //当bean已经定义了init方法，那么不会执行Beans标签中定义的defaultInitMethod，同样defaultDestroyMethod
    public void defaultInit() {
        System.out.println("defaultInit");
    }

    @Override
    public void destroy() {
        System.out.println("destroy");
    }

    public void destroyMethod() {
        System.out.println("destroyMethod");
    }

    public void defaultDestroy() {
        System.out.println("defaultDestroy");
    }
}
